; Установщик SlideNova (Inno Setup 6). Установка для текущего пользователя, права администратора не нужны.
#define AppVer GetEnv("SN_VERSION")
#if AppVer == ""
  #define AppVer "1.0.0"
#endif

[Setup]
AppId={{9E2B7C41-5A3D-4C8E-B1F2-6D7A8E9F0B1C}
AppName=SlideNova
AppVersion={#AppVer}
AppPublisher=SlideNova
DefaultDirName={localappdata}\Programs\SlideNova
DefaultGroupName=SlideNova
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
OutputDir=..\dist
OutputBaseFilename=SlideNova-Setup-{#AppVer}-x64
SetupIconFile=..\assets\SlideNova.ico
UninstallDisplayIcon={app}\SlideNova.exe
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ChangesAssociations=yes
CloseApplications=yes

[Languages]
Name: "ru"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "en"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительно:"
Name: "integration"; Description: "Эскизы презентаций в Проводнике и пункт «Открыть с помощью SlideNova»"; GroupDescription: "Интеграция с Windows:"

[Files]
Source: "..\dist\SlideNova\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\SlideNova"; Filename: "{app}\SlideNova.exe"
Name: "{userdesktop}\SlideNova"; Filename: "{app}\SlideNova.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\SlideNova.exe"; Parameters: "/register"; Flags: runhidden waituntilterminated; Tasks: integration
Filename: "{app}\SlideNova.exe"; Description: "Запустить SlideNova"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{app}\SlideNova.exe"; Parameters: "/unregister"; Flags: runhidden waituntilterminated; RunOnceId: "SNUnregister"
