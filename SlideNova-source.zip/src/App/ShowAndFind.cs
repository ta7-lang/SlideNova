// Демонстрация слайдов и окно «Найти и заменить».
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using SlideNova.Core;

namespace SlideNova
{
    public sealed class SlideShowWindow : Window
    {
        readonly PresentationModel _p;
        readonly SlideRenderer _r;
        readonly List<int> _order;
        int _pos;
        readonly Grid _stage = new Grid();
        readonly Viewbox _view = new Viewbox { Stretch = Stretch.Uniform };
        readonly InkCanvas _ink = new InkCanvas { Background = Brushes.Transparent, IsHitTestVisible = false };
        readonly Border _cover = new Border { Visibility = Visibility.Collapsed };
        readonly TextBlock _hud = new TextBlock { Foreground = Brushes.White, FontSize = 14, Margin = new Thickness(16), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom, Opacity = 0 };
        readonly bool _anim;
        string _typed = "";
        public int LastIndex => _order.Count > 0 ? _order[Math.Max(0, Math.Min(_pos, _order.Count - 1))] : 0;

        public SlideShowWindow(PresentationModel p, ImageCache img, int from, bool anim)
        {
            _p = p; _r = new SlideRenderer(p, img); _anim = anim;
            _order = Enumerable.Range(0, p.Slides.Count).Where(i => !p.Slides[i].Hidden || i == from).ToList();
            _pos = Math.Max(0, _order.IndexOf(from));
            WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize; WindowState = WindowState.Maximized; Topmost = true;
            Background = Brushes.Black; Title = "Показ слайдов — SlideNova";
            var host = new Grid();
            var slideHost = new Grid();
            slideHost.Children.Add(_stage);
            _ink.DefaultDrawingAttributes = new DrawingAttributes { Color = Color.FromRgb(255, 40, 120), Width = 4, Height = 4, FitToCurve = true };
            slideHost.Children.Add(_ink);
            _view.Child = slideHost;
            host.Children.Add(_view);
            host.Children.Add(_cover);
            host.Children.Add(_hud);
            Content = host;
            Cursor = Cursors.None;
            Loaded += (s, e) => Show(false);
            KeyDown += OnKey;
            MouseLeftButtonUp += (s, e) => { if (!_ink.IsHitTestVisible && !e.Handled && !(e.OriginalSource is FrameworkContentElement)) Next(); };
            MouseRightButtonUp += (s, e) => ShowMenu();
            MouseWheel += (s, e) => { if (e.Delta < 0) Next(); else Prev(); };
            MouseMove += (s, e) => { if (!_ink.IsHitTestVisible) Cursor = Cursors.Arrow; };
        }

        void Show(bool animate)
        {
            if (_order.Count == 0) { Close(); return; }
            _ink.Strokes.Clear();
            int idx = _order[_pos];
            var opt = new SlideRenderOptions { Interactive = true, OnLink = url => { Topmost = false; Security.OpenLink(url); Topmost = true; } };
            var c = _r.RenderSlide(_p.Slides[idx], idx + 1, opt);
            _stage.Children.Clear();
            _stage.Children.Add(c);
            _stage.Width = c.Width; _stage.Height = c.Height;
            _ink.Width = c.Width; _ink.Height = c.Height;
            if (animate && _anim)
            {
                c.Opacity = 0;
                c.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(320)) { EasingFunction = new QuadraticEase() });
            }
            Hud((_pos + 1) + " / " + _order.Count);
        }

        void Hud(string text)
        {
            _hud.Text = text;
            _hud.BeginAnimation(OpacityProperty, new DoubleAnimationUsingKeyFrames { KeyFrames = { new LinearDoubleKeyFrame(0.85, KeyTime.FromTimeSpan(TimeSpan.Zero)), new LinearDoubleKeyFrame(0.85, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(1.2))), new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(1.8))) } });
        }

        void Next() { if (_cover.Visibility == Visibility.Visible) { _cover.Visibility = Visibility.Collapsed; return; } if (_pos < _order.Count - 1) { _pos++; Show(true); } else EndScreen(); }
        void Prev() { if (_pos > 0) { _pos--; Show(true); } }

        bool _ended;
        void EndScreen()
        {
            if (_ended) { Close(); return; }
            _ended = true;
            _stage.Children.Clear();
            _stage.Children.Add(new TextBlock { Text = "Конец показа слайдов. Щёлкните или нажмите любую клавишу для выхода.", Foreground = Brushes.Gray, FontSize = 28, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(80) });
        }

        void OnKey(object sender, KeyEventArgs e)
        {
            if (_ended) { Close(); return; }
            switch (e.Key)
            {
                case Key.Escape: Close(); break;
                case Key.Right: case Key.Down: case Key.Space: case Key.PageDown: case Key.N: Next(); break;
                case Key.Enter: if (_typed.Length > 0 && int.TryParse(_typed, out var n)) { GoToNumber(n); _typed = ""; } else Next(); break;
                case Key.Left: case Key.Up: case Key.PageUp: case Key.Back: Prev(); break;
                case Key.Home: _pos = 0; Show(true); break;
                case Key.End: _pos = _order.Count - 1; Show(true); break;
                case Key.B: Cover(Brushes.Black); break;
                case Key.W: Cover(Brushes.White); break;
                case Key.P: TogglePen(); break;
                case Key.E: _ink.Strokes.Clear(); break;
                case Key.H: case Key.F1: Hud("→/Пробел — далее · ← — назад · номер+Enter — переход · B/W — чёрный/белый экран · P — перо · E — стереть · Esc — выход"); break;
                default:
                    if (e.Key >= Key.D0 && e.Key <= Key.D9) _typed += (char)('0' + (e.Key - Key.D0));
                    else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) _typed += (char)('0' + (e.Key - Key.NumPad0));
                    break;
            }
            e.Handled = true;
        }

        void GoToNumber(int n)
        {
            int i = _order.IndexOf(n - 1);
            if (i >= 0) { _pos = i; Show(true); }
        }

        void Cover(Brush b) { if (_cover.Visibility == Visibility.Visible && _cover.Background == b) _cover.Visibility = Visibility.Collapsed; else { _cover.Background = b; _cover.Visibility = Visibility.Visible; } }

        void TogglePen()
        {
            _ink.IsHitTestVisible = !_ink.IsHitTestVisible;
            Cursor = _ink.IsHitTestVisible ? Cursors.Pen : Cursors.None;
            Hud(_ink.IsHitTestVisible ? "Перо включено (P — выключить, E — стереть)" : "Перо выключено");
        }

        void ShowMenu()
        {
            Cursor = Cursors.Arrow;
            var m = new ContextMenu();
            void I(string h, Action a) { var mi = new MenuItem { Header = h }; mi.Click += (s, e) => a(); m.Items.Add(mi); }
            I("Следующий", Next); I("Предыдущий", Prev);
            var go = new MenuItem { Header = "Перейти к слайду" };
            for (int i = 0; i < _order.Count; i++) { int k = i; var t = _p.Slides[_order[i]].Title; var mi = new MenuItem { Header = (_order[i] + 1) + ". " + (string.IsNullOrEmpty(t) ? "Слайд" : t) }; mi.Click += (s, e) => { _pos = k; Show(true); }; go.Items.Add(mi); }
            m.Items.Add(go);
            I(_ink.IsHitTestVisible ? "Выключить перо" : "Перо", TogglePen);
            I("Стереть рисунки", () => _ink.Strokes.Clear());
            I("Чёрный экран", () => Cover(Brushes.Black));
            I("Завершить показ", Close);
            m.IsOpen = true;
        }
    }

    public sealed class FindWindow : ThemedWindow
    {
        static FindWindow _instance;
        readonly PresentationModel _p;
        readonly Action<int, ShapeModel> _goto;
        readonly Action<string> _changed;
        readonly Action _beforeChange;
        readonly TextBox _find = Ui.Input("", 320), _repl = Ui.Input("", 320);
        readonly CheckBox _case;
        readonly TextBlock _status = Ui.Text("", 12, false, "B.SubText", true);
        int _lastSlide = -1, _lastShape = -1;

        public static void Open(Window owner, PresentationModel p, bool replace, Action<int, ShapeModel> go, Action<string> changed, Action before)
        {
            if (_instance != null && _instance.IsLoaded && _instance._p == p) { _instance.Activate(); return; }
            _instance = new FindWindow(p, replace, go, changed, before) { Owner = owner };
            _instance.Show();
        }

        FindWindow(PresentationModel p, bool replace, Action<int, ShapeModel> go, Action<string> changed, Action before)
        {
            _p = p; _goto = go; _changed = changed; _beforeChange = before;
            Title = replace ? "Найти и заменить" : "Найти"; SizeToContent = SizeToContent.WidthAndHeight; ResizeMode = ResizeMode.NoResize; Topmost = true;
            ShowInTaskbar = false;
            var root = new StackPanel { Margin = new Thickness(18) };
            root.Children.Add(Ui.Text("Найти:", 12.5, false, "B.SubText")); root.Children.Add(_find);
            if (replace) { var l = Ui.Text("Заменить на:", 12.5, false, "B.SubText"); l.Margin = new Thickness(0, 8, 0, 0); root.Children.Add(l); root.Children.Add(_repl); }
            _case = Ui.Check("Учитывать регистр", false, v => { }, "Регистр", "Различать прописные и строчные буквы.");
            root.Children.Add(_case);
            var btns = Ui.Row(Ui.Action("Найти далее", FindNext, true, ""));
            if (replace) { btns.Children.Add(Ui.Action("Заменить", ReplaceOne)); btns.Children.Add(Ui.Action("Заменить все", ReplaceAll)); }
            btns.Margin = new Thickness(0, 10, 0, 6);
            root.Children.Add(btns);
            root.Children.Add(_status);
            Content = root;
            Loaded += (s, e) => _find.Focus();
            _find.KeyDown += (s, e) => { if (e.Key == Key.Enter) FindNext(); };
        }

        StringComparison Cmp => _case.IsChecked == true ? StringComparison.CurrentCulture : StringComparison.CurrentCultureIgnoreCase;

        static IEnumerable<TextBodyModel> Bodies(ShapeModel s)
        {
            if (s.Text != null) yield return s.Text;
            if (s.Table != null) foreach (var r in s.Table.Rows) foreach (var c in r) yield return c.Text;
            if (s.Children != null && s.Kind == ShapeKind.Group) foreach (var k in s.Children) foreach (var b in Bodies(k)) yield return b;
        }

        void FindNext()
        {
            var q = _find.Text;
            if (string.IsNullOrEmpty(q)) return;
            int total = _p.Slides.Count;
            for (int step = 0; step <= total; step++)
            {
                int si = ((_lastSlide < 0 ? 0 : _lastSlide) + step) % Math.Max(1, total);
                var sl = _p.Slides[si];
                int startShape = step == 0 ? _lastShape + 1 : 0;
                for (int k = startShape; k < sl.Shapes.Count; k++)
                    if (Bodies(sl.Shapes[k]).Any(b => b.PlainText.IndexOf(q, Cmp) >= 0))
                    { _lastSlide = si; _lastShape = k; _goto(si, sl.Shapes[k]); _status.Text = "Найдено на слайде " + (si + 1); return; }
                if (startShape <= sl.Shapes.Count && (sl.Notes ?? "").IndexOf(q, Cmp) >= 0 && step > 0)
                { _lastSlide = si; _lastShape = sl.Shapes.Count; _goto(si, null); _status.Text = "Найдено в заметках слайда " + (si + 1); return; }
            }
            _status.Text = "Совпадений не найдено.";
            _lastSlide = -1; _lastShape = -1;
        }

        int ReplaceIn(ShapeModel s, string q, string r, bool onlyFirst)
        {
            int n = 0;
            foreach (var b in Bodies(s))
                foreach (var p in b.Paras)
                    foreach (var run in p.Runs)
                    {
                        if (run.IsBreak || string.IsNullOrEmpty(run.Text)) continue;
                        int i;
                        while ((i = run.Text.IndexOf(q, Cmp)) >= 0)
                        {
                            run.Text = run.Text.Substring(0, i) + r + run.Text.Substring(i + q.Length);
                            n++;
                            if (onlyFirst) goto done;
                            if (r.IndexOf(q, Cmp) >= 0) break;
                        }
                    }
            done:
            if (n > 0) { if (s.Kind == ShapeKind.Table) s.DirtyTable = true; else if (s.Kind == ShapeKind.Group) { if (s.Children != null) foreach (var k in s.Children) k.DirtyText = k.Kind == ShapeKind.Table ? k.DirtyText : true; } else s.DirtyText = true; }
            return n;
        }

        void ReplaceOne()
        {
            var q = _find.Text; if (string.IsNullOrEmpty(q)) return;
            if (_lastSlide >= 0 && _lastSlide < _p.Slides.Count && _lastShape >= 0 && _lastShape < _p.Slides[_lastSlide].Shapes.Count)
            {
                _beforeChange();
                if (ReplaceIn(_p.Slides[_lastSlide].Shapes[_lastShape], q, _repl.Text, true) > 0) { _changed("Замена"); _status.Text = "Заменено 1 вхождение."; }
            }
            FindNext();
        }

        void ReplaceAll()
        {
            var q = _find.Text; if (string.IsNullOrEmpty(q)) return;
            _beforeChange();
            int n = 0;
            foreach (var sl in _p.Slides)
            {
                foreach (var s in sl.Shapes) n += ReplaceIn(s, q, _repl.Text, false);
                if (!string.IsNullOrEmpty(sl.Notes) && sl.Notes.IndexOf(q, Cmp) >= 0)
                {
                    int i; var t = sl.Notes; int guard = 0;
                    while ((i = t.IndexOf(q, Cmp)) >= 0 && guard++ < 10000) { t = t.Substring(0, i) + _repl.Text + t.Substring(i + q.Length); n++; if (_repl.Text.IndexOf(q, Cmp) >= 0) break; }
                    sl.Notes = t; sl.NotesDirty = true;
                }
            }
            if (n > 0) _changed("Замена");
            _status.Text = "Заменено вхождений: " + n + ".";
        }
    }
}
