// Диалоги: цвет, градиент, размер таблицы, редактор ячеек таблицы.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using SlideNova.Core;

namespace SlideNova
{
    public static class ColorPicker
    {
        static readonly int[] Palette =
        {
            0x000000,0x262626,0x404040,0x595959,0x7F7F7F,0xA6A6A6,0xBFBFBF,0xD9D9D9,0xF2F2F2,0xFFFFFF,
            0x7F0000,0xC00000,0xFF0000,0xFF6B6B,0xFF7E5F,0xFFA500,0xFFC000,0xFFE066,0xFFFF00,0xFFF7B3,
            0x0B3D2E,0x00703C,0x00B050,0x2ECC71,0x92D050,0xA8E063,0xC6FF00,0x00FFA3,0x00E5A0,0x23C1A6,
            0x002060,0x0070C0,0x0072FF,0x00B0F0,0x00C6FF,0x00F0FF,0x3BB4F2,0x5B9BD5,0x8EA9DB,0xBDD7EE,
            0x3A0CA3,0x7030A0,0x8E2DE2,0x8E5CF6,0xA15CF6,0xB57BFF,0xE040FB,0xFF2BD6,0xFF2E7E,0xF2709C,
        };

        public static Rgba? Show(Rgba initial, List<Rgba> theme, string title = "Выбор цвета")
        {
            Rgba cur = initial; Rgba? result = null;
            var w = new ThemedWindow { Title = title, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize };
            var root = new StackPanel { Margin = new Thickness(18) };
            var preview = new Border { Width = 120, Height = 56, CornerRadius = new CornerRadius(8), BorderThickness = new Thickness(1), BorderBrush = Brushes.Gray };
            var hex = Ui.Input(cur.Hex, 110);
            Slider sr = null, sg = null, sb = null, sa = null; bool lockUpd = false;
            Action upd = () =>
            {
                lockUpd = true;
                preview.Background = new SolidColorBrush(Px.C(cur));
                hex.Text = cur.Hex;
                if (sr != null) { sr.Value = cur.R; sg.Value = cur.G; sb.Value = cur.B; sa.Value = Math.Round(cur.A / 2.55); }
                lockUpd = false;
            };
            if (theme != null && theme.Count > 0)
            {
                root.Children.Add(Ui.Text("Цвета темы презентации", 12, true, "B.SubText"));
                var tw = new WrapPanel { Margin = new Thickness(0, 4, 0, 10) };
                foreach (var c in theme)
                    foreach (var f in new[] { 1.0, 1.6, 1.3, 0.75, 0.5 })
                    {
                        var col = Px.R(Px.Shade(Px.C(c), f));
                        var b = new FancyButton { Content = Ui.Swatch(Px.C(col), 18, false), Padding = new Thickness(1), Margin = new Thickness(1), Flat = true, ToolTip = "#" + col.Hex };
                        b.Click += (s, e) => { cur = col; upd(); };
                        tw.Children.Add(b);
                    }
                tw.MaxWidth = 420;
                root.Children.Add(tw);
            }
            root.Children.Add(Ui.Text("Палитра", 12, true, "B.SubText"));
            var pw = new WrapPanel { MaxWidth = 420, Margin = new Thickness(0, 4, 0, 10) };
            foreach (var p in Palette)
            {
                var col = Rgba.FromRgb(p);
                var b = new FancyButton { Content = Ui.Swatch(Px.C(col), 22, false), Padding = new Thickness(1), Margin = new Thickness(1), Flat = true, ToolTip = "#" + col.Hex };
                b.Click += (s, e) => { cur = col; upd(); };
                b.MouseDoubleClick += (s, e) => { cur = col; result = cur; w.Close(); };
                pw.Children.Add(b);
            }
            root.Children.Add(pw);
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); grid.ColumnDefinitions.Add(new ColumnDefinition());
            var left = Ui.Column(preview, Ui.Spacer(4)); left.Margin = new Thickness(0, 0, 16, 0);
            var hexRow = Ui.Row(Ui.Text("#", 13, true), Ui.Spacer(4), hex); hexRow.Margin = new Thickness(0, 8, 0, 0);
            left.Children.Add(hexRow);
            hex.TextChanged += (s, e) => { if (!lockUpd && Rgba.TryParseHex(hex.Text, out var c)) { cur = c.WithAlpha(cur.A); preview.Background = new SolidColorBrush(Px.C(cur)); } };
            Grid.SetColumn(left, 0); grid.Children.Add(left);
            var sliders = new StackPanel();
            Slider S(string label, double max, Action<double> set)
            {
                var sl = Ui.Slider(0, max, 0, v => { if (!lockUpd) { set(v); lockUpd = true; preview.Background = new SolidColorBrush(Px.C(cur)); hex.Text = cur.Hex; lockUpd = false; } }, 220);
                var row = Ui.Row(Ui.Text(label, 12, false, "B.SubText"), Ui.Spacer(6), sl); ((TextBlock)row.Children[0]).Width = 96;
                sliders.Children.Add(row);
                return sl;
            }
            sr = S("Красный", 255, v => cur = new Rgba(cur.A, (byte)v, cur.G, cur.B));
            sg = S("Зелёный", 255, v => cur = new Rgba(cur.A, cur.R, (byte)v, cur.B));
            sb = S("Синий", 255, v => cur = new Rgba(cur.A, cur.R, cur.G, (byte)v));
            sa = S("Непрозрачность %", 100, v => cur = cur.WithAlpha((byte)Math.Round(v * 2.55)));
            Grid.SetColumn(sliders, 1); grid.Children.Add(sliders);
            root.Children.Add(grid);
            var btns = Ui.Row(Ui.Action("Применить", () => { result = cur; w.Close(); }, true), Ui.Action("Отмена", () => w.Close()));
            btns.HorizontalAlignment = HorizontalAlignment.Right; btns.Margin = new Thickness(0, 14, 0, 0);
            root.Children.Add(btns);
            w.Content = root;
            upd();
            w.ShowDialog();
            return result;
        }
    }

    public static class GradientDialog
    {
        public static FillDef Show(FillDef initial, List<Rgba> theme)
        {
            var g = initial?.Clone() ?? FillDef.Gradient(theme != null && theme.Count > 4 ? theme[4] : Rgba.FromRgb(0x00C6FF), theme != null && theme.Count > 5 ? theme[5] : Rgba.FromRgb(0x0072FF), 90);
            if (g.Stops.Count < 2) g = FillDef.Gradient(Rgba.FromRgb(0x00C6FF), Rgba.FromRgb(0x0072FF), 90);
            FillDef result = null;
            var w = new ThemedWindow { Title = "Градиентная заливка", SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize };
            var root = new StackPanel { Margin = new Thickness(18), Width = 460 };
            var preview = new Border { Height = 110, CornerRadius = new CornerRadius(10), Margin = new Thickness(0, 0, 0, 12) };
            var stopsPanel = new StackPanel();
            Action refresh = null;
            refresh = () =>
            {
                var r = new SlideRenderer(new PresentationModel(), new ImageCache(new PresentationModel()));
                preview.Background = r.FillBrush(g, 1);
                stopsPanel.Children.Clear();
                for (int i = 0; i < g.Stops.Count; i++)
                {
                    var st = g.Stops[i]; int idx = i;
                    var sw = new FancyButton { Content = Ui.Swatch(Px.C(st.Color), 22, false), Padding = new Thickness(2), Flat = true };
                    sw.Click += (s, e) => { var c = ColorPicker.Show(st.Color, theme, "Цвет точки градиента"); if (c.HasValue) { st.Color = c.Value; refresh(); } };
                    var pos = Ui.Slider(0, 100, st.Pos * 100, v => { st.Pos = v / 100; preview.Background = r.FillBrush(g, 1); }, 220);
                    var del = Ui.Small("", null, "Удалить точку", "Убрать эту точку градиента.", () => { if (g.Stops.Count > 2) { g.Stops.RemoveAt(idx); refresh(); } });
                    var row = Ui.Row(sw, Ui.Spacer(8), Ui.Text("Позиция", 12, false, "B.SubText"), Ui.Spacer(6), pos, del);
                    row.Margin = new Thickness(0, 2, 0, 2);
                    stopsPanel.Children.Add(row);
                }
            };
            root.Children.Add(preview);
            var presets = new WrapPanel { Margin = new Thickness(0, 0, 0, 10) };
            var named = new[] { ("Неон", 0x00F0FF, 0xFF2BD6), ("Закат", 0xFF7E5F, 0xFEB47B), ("Океан", 0x0072FF, 0x00C6FF), ("Аврора", 0x00E5A0, 0x00B3FF), ("Лаванда", 0x8E2DE2, 0xE040FB), ("Лайм", 0xC6FF00, 0x00FFA3), ("Ночь", 0x0F0C29, 0x302B63), ("Персик", 0xFF6A3D, 0xFF2E7E) };
            foreach (var n in named)
            {
                var a = Rgba.FromRgb(n.Item2); var b = Rgba.FromRgb(n.Item3);
                var btn = new FancyButton { Content = new Border { Width = 46, Height = 22, CornerRadius = new CornerRadius(5), Background = new LinearGradientBrush(Px.C(a), Px.C(b), 0) }, Padding = new Thickness(2), Margin = new Thickness(1), Flat = true };
                Ui.Tip(btn, "Готовый градиент «" + n.Item1 + "»", null);
                btn.Click += (s, e) => { g.Stops = new List<GradStop> { new GradStop(0, a), new GradStop(1, b) }; refresh(); };
                presets.Children.Add(btn);
            }
            root.Children.Add(Ui.Text("Готовые градиенты", 12, true, "B.SubText"));
            root.Children.Add(presets);
            root.Children.Add(Ui.Text("Точки градиента", 12, true, "B.SubText"));
            root.Children.Add(stopsPanel);
            root.Children.Add(Ui.Action("Добавить точку", () => { g.Stops.Add(new GradStop(0.5, Rgba.White)); g.Stops = g.Stops.OrderBy(s => s.Pos).ToList(); refresh(); }, false, ""));
            var ang = Ui.Slider(0, 359, g.Angle, v => { g.Angle = v; refresh(); }, 260);
            var radial = Ui.Check("Радиальный (от центра)", g.Radial, v => { g.Radial = v; refresh(); }, "Радиальный градиент", "Цвета расходятся кругами от центра фигуры.");
            var angRow = Ui.Row(Ui.Text("Угол, °", 12, false, "B.SubText"), Ui.Spacer(8), ang); angRow.Margin = new Thickness(0, 8, 0, 0);
            root.Children.Add(angRow); root.Children.Add(radial);
            var btns = Ui.Row(Ui.Action("Применить", () => { g.Stops = g.Stops.OrderBy(s => s.Pos).ToList(); result = g; w.Close(); }, true), Ui.Action("Отмена", () => w.Close()));
            btns.HorizontalAlignment = HorizontalAlignment.Right; btns.Margin = new Thickness(0, 12, 0, 0);
            root.Children.Add(btns);
            w.Content = root;
            refresh();
            w.ShowDialog();
            return result;
        }
    }

    public static class TableDialog
    {
        public static Tuple<int, int> Show()
        {
            Tuple<int, int> result = null;
            var w = new ThemedWindow { Title = "Вставка таблицы", SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize };
            var root = new StackPanel { Margin = new Thickness(18) };
            root.Children.Add(Ui.Text("Наведите на сетку и щёлкните, либо укажите размер вручную.", 12.5, false, "B.SubText", true));
            var grid = new UniformGrid { Rows = 8, Columns = 10, Margin = new Thickness(0, 10, 0, 10) };
            var label = Ui.Text("1 × 1", 13, true);
            int rows = 3, cols = 4;
            var cells = new List<Border>();
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 10; c++)
                {
                    int rr = r + 1, cc = c + 1;
                    var b = new Border { Width = 24, Height = 20, Margin = new Thickness(1.5), CornerRadius = new CornerRadius(3), BorderThickness = new Thickness(1) };
                    b.SetResourceReference(Border.BorderBrushProperty, "B.Border");
                    b.SetResourceReference(Border.BackgroundProperty, "B.Panel2");
                    b.Tag = new[] { rr, cc };
                    b.MouseEnter += (s, e) =>
                    {
                        label.Text = rr + " × " + cc + " (строк × столбцов)";
                        foreach (var x in cells) { var t = (int[])x.Tag; if (t[0] <= rr && t[1] <= cc) x.SetResourceReference(Border.BackgroundProperty, "B.AccentSolid"); else x.SetResourceReference(Border.BackgroundProperty, "B.Panel2"); }
                    };
                    b.MouseLeftButtonUp += (s, e) => { result = Tuple.Create(rr, cc); w.Close(); };
                    b.Cursor = Cursors.Hand;
                    cells.Add(b); grid.Children.Add(b);
                }
            root.Children.Add(grid);
            root.Children.Add(label);
            var rb = Ui.Number(rows, 1, v => rows = (int)Units.Clamp(v, 1, 100), "0", 60);
            var cb = Ui.Number(cols, 1, v => cols = (int)Units.Clamp(v, 1, 50), "0", 60);
            var row = Ui.Row(Ui.Text("Строк:", 12.5), Ui.Spacer(6), rb, Ui.Spacer(14), Ui.Text("Столбцов:", 12.5), Ui.Spacer(6), cb);
            row.Margin = new Thickness(0, 12, 0, 0);
            root.Children.Add(row);
            var btns = Ui.Row(Ui.Action("Вставить", () => { result = Tuple.Create(rows, cols); w.Close(); }, true), Ui.Action("Отмена", () => w.Close()));
            btns.HorizontalAlignment = HorizontalAlignment.Right; btns.Margin = new Thickness(0, 14, 0, 0);
            root.Children.Add(btns);
            w.Content = root;
            w.ShowDialog();
            return result;
        }

        /// <summary>Редактор содержимого и структуры таблицы.</summary>
        public static bool Edit(ShapeModel shape, Rgba defaultText, string font)
        {
            var t = shape.Table.Clone();
            bool ok = false;
            var w = new ThemedWindow { Title = "Редактирование таблицы", Width = 860, Height = 560, ResizeMode = ResizeMode.CanResize };
            var dock = new DockPanel { Margin = new Thickness(14) };
            var gridHost = new ScrollViewer { HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            Action rebuild = null;
            rebuild = () =>
            {
                var g = new Grid();
                for (int c = 0; c < t.ColWidths.Count; c++) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Math.Max(110, Math.Min(260, t.ColWidths[c] / 9525 * 0.9))) });
                for (int r = 0; r < t.Rows.Count; r++)
                {
                    g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                    for (int c = 0; c < t.ColWidths.Count && c < t.Rows[r].Count; c++)
                    {
                        var cell = t.Rows[r][c];
                        var tb = Ui.Input(cell.Text.PlainText); tb.AcceptsReturn = true; tb.TextWrapping = TextWrapping.Wrap; tb.MinHeight = 34; tb.Margin = new Thickness(2);
                        if (r == 0 && t.FirstRow) tb.FontWeight = FontWeights.SemiBold;
                        if (cell.HMerge || cell.VMerge) { tb.IsEnabled = false; tb.Text = "(объединена)"; }
                        tb.TextChanged += (s, e) =>
                        {
                            var lv = cell.Text.Levels[0];
                            var first = cell.Text.Paras.FirstOrDefault()?.Runs.FirstOrDefault(x => !x.IsBreak);
                            var paras = new List<ParaModel>();
                            foreach (var line in tb.Text.Replace("\r\n", "\n").Split('\n'))
                            {
                                var p = new ParaModel { Align = cell.Text.Paras.FirstOrDefault()?.Align };
                                var run = first != null ? first.Clone() : new RunModel(); run.Text = line; run.IsBreak = false;
                                p.Runs.Add(run); paras.Add(p);
                            }
                            cell.Text.Paras = paras;
                        };
                        Grid.SetRow(tb, r); Grid.SetColumn(tb, c);
                        g.Children.Add(tb);
                    }
                }
                gridHost.Content = g;
            };
            LevelStyle Lv() => new LevelStyle { SizePt = 18, Font = font, Color = defaultText };
            var tools = Ui.Row(
                Ui.Small("", "Строка", "Добавить строку", "Добавить строку в конец таблицы.", () => { var row = new List<TableCell>(); for (int c = 0; c < t.ColWidths.Count; c++) row.Add(new TableCell { Text = TextBodyModel.FromPlain("", Lv()) }); t.Rows.Add(row); t.RowHeights.Add(t.RowHeights.LastOrDefault() > 0 ? t.RowHeights.Last() : 370840); rebuild(); }),
                Ui.Small("", "Столбец", "Добавить столбец", "Добавить столбец справа.", () => { double cw = t.ColWidths.LastOrDefault() > 0 ? t.ColWidths.Last() : 1828800; t.ColWidths.Add(cw); foreach (var r in t.Rows) r.Add(new TableCell { Text = TextBodyModel.FromPlain("", Lv()) }); rebuild(); }),
                Ui.Small("", "Строка", "Удалить последнюю строку", "Убрать нижнюю строку.", () => { if (t.Rows.Count > 1) { t.Rows.RemoveAt(t.Rows.Count - 1); t.RowHeights.RemoveAt(t.RowHeights.Count - 1); rebuild(); } }),
                Ui.Small("", "Столбец", "Удалить последний столбец", "Убрать правый столбец.", () => { if (t.ColWidths.Count > 1) { t.ColWidths.RemoveAt(t.ColWidths.Count - 1); foreach (var r in t.Rows) if (r.Count > t.ColWidths.Count) r.RemoveAt(r.Count - 1); rebuild(); } }),
                Ui.Check("Строка заголовка", t.FirstRow, v => { t.FirstRow = v; }, "Строка заголовка", "Выделить первую строку цветом темы."),
                Ui.Spacer(10),
                Ui.Check("Чередование строк", t.BandRow, v => { t.BandRow = v; }, "Чередование", "Полосатая заливка строк для удобства чтения."));
            tools.Margin = new Thickness(0, 0, 0, 10);
            DockPanel.SetDock(tools, Dock.Top); dock.Children.Add(tools);
            var btns = Ui.Row(Ui.Action("Применить", () => { ok = true; w.Close(); }, true), Ui.Action("Отмена", () => w.Close()));
            btns.HorizontalAlignment = HorizontalAlignment.Right; btns.Margin = new Thickness(0, 10, 0, 0);
            DockPanel.SetDock(btns, Dock.Bottom); dock.Children.Add(btns);
            dock.Children.Add(gridHost);
            w.Content = dock;
            rebuild();
            w.ShowDialog();
            if (ok)
            {
                double oldW = shape.Table.ColWidths.Sum();
                shape.Table = t;
                double newW = t.ColWidths.Sum();
                if (Math.Abs(newW - oldW) > 1) shape.W = newW;
                shape.H = t.RowHeights.Sum();
                shape.DirtyTable = true; shape.DirtyXfrm = true;
            }
            return ok;
        }
    }
}
