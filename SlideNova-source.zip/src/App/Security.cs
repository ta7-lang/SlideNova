// Безопасность: метка «из Интернета», атомарная запись без временного мусора, безопасные ссылки.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using Microsoft.Win32.SafeHandles;

namespace SlideNova
{
    public static class Security
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern SafeFileHandle CreateFileW(string name, uint access, uint share, IntPtr sa, uint disp, uint flags, IntPtr tmpl);

        /// <summary>Зона безопасности файла (Mark-of-the-Web): 0-локальный ... 3-Интернет, 4-ограниченные. -1 — метки нет.</summary>
        public static int ZoneOf(string path)
        {
            try
            {
                using (var h = CreateFileW(path + ":Zone.Identifier", 0x80000000, 1 | 2 | 4, IntPtr.Zero, 3, 0, IntPtr.Zero))
                {
                    if (h.IsInvalid) return -1;
                    using (var fs = new FileStream(h, FileAccess.Read))
                    {
                        if (fs.Length > 64 * 1024) return 3;
                        using (var r = new StreamReader(fs))
                        {
                            string line;
                            while ((line = r.ReadLine()) != null)
                            {
                                line = line.Trim();
                                if (line.StartsWith("ZoneId=", StringComparison.OrdinalIgnoreCase) && int.TryParse(line.Substring(7), out int z)) return z;
                            }
                        }
                    }
                }
            }
            catch { }
            return -1;
        }

        /// <summary>Запись через временный файл в той же папке и атомарную замену; временный файл удаляется при любой ошибке.</summary>
        public static void AtomicWrite(string path, byte[] data)
        {
            var dir = Path.GetDirectoryName(Path.GetFullPath(path)) ?? ".";
            var tmp = Path.Combine(dir, "~sn" + Guid.NewGuid().ToString("N").Substring(0, 10) + ".tmp");
            try
            {
                using (var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, FileOptions.WriteThrough))
                {
                    fs.Write(data, 0, data.Length);
                    fs.Flush(true);
                }
                try { File.SetAttributes(tmp, FileAttributes.Normal); } catch { }
                if (File.Exists(path))
                {
                    var attrs = File.GetAttributes(path);
                    if ((attrs & FileAttributes.ReadOnly) != 0) throw new UnauthorizedAccessException("Файл доступен только для чтения.");
                    File.Replace(tmp, path, null, true);
                }
                else File.Move(tmp, path);
            }
            finally
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            }
        }

        public static bool IsSafeUrl(string url, out string reason)
        {
            reason = null;
            if (!Uri.TryCreate(url ?? "", UriKind.Absolute, out var u)) { reason = "Адрес некорректен или является относительной ссылкой на файл."; return false; }
            if (u.Scheme == Uri.UriSchemeHttps || u.Scheme == Uri.UriSchemeHttp || u.Scheme == Uri.UriSchemeMailto) return true;
            reason = "Схема «" + u.Scheme + ":» заблокирована (разрешены только http, https и mailto). Ссылки на файлы, программы и сценарии не открываются.";
            return false;
        }

        /// <summary>Безопасное открытие гиперссылки: только http/https/mailto, с подтверждением.</summary>
        public static void OpenLink(string url)
        {
            if (!IsSafeUrl(url, out var why)) { Dialogs.Error("Ссылка заблокирована", url + "\n\n" + why); return; }
            if (Hardening.ChildProcessesBlocked)
            {
                try { Clipboard.SetText(url); } catch { }
                Dialogs.Info("Ссылка скопирована", "Включён строгий режим защиты: программа не запускает другие приложения.\n\nАдрес скопирован в буфер обмена — вставьте его в браузер:\n" + url);
                return;
            }
            if (AppSettings.Current.ConfirmLinks && Dialogs.Ask("Открыть ссылку?", "Будет открыт внешний адрес:\n\n" + url + "\n\nОткрывайте только ссылки, которым доверяете.", "Открыть", "Отмена") != true) return;
            try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
            catch (Exception ex) { Dialogs.Error("Не удалось открыть ссылку", ex.Message); }
        }
    }
}
