// Темы оформления: градиенты, акцентные цвета, скругления. Переключаются «на лету».
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;

namespace SlideNova
{
    public sealed class AppTheme
    {
        public string Name;
        public bool Dark;
        public Color Bg1, Bg2, Panel, Panel2, Text, Accent1, Accent2, Canvas;
        public double Radius = 10;
        public string Description = "";

        public static Color C(string hex) => (Color)ColorConverter.ConvertFromString(hex);

        public static AppTheme Make(string name, bool dark, string bg1, string bg2, string panel, string panel2, string text, string a1, string a2, string canvas, double radius, string desc)
            => new AppTheme { Name = name, Dark = dark, Bg1 = C(bg1), Bg2 = C(bg2), Panel = C(panel), Panel2 = C(panel2), Text = C(text), Accent1 = C(a1), Accent2 = C(a2), Canvas = C(canvas), Radius = radius, Description = desc };

        public static AppTheme FromCustom(CustomThemeData d)
        {
            try { return Make(d.Name ?? "Моя тема", d.Dark, d.Bg1, d.Bg2, d.Panel, d.Panel2, d.Text, d.Accent1, d.Accent2, d.Canvas, d.Radius, "Пользовательская тема"); }
            catch { return ThemeManager.Builtins[0]; }
        }
    }

    public static class ThemeManager
    {
        public static readonly List<AppTheme> Builtins = new List<AppTheme>
        {
            AppTheme.Make("Неоновая ночь", true, "#0F0C29", "#302B63", "#1A1736", "#262250", "#F1EEFF", "#00F0FF", "#FF2BD6", "#0B0920", 12, "Тёмная тема с неоновыми бирюзово-розовыми акцентами"),
            AppTheme.Make("Кибер-лайм", true, "#0A0A0F", "#1A1A2E", "#15151F", "#22222F", "#EFFFF0", "#C6FF00", "#00FFA3", "#07070B", 8, "Контрастная тёмная тема с кислотно-зелёным неоном"),
            AppTheme.Make("Аврора", true, "#06202A", "#123B3F", "#0E2A33", "#163944", "#E6FFFB", "#00E5A0", "#00B3FF", "#051A21", 14, "Северное сияние: изумрудные и голубые переливы"),
            AppTheme.Make("Закат", true, "#2B1331", "#4A1C2E", "#341A33", "#45213F", "#FFF1EA", "#FF7E5F", "#FEB47B", "#200E24", 14, "Тёплые закатные тона: коралл и персик"),
            AppTheme.Make("Графит", true, "#18191C", "#2B2D31", "#202226", "#2C2F35", "#ECEDEF", "#5865F2", "#A15CF6", "#121316", 8, "Сдержанная тёмная тема для долгой работы"),
            AppTheme.Make("Изумруд", true, "#04201A", "#0B3D2E", "#0A2A22", "#11392E", "#E9FFF5", "#2ECC71", "#A8E063", "#03170F", 12, "Глубокий зелёный с травяным градиентом"),
            AppTheme.Make("Океан", false, "#E0F7FA", "#E3EEFD", "#F7FBFF", "#E6EFFA", "#0D2236", "#0072FF", "#00C6FF", "#D3E2F2", 12, "Светлая свежая тема в синих тонах"),
            AppTheme.Make("Лаванда", false, "#F3E8FF", "#FCE7F3", "#FFFBFF", "#F1E6FA", "#2A1838", "#8E2DE2", "#E040FB", "#E6D9F2", 16, "Нежная светлая тема с фиолетово-розовым градиентом"),
            AppTheme.Make("Светлая классика", false, "#F4F6FB", "#FFFFFF", "#FFFFFF", "#EEF1F7", "#1B2333", "#2563EB", "#7C3AED", "#E2E7F0", 8, "Нейтральная светлая тема"),
            AppTheme.Make("Персик", false, "#FFF3E6", "#FFE4EC", "#FFFAF6", "#FCEDE3", "#3A2117", "#FF6A3D", "#FF2E7E", "#F2DED3", 16, "Светлая тёплая тема с энергичными акцентами"),
        };

        public static AppTheme Current { get; private set; } = Builtins[0];
        public static event Action Changed;
        static Application _app;

        public static IEnumerable<AppTheme> All()
        {
            foreach (var t in Builtins) yield return t;
            yield return AppTheme.FromCustom(AppSettings.Current.Custom);
        }

        public static void Init(Application app, AppSettings s)
        {
            _app = app;
            var t = s.ThemeName == "@custom" ? AppTheme.FromCustom(s.Custom) : Builtins.FirstOrDefault(x => x.Name == s.ThemeName) ?? Builtins[0];
            Apply(t);
        }

        static SolidColorBrush S(Color c) { var b = new SolidColorBrush(c); b.Freeze(); return b; }
        static Color A(Color c, byte a) => Color.FromArgb(a, c.R, c.G, c.B);
        public static Color Mix(Color a, Color b, double t) => Color.FromArgb((byte)(a.A + (b.A - a.A) * t), (byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));
        static double Lum(Color c) => (0.2126 * c.R + 0.7152 * c.G + 0.0722 * c.B) / 255.0;

        public static void Apply(AppTheme t)
        {
            Current = t;
            var r = _app.Resources;
            bool glass = AppSettings.Current.GlassPanels;
            var winBg = new LinearGradientBrush(t.Bg1, t.Bg2, new Point(0, 0), new Point(1, 1)); winBg.Freeze();
            r["B.WindowBg"] = winBg;
            var accent = new LinearGradientBrush(t.Accent1, t.Accent2, new Point(0, 0), new Point(1, 1)); accent.Freeze();
            r["B.Accent"] = accent;
            var accentH = new LinearGradientBrush(t.Accent1, t.Accent2, new Point(0, 0.5), new Point(1, 0.5)); accentH.Freeze();
            r["B.AccentH"] = accentH;
            r["B.AccentSolid"] = S(t.Accent1);
            r["B.Accent2Solid"] = S(t.Accent2);
            r["B.AccentSoft"] = S(A(t.Accent1, 60));
            r["B.Panel"] = S(glass ? A(t.Panel, 215) : t.Panel);
            r["B.PanelSolid"] = S(t.Panel);
            r["B.Panel2"] = S(t.Panel2);
            var header = new LinearGradientBrush(new GradientStopCollection { new GradientStop(A(t.Panel, glass ? (byte)200 : (byte)255), 0), new GradientStop(A(Mix(t.Panel, t.Accent1, 0.12), glass ? (byte)200 : (byte)255), 0.55), new GradientStop(A(Mix(t.Panel, t.Accent2, 0.12), glass ? (byte)200 : (byte)255), 1) }, new Point(0, 0), new Point(1, 0));
            header.Freeze();
            r["B.Header"] = header;
            r["B.Text"] = S(t.Text);
            r["B.SubText"] = S(A(t.Text, 165));
            r["B.Faint"] = S(A(t.Text, 90));
            r["B.Border"] = S(A(t.Text, t.Dark ? (byte)38 : (byte)45));
            r["B.Button"] = S(A(t.Panel2, 230));
            r["B.ButtonHover"] = S(Mix(t.Panel2, t.Accent1, t.Dark ? 0.22 : 0.15));
            r["B.ButtonPress"] = S(Mix(t.Panel2, t.Accent1, 0.40));
            r["B.Input"] = S(t.Dark ? Mix(t.Panel, Colors.Black, 0.25) : Colors.White);
            var canvas = new RadialGradientBrush(Mix(t.Canvas, t.Accent1, t.Dark ? 0.08 : 0.05), t.Canvas); canvas.Freeze();
            r["B.Canvas"] = canvas;
            r["B.Selection"] = S(t.Accent1);
            r["B.OnAccent"] = S(Lum(Mix(t.Accent1, t.Accent2, 0.5)) > 0.6 ? Color.FromRgb(20, 20, 30) : Colors.White);
            r["B.Shadow"] = S(t.Dark ? Colors.Black : Color.FromRgb(90, 100, 130));
            r["R.Corner"] = new CornerRadius(t.Radius);
            r["R.CornerSmall"] = new CornerRadius(Math.Max(2, t.Radius / 2));
            r["C.Accent1"] = t.Accent1;
            r["C.Shadow"] = t.Dark ? Colors.Black : Color.FromRgb(90, 100, 130);
            foreach (Window w in _app.Windows) ApplyTitleBar(w);
            Changed?.Invoke();
        }

        public static Brush Brush(string key) => (_app?.Resources[key] as Brush) ?? Brushes.Gray;

        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        public static void ApplyTitleBar(Window w)
        {
            try
            {
                var h = new WindowInteropHelper(w).Handle;
                if (h == IntPtr.Zero) return;
                int dark = Current.Dark ? 1 : 0;
                DwmSetWindowAttribute(h, 20, ref dark, 4);
                int corner = 2; DwmSetWindowAttribute(h, 33, ref corner, 4);
                var c = Current.Panel; int cap = c.R | (c.G << 8) | (c.B << 16);
                DwmSetWindowAttribute(h, 35, ref cap, 4); // цвет заголовка (Windows 11)
                var tc = Current.Text; int txt = tc.R | (tc.G << 8) | (tc.B << 16);
                DwmSetWindowAttribute(h, 36, ref txt, 4);
            }
            catch { }
        }
    }
}
