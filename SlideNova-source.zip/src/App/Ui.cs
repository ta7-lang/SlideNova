// Элементы интерфейса: красивые кнопки, подсказки с пояснениями, всплывающие списки, окна-диалоги.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace SlideNova
{
    /// <summary>Кнопка с градиентной подсветкой, иконкой и подписью.</summary>
    public class FancyButton : Button
    {
        Border _bd;
        bool _hover;
        public bool IsAccent { get; set; }
        bool _toggled;
        public bool IsToggled { get => _toggled; set { _toggled = value; UpdateVisual(); } }
        public bool Flat { get; set; }

        static ControlTemplate _tpl;
        static ControlTemplate Tpl()
        {
            if (_tpl != null) return _tpl;
            var bd = new FrameworkElementFactory(typeof(Border), "bd");
            bd.SetValue(Border.PaddingProperty, new TemplateBindingExtension(PaddingProperty));
            bd.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(BorderThicknessProperty));
            bd.SetValue(Border.SnapsToDevicePixelsProperty, true);
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, new TemplateBindingExtension(HorizontalContentAlignmentProperty));
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, new TemplateBindingExtension(VerticalContentAlignmentProperty));
            cp.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
            bd.AppendChild(cp);
            _tpl = new ControlTemplate(typeof(Button)) { VisualTree = bd };
            return _tpl;
        }

        public FancyButton()
        {
            Template = Tpl();
            Padding = new Thickness(8, 4, 8, 4);
            BorderThickness = new Thickness(1);
            Cursor = Cursors.Hand;
            FocusVisualStyle = null;
            HorizontalContentAlignment = HorizontalAlignment.Center;
            VerticalContentAlignment = VerticalAlignment.Center;
            SetResourceReference(ForegroundProperty, "B.Text");
            IsEnabledChanged += (s, e) => Opacity = IsEnabled ? 1 : 0.42;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _bd = GetTemplateChild("bd") as Border;
            if (_bd != null) _bd.SetResourceReference(Border.CornerRadiusProperty, "R.CornerSmall");
            UpdateVisual();
        }

        protected override void OnMouseEnter(MouseEventArgs e) { base.OnMouseEnter(e); _hover = true; UpdateVisual(); }
        protected override void OnMouseLeave(MouseEventArgs e) { base.OnMouseLeave(e); _hover = false; UpdateVisual(); }
        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (e.Property == IsPressedProperty || e.Property == IsKeyboardFocusedProperty) UpdateVisual();
        }

        void UpdateVisual()
        {
            if (_bd == null) return;
            string bg = IsAccent || IsToggled ? "B.Accent" : IsPressed ? "B.ButtonPress" : _hover ? "B.ButtonHover" : Flat ? null : "B.Button";
            if (bg == null) _bd.Background = Brushes.Transparent; else _bd.SetResourceReference(Border.BackgroundProperty, bg);
            if ((IsAccent || IsToggled) && _hover) _bd.Opacity = 0.88; else _bd.Opacity = 1;
            _bd.SetResourceReference(Border.BorderBrushProperty, IsKeyboardFocused ? "B.AccentSolid" : (Flat && !_hover ? "B.Transparent" : "B.Border"));
            if (Flat && !_hover && !IsKeyboardFocused) _bd.BorderBrush = Brushes.Transparent;
            if (IsAccent || IsToggled) SetResourceReference(ForegroundProperty, "B.OnAccent"); else SetResourceReference(ForegroundProperty, "B.Text");
        }
    }

    public static class Ui
    {
        public static readonly FontFamily IconFont = new FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets, Segoe UI Symbol");
        public static readonly FontFamily UiFont = new FontFamily("Segoe UI Variable Text, Segoe UI");
        public static event Action<string> Hint;

        public static TextBlock Icon(string glyph, double size = 16)
        {
            var t = new TextBlock { Text = glyph, FontSize = size, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Center };
            t.FontFamily = glyph.Length == 1 && glyph[0] >= 0xE000 && glyph[0] <= 0xF8FF ? IconFont : new FontFamily("Segoe UI Symbol, Segoe UI");
            return t;
        }

        public static TextBlock Text(string s, double size = 13, bool bold = false, string brush = "B.Text", bool wrap = false)
        {
            var t = new TextBlock { Text = s, FontSize = size, FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal, VerticalAlignment = VerticalAlignment.Center };
            if (wrap) t.TextWrapping = TextWrapping.Wrap;
            t.SetResourceReference(TextBlock.ForegroundProperty, brush);
            return t;
        }

        /// <summary>Подсказка-пояснение: заголовок, описание, сочетание клавиш.</summary>
        public static void Tip(FrameworkElement el, string title, string text, string keys = null)
        {
            var sp = new StackPanel { MaxWidth = 320 };
            sp.Children.Add(Text(title, 13.5, true));
            if (!string.IsNullOrEmpty(text)) { var d = Text(text, 12.5, false, "B.SubText", true); d.Margin = new Thickness(0, 4, 0, 0); sp.Children.Add(d); }
            if (!string.IsNullOrEmpty(keys))
            {
                var kb = new Border { CornerRadius = new CornerRadius(4), Padding = new Thickness(6, 1, 6, 2), Margin = new Thickness(0, 6, 0, 0), HorizontalAlignment = HorizontalAlignment.Left, Child = Text(keys, 11.5, true) };
                kb.SetResourceReference(Border.BackgroundProperty, "B.Panel2");
                sp.Children.Add(kb);
            }
            var tip = new ToolTip { Content = sp, Padding = new Thickness(12, 9, 12, 10), HasDropShadow = true };
            tip.SetResourceReference(Control.BackgroundProperty, "B.PanelSolid");
            tip.SetResourceReference(Control.BorderBrushProperty, "B.AccentSolid");
            tip.SetResourceReference(Control.ForegroundProperty, "B.Text");
            el.ToolTip = tip;
            ToolTipService.SetInitialShowDelay(el, 350);
            ToolTipService.SetShowDuration(el, 30000);
            ToolTipService.SetShowOnDisabled(el, true);
            el.MouseEnter += (s, e) => Hint?.Invoke(title + (string.IsNullOrEmpty(text) ? "" : " — " + text));
            el.MouseLeave += (s, e) => Hint?.Invoke(null);
        }

        /// <summary>Крупная кнопка ленты: иконка над подписью.</summary>
        public static FancyButton Big(string glyph, string label, string title, string text, Action click, string keys = null)
        {
            var sp = new StackPanel { MinWidth = 52 };
            var ic = string.IsNullOrEmpty(glyph) ? new TextBlock { Text = "", FontSize = 20, Height = 26 } : Icon(glyph, 20); ic.Margin = new Thickness(0, 2, 0, 3);
            sp.Children.Add(ic);
            sp.Children.Add(new TextBlock { Text = label, FontSize = 11.5, TextAlignment = TextAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center, MaxWidth = 92, TextWrapping = TextWrapping.Wrap });
            var b = new FancyButton { Content = sp, Padding = new Thickness(6, 4, 6, 4), Margin = new Thickness(2), Flat = true, VerticalAlignment = VerticalAlignment.Stretch, Focusable = false };
            b.Click += (s, e) => click?.Invoke();
            Tip(b, title, text, keys);
            return b;
        }

        /// <summary>Небольшая кнопка: иконка + (необязательная) подпись в строку.</summary>
        public static FancyButton Small(string glyph, string label, string title, string text, Action click, string keys = null)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            if (!string.IsNullOrEmpty(glyph)) { var ic = Icon(glyph, 14); sp.Children.Add(ic); }
            if (!string.IsNullOrEmpty(label)) sp.Children.Add(new TextBlock { Text = label, FontSize = 12, Margin = new Thickness(string.IsNullOrEmpty(glyph) ? 0 : 6, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center });
            var b = new FancyButton { Content = sp, Padding = new Thickness(7, 4, 7, 4), Margin = new Thickness(2), Flat = true, MinWidth = 30, MinHeight = 28, Focusable = false };
            b.Click += (s, e) => click?.Invoke();
            Tip(b, title, text, keys);
            return b;
        }

        public static FancyButton Action(string label, Action click, bool accent = false, string glyph = null)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            if (glyph != null) { var ic = Icon(glyph, 14); ic.Margin = new Thickness(0, 0, 7, 0); sp.Children.Add(ic); }
            sp.Children.Add(new TextBlock { Text = label, FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
            var b = new FancyButton { Content = sp, IsAccent = accent, Padding = new Thickness(14, 7, 14, 7), Margin = new Thickness(4), MinWidth = 90 };
            b.Click += (s, e) => click?.Invoke();
            return b;
        }

        /// <summary>Группа ленты с подписью снизу.</summary>
        public static Border Group(string title, params UIElement[] items)
        {
            var wrap = new WrapPanel { Orientation = Orientation.Horizontal, MaxHeight = 140, VerticalAlignment = VerticalAlignment.Top };
            foreach (var i in items) if (i != null) wrap.Children.Add(i);
            var dock = new DockPanel();
            var lbl = Text(title, 11, false, "B.Faint"); lbl.HorizontalAlignment = HorizontalAlignment.Center; lbl.Margin = new Thickness(0, 2, 0, 0);
            DockPanel.SetDock(lbl, Dock.Bottom);
            dock.Children.Add(lbl); dock.Children.Add(wrap);
            var b = new Border { Child = dock, Padding = new Thickness(6, 4, 6, 3), Margin = new Thickness(0, 0, 6, 0), BorderThickness = new Thickness(0, 0, 1, 0) };
            b.SetResourceReference(Border.BorderBrushProperty, "B.Border");
            return b;
        }

        public static StackPanel Column(params UIElement[] items)
        {
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            foreach (var i in items) if (i != null) sp.Children.Add(i);
            return sp;
        }

        public static StackPanel Row(params UIElement[] items)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var i in items) if (i != null) sp.Children.Add(i);
            return sp;
        }

        public static Border Card(UIElement child, double pad = 12)
        {
            var b = new Border { Child = child, Padding = new Thickness(pad), BorderThickness = new Thickness(1) };
            b.SetResourceReference(Border.BackgroundProperty, "B.Panel");
            b.SetResourceReference(Border.BorderBrushProperty, "B.Border");
            b.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            return b;
        }

        public static TextBox Input(string text = "", double width = double.NaN)
        {
            var t = new TextBox { Text = text ?? "", Padding = new Thickness(6, 4, 6, 4), FontSize = 13, BorderThickness = new Thickness(1), VerticalContentAlignment = VerticalAlignment.Center };
            if (!double.IsNaN(width)) t.Width = width;
            t.SetResourceReference(Control.BackgroundProperty, "B.Input");
            t.SetResourceReference(Control.ForegroundProperty, "B.Text");
            t.SetResourceReference(Control.BorderBrushProperty, "B.Border");
            t.SetResourceReference(TextBoxBase.CaretBrushProperty, "B.AccentSolid");
            t.SetResourceReference(TextBoxBase.SelectionBrushProperty, "B.AccentSolid");
            return t;
        }

        /// <summary>Числовое поле: колесо мыши/стрелки меняют значение, Enter применяет.</summary>
        public static TextBox Number(double value, double step, Action<double> commit, string fmt = "0.##", double width = 64)
        {
            var t = Input(value.ToString(fmt, CultureInfo.CurrentCulture), width);
            t.HorizontalContentAlignment = HorizontalAlignment.Right;
            double last = double.Parse(value.ToString(fmt, CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
            Action apply = () =>
            {
                var s = t.Text.Replace(',', '.');
                if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) && Math.Abs(v - last) > 1e-9) { last = v; commit(v); }
            };
            t.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter) { apply(); e.Handled = true; }
                else if (e.Key == Key.Up || e.Key == Key.Down)
                {
                    if (double.TryParse(t.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                    { v += e.Key == Key.Up ? step : -step; t.Text = v.ToString(fmt, CultureInfo.CurrentCulture); apply(); }
                    e.Handled = true;
                }
            };
            t.LostKeyboardFocus += (s, e) => apply();
            t.MouseWheel += (s, e) =>
            {
                if (!t.IsKeyboardFocusWithin) return;
                if (double.TryParse(t.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                { v += e.Delta > 0 ? step : -step; t.Text = v.ToString(fmt, CultureInfo.CurrentCulture); apply(); }
                e.Handled = true;
            };
            return t;
        }

        public static CheckBox Check(string label, bool value, Action<bool> changed, string tipTitle = null, string tip = null)
        {
            var c = new CheckBox { Content = label, IsChecked = value, Margin = new Thickness(0, 4, 0, 4), VerticalContentAlignment = VerticalAlignment.Center, FontSize = 13 };
            c.SetResourceReference(Control.ForegroundProperty, "B.Text");
            c.Checked += (s, e) => changed(true);
            c.Unchecked += (s, e) => changed(false);
            if (tipTitle != null) Tip(c, tipTitle, tip);
            return c;
        }

        public static Slider Slider(double min, double max, double value, Action<double> changed, double width = 140)
        {
            var s = new Slider { Minimum = min, Maximum = max, Value = value, Width = width, VerticalAlignment = VerticalAlignment.Center, IsMoveToPointEnabled = true };
            s.ValueChanged += (o, e) => changed(e.NewValue);
            return s;
        }

        public static Border Swatch(Color c, double size = 18, bool round = true)
        {
            var b = new Border { Width = size, Height = size, CornerRadius = new CornerRadius(round ? size / 2 : 3), Background = new SolidColorBrush(c), BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromArgb(90, 128, 128, 128)) };
            return b;
        }

        /// <summary>Всплывающий список вариантов в стиле темы.</summary>
        public static void Pick<T>(UIElement anchor, IEnumerable<T> items, Func<T, UIElement> visual, Action<T> onPick, double maxHeight = 420, double width = double.NaN, string searchHint = null, Func<T, string> searchText = null)
        {
            var popup = new Popup { PlacementTarget = anchor, Placement = PlacementMode.Bottom, StaysOpen = false, AllowsTransparency = true, PopupAnimation = PopupAnimation.Fade };
            var list = new StackPanel();
            var sv = new ScrollViewer { Content = list, MaxHeight = maxHeight, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var root = new DockPanel();
            var all = items.ToList();
            Action<string> fill = filter =>
            {
                list.Children.Clear();
                foreach (var it in all)
                {
                    if (!string.IsNullOrEmpty(filter) && searchText != null && searchText(it).IndexOf(filter, StringComparison.CurrentCultureIgnoreCase) < 0) continue;
                    var b = new FancyButton { Content = visual(it), Flat = true, HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(1) };
                    var cur = it;
                    b.Click += (s, e) => { popup.IsOpen = false; onPick(cur); };
                    list.Children.Add(b);
                }
            };
            if (searchHint != null)
            {
                var tb = Input(""); tb.Margin = new Thickness(4, 4, 4, 6);
                tb.TextChanged += (s, e) => fill(tb.Text);
                DockPanel.SetDock(tb, Dock.Top); root.Children.Add(tb);
                popup.Opened += (s, e) => tb.Focus();
            }
            root.Children.Add(sv);
            fill(null);
            var border = new Border { Child = root, Padding = new Thickness(5), BorderThickness = new Thickness(1), Margin = new Thickness(6), Effect = new DropShadowEffect { BlurRadius = 16, ShadowDepth = 3, Opacity = 0.45 } };
            if (!double.IsNaN(width)) border.Width = width;
            border.SetResourceReference(Border.BackgroundProperty, "B.PanelSolid");
            border.SetResourceReference(Border.BorderBrushProperty, "B.AccentSolid");
            border.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            border.SetResourceReference(TextElement.ForegroundProperty, "B.Text");
            popup.Child = border;
            popup.IsOpen = true;
        }

        public static UIElement Spacer(double w = 8) => new Border { Width = w };

        public static Border Separator()
        {
            var b = new Border { Height = 1, Margin = new Thickness(0, 8, 0, 8) };
            b.SetResourceReference(Border.BackgroundProperty, "B.Border");
            return b;
        }

        public static TextBlock Header(string s)
        {
            var t = Text(s, 15, true);
            t.Margin = new Thickness(0, 4, 0, 8);
            return t;
        }

        public static FrameworkElement Logo(double size = 28)
        {
            var g = new Grid { Width = size, Height = size };
            var b = new Border { CornerRadius = new CornerRadius(size * 0.28) };
            b.SetResourceReference(Border.BackgroundProperty, "B.Accent");
            g.Children.Add(b);
            var inner = new Border { Margin = new Thickness(size * 0.22, size * 0.28, size * 0.22, size * 0.28), CornerRadius = new CornerRadius(size * 0.06), BorderThickness = new Thickness(Math.Max(1.5, size * 0.07)) };
            inner.SetResourceReference(Border.BorderBrushProperty, "B.OnAccent");
            g.Children.Add(inner);
            var dot = new Border { Width = size * 0.16, Height = size * 0.16, CornerRadius = new CornerRadius(size), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            dot.SetResourceReference(Border.BackgroundProperty, "B.OnAccent");
            g.Children.Add(dot);
            return g;
        }
    }

    /// <summary>Окно-диалог в стиле текущей темы.</summary>
    public class ThemedWindow : Window
    {
        public ThemedWindow()
        {
            SetResourceReference(BackgroundProperty, "B.WindowBg");
            SetResourceReference(ForegroundProperty, "B.Text");
            FontFamily = Ui.UiFont;
            FontSize = 13;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;
            UseLayoutRounding = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBar(this);
            var o = Application.Current?.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive) ?? Application.Current?.MainWindow;
            if (o != null && o != this && o.IsLoaded) Owner = o;
            else WindowStartupLocation = WindowStartupLocation.CenterScreen;
            KeyDown += (s, e) => { if (e.Key == Key.Escape) Close(); };
        }

        protected override void OnContentChanged(object oldContent, object newContent)
        {
            base.OnContentChanged(oldContent, newContent);
            double k = AppSettings.Current.UiScale;
            if (Math.Abs(k - 1.0) > 0.01 && newContent is FrameworkElement fe) fe.LayoutTransform = new ScaleTransform(k, k);
        }
    }

    public static class Dialogs
    {
        public static bool? Ask(string title, string message, string yes = "Да", string no = "Нет", string cancel = null, string glyph = "")
        {
            bool? result = null;
            var w = new ThemedWindow { Title = title, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize, MaxWidth = 560 };
            var sp = new StackPanel { Margin = new Thickness(22) };
            var head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            var ic = Ui.Icon(glyph, 26); ic.SetResourceReference(TextBlock.ForegroundProperty, "B.AccentSolid"); ic.Margin = new Thickness(0, 0, 12, 0);
            head.Children.Add(ic); head.Children.Add(Ui.Text(title, 16, true));
            sp.Children.Add(head);
            var msg = Ui.Text(message, 13, false, "B.Text", true); msg.MaxWidth = 500;
            sp.Children.Add(msg);
            var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 18, 0, 0) };
            btns.Children.Add(Ui.Action(yes, () => { result = true; w.Close(); }, true));
            if (no != null) btns.Children.Add(Ui.Action(no, () => { result = false; w.Close(); }));
            if (cancel != null) btns.Children.Add(Ui.Action(cancel, () => { result = null; w.Close(); }));
            sp.Children.Add(btns);
            w.Content = sp;
            w.ShowDialog();
            return result;
        }

        public static void Info(string title, string message) => Ask(title, message, "OK", null, null, "");
        public static void Error(string title, string message) => Ask(title, message, "OK", null, null, "");

        public static string Prompt(string title, string label, string value)
        {
            string result = null;
            var w = new ThemedWindow { Title = title, SizeToContent = SizeToContent.WidthAndHeight, ResizeMode = ResizeMode.NoResize };
            var sp = new StackPanel { Margin = new Thickness(20), Width = 380 };
            sp.Children.Add(Ui.Text(label, 13, false, "B.Text", true));
            var tb = Ui.Input(value); tb.Margin = new Thickness(0, 8, 0, 0);
            sp.Children.Add(tb);
            var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
            btns.Children.Add(Ui.Action("OK", () => { result = tb.Text; w.Close(); }, true));
            btns.Children.Add(Ui.Action("Отмена", () => w.Close()));
            sp.Children.Add(btns);
            tb.KeyDown += (s, e) => { if (e.Key == Key.Enter) { result = tb.Text; w.Close(); } };
            w.Content = sp;
            w.Loaded += (s, e) => { tb.Focus(); tb.SelectAll(); };
            w.ShowDialog();
            return result;
        }
    }
}
