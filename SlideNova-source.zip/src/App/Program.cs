// Точка входа SlideNova.
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace SlideNova
{
    public static class Program
    {
        public static string AppDir => AppContext.BaseDirectory;

        [STAThread]
        public static int Main(string[] args)
        {
            var settings = AppSettings.Load();
            Hardening.Apply(settings.StrictMode);
            try { Encoding.RegisterProvider(CodePagesEncodingProvider.Instance); } catch { }
            Core.Limits.MaxFileBytes = Math.Max(16, settings.MaxFileMb) * 1024L * 1024L;

            // Служебные режимы (интеграция с Проводником без запуска интерфейса)
            if (args.Length > 0 && args[0].Equals("/register", StringComparison.OrdinalIgnoreCase)) { ShellIntegration.Register(true, true); return 0; }
            if (args.Length > 0 && args[0].Equals("/unregister", StringComparison.OrdinalIgnoreCase)) { ShellIntegration.Unregister(); return 0; }

            var app = new Application { ShutdownMode = ShutdownMode.OnLastWindowClose };
            app.DispatcherUnhandledException += OnUnhandled;
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                try { MessageBox.Show("Критическая ошибка: " + (e.ExceptionObject as Exception)?.Message, "SlideNova", MessageBoxButton.OK, MessageBoxImage.Error); } catch { }
            };
            ThemeManager.Init(app, settings);

            var w = new MainWindow();
            w.Show();
            var file = args.FirstOrDefault(a => !a.StartsWith("/", StringComparison.Ordinal));
            if (file != null) w.Dispatcher.BeginInvoke(new Action(() => w.OpenFile(file)), DispatcherPriority.ApplicationIdle);
            return app.Run();
        }

        static void OnUnhandled(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            try { Dialogs.Error("Произошла ошибка", e.Exception.Message + "\n\nРабота приложения продолжена. Рекомендуется сохранить документ под новым именем."); }
            catch { }
        }
    }

    /// <summary>Усиление защиты процесса средствами Windows.</summary>
    public static class Hardening
    {
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetDefaultDllDirectories(uint flags);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool SetDllDirectory(string path);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetSearchPathMode(uint flags);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetProcessMitigationPolicy(int policy, ref uint buffer, IntPtr length);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool HeapSetInformation(IntPtr heap, int cls, IntPtr info, IntPtr len);

        public static readonly System.Collections.Generic.List<string> Applied = new System.Collections.Generic.List<string>();
        public static bool ChildProcessesBlocked { get; private set; }

        static void Policy(int id, uint flags, string name)
        {
            try { uint f = flags; if (SetProcessMitigationPolicy(id, ref f, (IntPtr)4)) Applied.Add(name); }
            catch { }
        }

        public static void Apply(bool strict)
        {
            try { if (SetDefaultDllDirectories(0x00001000)) Applied.Add("Безопасный поиск DLL (только системные каталоги и каталог программы)"); } catch { }
            try { SetDllDirectory(""); } catch { }
            try { if (SetSearchPathMode(0x00000001 | 0x00008000)) Applied.Add("Безопасный режим поиска путей"); } catch { }
            try { HeapSetInformation(IntPtr.Zero, 1, IntPtr.Zero, IntPtr.Zero); Applied.Add("Завершение при повреждении кучи"); } catch { }
            Policy(6, 1, "Отключены устаревшие точки внедрения (AppInit DLL, глобальные хуки)");
            bool remote = false;
            try { var root = Path.GetPathRoot(Program.AppDir); remote = root.StartsWith(@"\\", StringComparison.Ordinal) || new DriveInfo(root).DriveType == DriveType.Network; } catch { }
            Policy(10, (remote ? 0u : 1u) | 2u | 4u, "Запрет загрузки модулей с низким уровнем целостности" + (remote ? "" : " и из сети"));
            if (strict)
            {
                uint f = 1;
                try { if (SetProcessMitigationPolicy(13, ref f, (IntPtr)4)) { ChildProcessesBlocked = true; Applied.Add("Строгий режим: запрет запуска дочерних процессов"); } } catch { }
            }
        }
    }
}
