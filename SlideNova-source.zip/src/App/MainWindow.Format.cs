// Главное окно: оформление объектов и текста, фон, окна-инструменты.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Microsoft.Win32;
using SlideNova.Core;

namespace SlideNova
{
    public sealed partial class MainWindow
    {
        // ================== Упорядочивание и выравнивание ==================
        void Arrange(int mode)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            var list = _ed.Slide.Shapes;
            _ed.ModifySlide("Порядок объектов", sl =>
            {
                var sel = list.Where(s => _ed.Selection.Contains(s)).ToList();
                if (mode == 2) { foreach (var s in sel) { list.Remove(s); list.Add(s); } }
                else if (mode == -2) { for (int i = sel.Count - 1; i >= 0; i--) { list.Remove(sel[i]); list.Insert(0, sel[i]); } }
                else if (mode == 1) { for (int i = list.Count - 2; i >= 0; i--) if (sel.Contains(list[i]) && !sel.Contains(list[i + 1])) { var t = list[i]; list[i] = list[i + 1]; list[i + 1] = t; } }
                else { for (int i = 1; i < list.Count; i++) if (sel.Contains(list[i]) && !sel.Contains(list[i - 1])) { var t = list[i]; list[i] = list[i - 1]; list[i - 1] = t; } }
            });
        }

        void Align(string how)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            double l, t, r, b;
            if (_ed.Selection.Count == 1) { l = 0; t = 0; r = _pres.SlideW; b = _pres.SlideH; }
            else { l = _ed.Selection.Min(s => s.X); t = _ed.Selection.Min(s => s.Y); r = _ed.Selection.Max(s => s.X + s.W); b = _ed.Selection.Max(s => s.Y + s.H); }
            _ed.Modify("Выравнивание", s =>
            {
                switch (how)
                {
                    case "l": s.X = l; break;
                    case "c": s.X = (l + r) / 2 - s.W / 2; break;
                    case "r": s.X = r - s.W; break;
                    case "t": s.Y = t; break;
                    case "m": s.Y = (t + b) / 2 - s.H / 2; break;
                    case "b": s.Y = b - s.H; break;
                }
                s.DirtyXfrm = true;
            });
        }

        void Distribute(bool horizontal)
        {
            if (!EnsureEditable() || _ed.Selection.Count < 3) { _stHint.Text = "Выделите не менее трёх объектов"; return; }
            var sorted = horizontal ? _ed.Selection.OrderBy(s => s.X).ToList() : _ed.Selection.OrderBy(s => s.Y).ToList();
            double start = horizontal ? sorted[0].X : sorted[0].Y;
            double end = horizontal ? sorted.Last().X + sorted.Last().W : sorted.Last().Y + sorted.Last().H;
            double total = sorted.Sum(s => horizontal ? s.W : s.H);
            double gap = (end - start - total) / (sorted.Count - 1);
            var pos = new Dictionary<ShapeModel, double>(); double cur = start;
            foreach (var s in sorted) { pos[s] = cur; cur += (horizontal ? s.W : s.H) + gap; }
            _ed.Modify("Распределение", s => { if (horizontal) s.X = pos[s]; else s.Y = pos[s]; s.DirtyXfrm = true; });
        }

        void RotateBy(double deg) => _ed.Modify("Поворот", s => { s.Rot = ((s.Rot + deg) % 360 + 360) % 360; s.DirtyXfrm = true; });

        void GroupSel()
        {
            if (!EnsureEditable() || _ed.Selection.Count < 2) { _stHint.Text = "Для группировки выделите два объекта или больше"; return; }
            if (_ed.Selection.Any(s => !s.CanDetach && s.Original == null)) return;
            var sel = _ed.Slide.Shapes.Where(s => _ed.Selection.Contains(s)).ToList();
            double l = sel.Min(s => s.X), t = sel.Min(s => s.Y), r = sel.Max(s => s.X + s.W), b = sel.Max(s => s.Y + s.H);
            _ed.ModifySlide("Группировка", sl =>
            {
                int at = sl.Shapes.IndexOf(sel.Last());
                var g = new ShapeModel { Kind = ShapeKind.Group, Name = "Группа", X = l, Y = t, W = r - l, H = b - t, ChX = l, ChY = t, ChW = r - l, ChH = b - t, Children = sel.Select(s => { var c = s.Clone(); c.PlaceholderType = null; c.PlaceholderIdx = null; if (c.Original != null && c.Original.Name.LocalName == "sp" && s.PlaceholderType != null) c.Detach(); return c; }).ToList(), Id = sl.NextShapeId() };
                foreach (var s in sel) sl.Shapes.Remove(s);
                sl.Shapes.Insert(Math.Min(at - sel.Count + 1, sl.Shapes.Count), g);
                _ed.Selection.Clear(); _ed.Selection.Add(g);
            });
        }

        void UngroupSel()
        {
            if (!EnsureEditable()) return;
            var groups = _ed.Selection.Where(s => s.Kind == ShapeKind.Group && s.Children != null).ToList();
            if (groups.Count == 0) { _stHint.Text = "Выделите группу"; return; }
            _ed.ModifySlide("Разгруппировка", sl =>
            {
                _ed.Selection.Clear();
                foreach (var g in groups)
                {
                    int at = sl.Shapes.IndexOf(g);
                    sl.Shapes.Remove(g);
                    double sx = g.ChW > 0 ? g.W / g.ChW : 1, sy = g.ChH > 0 ? g.H / g.ChH : 1;
                    foreach (var k in g.Children)
                    {
                        var c = k.Clone();
                        c.X = g.X + (k.X - g.ChX) * sx; c.Y = g.Y + (k.Y - g.ChY) * sy; c.W = k.W * sx; c.H = k.H * sy;
                        c.Rot = ((k.Rot + g.Rot) % 360 + 360) % 360;
                        c.DirtyXfrm = true;
                        sl.Shapes.Insert(Math.Max(0, at++), c);
                        _ed.Selection.Add(c);
                    }
                }
            });
        }

        // ================== Заливка и контур ==================
        void PickFill(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) { _stHint.Text = "Сначала выделите фигуру"; return; }
            var cur = _ed.Selection[0].Fill?.Representative ?? Rgba.White;
            var c = ColorPicker.Show(cur, ThemeColors().ToList(), "Цвет заливки");
            if (c.HasValue) _ed.Modify("Заливка", s => { s.Fill = FillDef.Solid(c.Value); s.DirtyFill = true; }, s => s.Kind == ShapeKind.Shape || s.Kind == ShapeKind.Picture);
        }

        void PickGradient()
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) { _stHint.Text = "Сначала выделите фигуру"; return; }
            var cur = _ed.Selection[0].Fill;
            var g = GradientDialog.Show(cur?.Kind == FillKind.Gradient ? cur : null, ThemeColors().ToList());
            if (g != null) _ed.Modify("Градиент", s => { s.Fill = g.Clone(); s.DirtyFill = true; }, s => s.Kind == ShapeKind.Shape);
        }

        void PickImageFill()
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) { _stHint.Text = "Сначала выделите фигуру"; return; }
            var key = LoadImageMedia();
            if (key != null) _ed.Modify("Заливка рисунком", s => { s.Fill = new FillDef { Kind = FillKind.Image, ImageKey = key }; s.DirtyFill = true; }, s => s.Kind == ShapeKind.Shape);
        }

        string LoadImageMedia()
        {
            var dlg = new OpenFileDialog { Filter = "Изображения|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff", Title = "Выберите изображение" };
            if (dlg.ShowDialog(this) != true) return null;
            try
            {
                var data = File.ReadAllBytes(dlg.FileName);
                if (data.Length > 100L * 1024 * 1024) throw new UnsafeFileException("Изображение больше 100 МБ.");
                var ext = Path.GetExtension(dlg.FileName).TrimStart('.').ToLowerInvariant();
                var bmp = ImageCache.Decode(data, ext);
                if (bmp == null) throw new UnsafeFileException("Файл не является поддерживаемым изображением.");
                if (ext != "png" && ext != "jpg" && ext != "jpeg") { data = SlideRenderer.Png(bmp); ext = "png"; }
                return _pres.AddMedia(data, ext);
            }
            catch (Exception ex) { Dialogs.Error("Изображение не загружено", ex.Message); return null; }
        }

        void PickLineColor(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            var c = ColorPicker.Show(_ed.Selection[0].Line?.Color ?? Rgba.Black, ThemeColors().ToList(), "Цвет контура");
            if (c.HasValue) _ed.Modify("Цвет контура", s => { s.Line = s.Line?.Clone() ?? new LineDef(); s.Line.Visible = true; s.Line.Color = c.Value; if (s.Line.WidthEmu <= 0) s.Line.WidthEmu = 12700; s.DirtyLine = true; });
        }

        void PickLineWidth(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            Ui.Pick(anchor, new[] { 0.25, 0.5, 0.75, 1, 1.5, 2.25, 3, 4.5, 6, 8, 12 }, w => Ui.Row(new Border { Width = 70, Height = Math.Max(1, w * 1.33), Background = ThemeManager.Brush("B.Text"), VerticalAlignment = VerticalAlignment.Center }, Ui.Spacer(10), Ui.Text(w.ToString(CultureInfo.CurrentCulture) + " пт", 12.5)),
                w => _ed.Modify("Толщина контура", s => { s.Line = s.Line?.Clone() ?? new LineDef(); s.Line.Visible = true; s.Line.WidthEmu = w * Units.EmuPerPt; s.DirtyLine = true; }));
        }

        void PickDash(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            var dashes = new[] { ("solid", "Сплошная"), ("sysDot", "Точки"), ("sysDash", "Короткий пунктир"), ("dash", "Пунктир"), ("dashDot", "Штрихпунктир"), ("lgDash", "Длинный пунктир"), ("lgDashDot", "Длинный штрихпунктир"), ("lgDashDotDot", "Штрих-две точки") };
            Ui.Pick(anchor, dashes, d =>
            {
                var line = new System.Windows.Shapes.Line { X1 = 0, X2 = 70, Y1 = 6, Y2 = 6, StrokeThickness = 2, StrokeDashArray = SlideRenderer.Dash(d.Item1), Width = 72, Height = 12 };
                line.SetResourceReference(System.Windows.Shapes.Shape.StrokeProperty, "B.Text");
                return Ui.Row(line, Ui.Spacer(10), Ui.Text(d.Item2, 12.5));
            }, d => _ed.Modify("Тип штриха", s => { s.Line = s.Line?.Clone() ?? new LineDef(); s.Line.Visible = true; s.Line.Dash = d.Item1; s.DirtyLine = true; }));
        }

        void PickArrows(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            var opts = new[] { ("none", "none", "Без стрелок"), ("none", "triangle", "Стрелка в конце"), ("triangle", "none", "Стрелка в начале"), ("triangle", "triangle", "Стрелки с обеих сторон"), ("none", "stealth", "Острая стрелка"), ("none", "arrow", "Открытая стрелка"), ("oval", "oval", "Круги на концах"), ("diamond", "diamond", "Ромбы на концах") };
            Ui.Pick(anchor, opts, o => Ui.Text(o.Item3, 12.5), o => _ed.Modify("Концы линии", s => { s.Line = s.Line?.Clone() ?? new LineDef(); s.Line.Visible = true; s.Line.HeadEnd = o.Item1; s.Line.TailEnd = o.Item2; s.DirtyLine = true; }));
        }

        // ================== Текст ==================
        IEnumerable<TextBodyModel> Bodies(ShapeModel s)
        {
            if (s.Text != null && s.Kind == ShapeKind.Shape) yield return s.Text;
            if (s.Table != null) foreach (var r in s.Table.Rows) foreach (var c in r) yield return c.Text;
            if (s.Kind == ShapeKind.Group && s.Children != null) foreach (var k in s.Children) foreach (var b in Bodies(k)) yield return b;
        }

        void MarkText(ShapeModel s)
        {
            if (s.Kind == ShapeKind.Table) s.DirtyTable = true;
            else if (s.Kind == ShapeKind.Group) { if (s.Children != null) foreach (var k in s.Children) MarkText(k); }
            else s.DirtyText = true;
        }

        void TextOp(string label, Action<RichTextBox> rtbOp, Action<TextBodyModel, ParaModel, RunModel> runOp, Action<TextBodyModel, ParaModel> paraOp = null)
        {
            if (!EnsureEditable()) return;
            if (_ed.IsEditingText)
            {
                var rtb = _ed.TextEditor;
                rtbOp?.Invoke(rtb);
                rtb.Focus();
                return;
            }
            if (_ed.Selection.Count == 0) { _stHint.Text = "Выделите фигуру с текстом или начните редактирование текста"; return; }
            _ed.Modify(label, s =>
            {
                foreach (var t in Bodies(s))
                    foreach (var p in t.Paras)
                    {
                        paraOp?.Invoke(t, p);
                        if (runOp != null) foreach (var r in p.Runs.Where(x => !x.IsBreak)) runOp(t, p, r);
                    }
                MarkText(s);
            }, s => Bodies(s).Any());
        }

        void SetTextColor(ShapeModel s, Rgba c)
        {
            foreach (var t in Bodies(s))
            {
                foreach (var l in t.Levels) l.Color = c;
                foreach (var p in t.Paras) foreach (var r in p.Runs) r.Color = c;
            }
            MarkText(s);
        }

        void ToggleStyle(string which)
        {
            if (_ed.IsEditingText)
            {
                var rtb = _ed.TextEditor;
                switch (which)
                {
                    case "b": EditingCommands.ToggleBold.Execute(null, rtb); break;
                    case "i": EditingCommands.ToggleItalic.Execute(null, rtb); break;
                    case "u": EditingCommands.ToggleUnderline.Execute(null, rtb); break;
                    case "s":
                        {
                            var cur = rtb.Selection.GetPropertyValue(Inline.TextDecorationsProperty) as TextDecorationCollection;
                            bool has = cur != null && cur.Any(d => d.Location == TextDecorationLocation.Strikethrough);
                            rtb.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, has ? new TextDecorationCollection() : TextDecorations.Strikethrough);
                            break;
                        }
                }
                rtb.Focus();
                return;
            }
            if (_ed.Selection.Count == 0) return;
            bool all = _ed.Selection.SelectMany(Bodies).SelectMany(t => t.Paras.SelectMany(p => p.Runs.Where(r => !r.IsBreak).Select(r => which == "b" ? t.EffBold(p, r) : which == "i" ? t.EffItalic(p, r) : which == "u" ? t.EffUnderline(p, r) : t.EffStrike(p, r)))).DefaultIfEmpty(false).All(x => x);
            bool v = !all;
            TextOp("Начертание", null, (t, p, r) => { if (which == "b") r.Bold = v; else if (which == "i") r.Italic = v; else if (which == "u") r.Underline = v; else r.Strike = v; });
        }

        void ParaAlign(string a)
        {
            if (_ed.IsEditingText)
            {
                var ta = a == "ctr" ? TextAlignment.Center : a == "r" ? TextAlignment.Right : a == "just" ? TextAlignment.Justify : TextAlignment.Left;
                _ed.TextEditor.Selection.ApplyPropertyValue(Block.TextAlignmentProperty, ta);
                _ed.TextEditor.Focus();
                return;
            }
            TextOp("Выравнивание текста", null, null, (t, p) => p.Align = a);
        }

        IEnumerable<Paragraph> SelectedParagraphs(RichTextBox rtb)
        {
            var start = rtb.Selection.Start.Paragraph; var end = rtb.Selection.End.Paragraph;
            bool inside = false;
            foreach (var b in rtb.Document.Blocks)
            {
                if (b == start) inside = true;
                if (inside && b is Paragraph p) yield return p;
                if (b == end) break;
            }
            if (start == null && end == null && rtb.CaretPosition.Paragraph != null) yield return rtb.CaretPosition.Paragraph;
        }

        void Bullets(string bullet)
        {
            if (_ed.IsEditingText)
            {
                foreach (var p in SelectedParagraphs(_ed.TextEditor))
                {
                    var pm = p.Tag as ParaModel ?? new ParaModel(); p.Tag = pm;
                    pm.Bullet = pm.Bullet == bullet ? "" : bullet;
                }
                _stHint.Text = "Маркеры применятся после завершения ввода текста (Esc)";
                return;
            }
            bool allHave = _ed.Selection.SelectMany(Bodies).SelectMany(t => t.Paras.Select(p => t.EffBullet(p))).DefaultIfEmpty(null).All(b => b == bullet || (b != null && bullet == "•" && b[0] != '\u0001'));
            TextOp("Список", null, null, (t, p) => p.Bullet = allHave ? "" : bullet);
        }

        void Level(int d)
        {
            if (_ed.IsEditingText)
            {
                foreach (var p in SelectedParagraphs(_ed.TextEditor)) { var pm = p.Tag as ParaModel ?? new ParaModel(); p.Tag = pm; pm.Level = Math.Max(0, Math.Min(8, pm.Level + d)); p.Margin = new Thickness(Math.Max(0, p.Margin.Left + d * 36), p.Margin.Top, 0, p.Margin.Bottom); }
                return;
            }
            TextOp("Уровень списка", null, null, (t, p) => p.Level = Math.Max(0, Math.Min(8, p.Level + d)));
        }

        void Anchor(string a)
        {
            if (!EnsureEditable()) return;
            _ed.EndTextEdit(true);
            _ed.Modify("Положение текста", s => { s.Text.Anchor = a; s.DirtyText = true; }, s => s.Text != null && s.Kind == ShapeKind.Shape);
        }

        void GrowFont(int dir)
        {
            double[] steps = { 8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 44, 48, 54, 60, 66, 72, 80, 88, 96 };
            Func<double, double> next = v => dir > 0 ? steps.FirstOrDefault(x => x > v + 0.01) is double n && n > 0 ? n : v + 8 : steps.LastOrDefault(x => x < v - 0.01) is double m && m > 0 ? m : Math.Max(1, v - 1);
            if (_ed.IsEditingText)
            {
                var rtb = _ed.TextEditor;
                var cur = rtb.Selection.GetPropertyValue(TextElement.FontSizeProperty);
                double pt = cur is double d ? d * 72 / 96 / Math.Max(0.05, _ed.Selection.FirstOrDefault()?.Text?.FontScale ?? 1) : 18;
                SetSizeRtb(next(pt));
                return;
            }
            TextOp("Размер шрифта", null, (t, p, r) => r.SizePt = next(t.EffSize(p, r)));
        }

        void SetSizeRtb(double pt)
        {
            var rtb = _ed.TextEditor;
            double scale = Math.Max(0.05, _ed.Selection.FirstOrDefault()?.Text?.FontScale ?? 1);
            rtb.Selection.ApplyPropertyValue(TextElement.FontSizeProperty, Px.PtToDip(pt * scale));
            rtb.Focus();
        }

        void ChangeCase(bool upper)
        {
            if (_ed.IsEditingText)
            {
                var sel = _ed.TextEditor.Selection;
                if (!sel.IsEmpty) sel.Text = upper ? sel.Text.ToUpper(CultureInfo.CurrentCulture) : sel.Text.ToLower(CultureInfo.CurrentCulture);
                return;
            }
            TextOp("Регистр", null, (t, p, r) => r.Text = upper ? r.Text.ToUpper(CultureInfo.CurrentCulture) : r.Text.ToLower(CultureInfo.CurrentCulture));
        }

        string CurrentFontName()
        {
            var s = _ed.Selection.FirstOrDefault();
            var t = s != null ? Bodies(s).FirstOrDefault() : null;
            var p = t?.Paras.FirstOrDefault();
            return t == null ? null : t.EffFont(p, p?.Runs.FirstOrDefault(r => !r.IsBreak));
        }

        string CurrentFontSize()
        {
            var s = _ed.Selection.FirstOrDefault();
            var t = s != null ? Bodies(s).FirstOrDefault() : null;
            var p = t?.Paras.FirstOrDefault();
            return t == null ? null : t.EffSize(p, p?.Runs.FirstOrDefault(r => !r.IsBreak)).ToString("0.#", CultureInfo.CurrentCulture) + " пт";
        }

        static List<string> _fontNames;
        void PickFont(UIElement anchor)
        {
            if (!EnsureEditable()) return;
            if (_fontNames == null) _fontNames = Fonts.SystemFontFamilies.Select(f => f.Source).Where(n => !string.IsNullOrWhiteSpace(n)).Distinct().OrderBy(n => n).ToList();
            var theme = _pres.Theme;
            var list = new List<string> { theme.MajorFont, theme.MinorFont }.Concat(_fontNames).Distinct().ToList();
            Ui.Pick(anchor, list, n => new TextBlock { Text = n, FontFamily = SlideRenderer.Font(n), FontSize = 15 }, n =>
            {
                if (_ed.IsEditingText) { _ed.TextEditor.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, SlideRenderer.Font(n)); _ed.TextEditor.Focus(); return; }
                TextOp("Шрифт", null, (t, p, r) => r.Font = n);
                RebuildRibbon();
            }, 420, 300, "Поиск шрифта", n => n);
        }

        void PickSize(UIElement anchor)
        {
            if (!EnsureEditable()) return;
            var sizes = new List<string> { "8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "28", "32", "36", "40", "44", "48", "54", "60", "72", "80", "96", "Другой…" };
            Ui.Pick(anchor, sizes, s => Ui.Text(s, 13), s =>
            {
                double v;
                if (s == "Другой…")
                {
                    var r = Dialogs.Prompt("Размер шрифта", "Введите размер в пунктах (1–4000):", "18");
                    if (r == null || !double.TryParse(r.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return;
                }
                else v = double.Parse(s, CultureInfo.InvariantCulture);
                v = Units.Clamp(v, 1, 4000);
                if (_ed.IsEditingText) { SetSizeRtb(v); return; }
                TextOp("Размер шрифта", null, (t, p, r) => r.SizePt = v, (t, p) => { if (p.Runs.Count == 0) p.EndSizePt = v; });
                RebuildRibbon();
            }, 360, 120);
        }

        void PickTextColor(UIElement anchor)
        {
            if (!EnsureEditable()) return;
            var c = ColorPicker.Show(Rgba.Black, ThemeColors().ToList(), "Цвет текста");
            if (!c.HasValue) return;
            if (_ed.IsEditingText) { _ed.TextEditor.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(Px.C(c.Value))); _ed.TextEditor.Focus(); return; }
            TextOp("Цвет текста", null, (t, p, r) => r.Color = c.Value);
        }

        void PickSpacing(UIElement anchor)
        {
            if (!EnsureEditable()) return;
            _ed.EndTextEdit(true);
            Ui.Pick(anchor, new[] { 1.0, 1.15, 1.5, 2.0, 2.5, 3.0 }, v => Ui.Text(v.ToString("0.0#", CultureInfo.CurrentCulture), 13), v => TextOp("Междустрочный интервал", null, null, (t, p) => p.LineSpacingPct = v * 100), 300, 120);
        }

        // ================== Фон ==================
        void PickBackground(UIElement anchor)
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            var c = ColorPicker.Show(_ed.Slide.Background?.Representative ?? Rgba.White, ThemeColors().ToList(), "Цвет фона");
            if (c.HasValue) _ed.ModifySlide("Фон", s => { s.Background = FillDef.Solid(c.Value); s.BackgroundDirty = true; });
            RefreshThumb(_ed.SlideIndex);
        }

        void PickBackgroundGradient()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            var g = GradientDialog.Show(_ed.Slide.Background?.Kind == FillKind.Gradient ? _ed.Slide.Background : null, ThemeColors().ToList());
            if (g != null) _ed.ModifySlide("Градиентный фон", s => { s.Background = g.Clone(); s.BackgroundDirty = true; });
            RefreshThumb(_ed.SlideIndex);
        }

        void PickBackgroundImage()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            var key = LoadImageMedia();
            if (key != null) _ed.ModifySlide("Фоновый рисунок", s => { s.Background = new FillDef { Kind = FillKind.Image, ImageKey = key }; s.BackgroundDirty = true; });
            RefreshThumb(_ed.SlideIndex);
        }

        void ApplyBgToAll()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            var bg = _ed.Slide.Background?.Clone();
            if (bg == null) return;
            PushUndo("Фон для всех слайдов");
            foreach (var s in _pres.Slides) { s.Background = bg.Clone(); s.BackgroundDirty = true; }
            AfterStructure(_ed.SlideIndex);
        }

        // ================== Окна ==================
        void ShowFind(bool replace)
        {
            if (_pres == null) return;
            _ed.EndTextEdit(true);
            FindWindow.Open(this, _pres, replace && !_protected, (slide, shape) =>
            {
                GoTo(slide);
                if (shape != null) _ed.Select(shape);
            }, label => { MarkDirty(); RebuildThumbs(); _ed.Rebuild(); LoadNotes(); }, () => PushUndo("Замена текста"));
        }

        void StartShow(int from)
        {
            if (_pres == null || _pres.Slides.Count == 0) return;
            _ed.EndTextEdit(true);
            var w = new SlideShowWindow(_pres, _img, from, S.ShowTransitions);
            w.ShowDialog();
            GoTo(Math.Min(w.LastIndex, _pres.Slides.Count - 1));
        }

        void PrintNow()
        {
            if (_pres == null) return;
            _ed.EndTextEdit(true);
            var w = new PrintWindow(_pres, _img, _ed.SlideIndex, _path != null ? Path.GetFileName(_path) : "Презентация");
            w.ShowDialog();
        }

        void ShowProperties()
        {
            if (_pres == null) { Dialogs.Info("Свойства", "Откройте презентацию, чтобы увидеть её свойства."); return; }
            _ed.EndTextEdit(true);
            var w = new PropertiesWindow(_pres, _path, _img, _protected, () => { MarkDirty(); });
            w.ShowDialog();
        }

        void ShowSettings()
        {
            var w = new SettingsWindow();
            w.ShowDialog();
            RebuildRibbon();
            if (_pres == null) ShowStart();
        }

        void ExportPng()
        {
            if (_pres == null) return;
            _ed.EndTextEdit(true);
            var choice = Dialogs.Ask("Экспорт в PNG", "Сохранить только текущий слайд или все слайды презентации? Изображения создаются в разрешении 1920 пикселей по ширине.", "Текущий слайд", "Все слайды", "Отмена", "");
            if (choice == null) return;
            var dlg = new SaveFileDialog { Filter = "Изображение PNG|*.png", FileName = "Слайд " + (_ed.SlideIndex + 1), Title = "Экспорт в PNG" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                WaitCursor(true);
                if (choice == true) Security.AtomicWrite(dlg.FileName, SlideRenderer.Png(_ed.Renderer.Rasterize(_pres.Slides[_ed.SlideIndex], _ed.SlideIndex + 1, 1920)));
                else
                {
                    var dir = Path.GetDirectoryName(dlg.FileName); var bas = Path.GetFileNameWithoutExtension(dlg.FileName);
                    for (int i = 0; i < _pres.Slides.Count; i++)
                        Security.AtomicWrite(Path.Combine(dir, bas + " " + (i + 1).ToString("D2") + ".png"), SlideRenderer.Png(_ed.Renderer.Rasterize(_pres.Slides[i], i + 1, 1920)));
                }
                _stHint.Text = "Экспорт завершён";
            }
            catch (Exception ex) { Dialogs.Error("Экспорт не выполнен", ex.Message); }
            finally { WaitCursor(false); }
        }

        void ExportPdf()
        {
            if (_pres == null) return;
            _ed.EndTextEdit(true);
            var dlg = new SaveFileDialog { Filter = "Документ PDF|*.pdf", FileName = _path != null ? Path.GetFileNameWithoutExtension(_path) : "Презентация", Title = "Экспорт в PDF" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                WaitCursor(true);
                var pages = new List<Tuple<byte[], int, int>>();
                for (int i = 0; i < _pres.Slides.Count; i++)
                {
                    if (_pres.Slides[i].Hidden) continue;
                    var bmp = _ed.Renderer.Rasterize(_pres.Slides[i], i + 1, 2200);
                    pages.Add(Tuple.Create(SlideRenderer.Jpeg(bmp, 92), bmp.PixelWidth, bmp.PixelHeight));
                }
                var pdf = PdfWriter.FromJpegs(pages, _pres.SlideW / Units.EmuPerPt, _pres.SlideH / Units.EmuPerPt, _pres.Info.Title);
                Security.AtomicWrite(dlg.FileName, pdf);
                _stHint.Text = "PDF сохранён: " + dlg.FileName;
            }
            catch (Exception ex) { Dialogs.Error("Экспорт не выполнен", ex.Message); }
            finally { WaitCursor(false); }
        }

        static void WaitCursor(bool wait) => System.Windows.Input.Mouse.OverrideCursor = wait ? System.Windows.Input.Cursors.Wait : null;
    }
}
