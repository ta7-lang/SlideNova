// Отрисовка слайдов средствами WPF. Всё в памяти: никакого дискового кэша.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SlideNova.Core;

namespace SlideNova
{
    public static class Px
    {
        public static double D(double emu) => emu / Units.EmuPerDip;
        public static double E(double dip) => dip * Units.EmuPerDip;
        public static double PtToDip(double pt) => pt * 96.0 / 72.0;
        public static Color C(Rgba c) => Color.FromArgb(c.A, c.R, c.G, c.B);
        public static Rgba R(Color c) => new Rgba(c.A, c.R, c.G, c.B);
        public static Color Shade(Color c, double f)
        {
            if (Math.Abs(f - 1) < 0.001) return c;
            if (f < 1) return Color.FromArgb(c.A, (byte)(c.R * f), (byte)(c.G * f), (byte)(c.B * f));
            double t = Math.Min(1, f - 1);
            return Color.FromArgb(c.A, (byte)(c.R + (255 - c.R) * t), (byte)(c.G + (255 - c.G) * t), (byte)(c.B + (255 - c.B) * t));
        }
    }

    /// <summary>Безопасное декодирование изображений в память с ограничениями.</summary>
    public sealed class ImageCache
    {
        readonly PresentationModel _pres;
        readonly Dictionary<string, BitmapSource> _cache = new Dictionary<string, BitmapSource>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> _failed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public ImageCache(PresentationModel p) { _pres = p; }
        public void Clear() { _cache.Clear(); _failed.Clear(); }

        public BitmapSource Get(string key)
        {
            if (key == null || _failed.Contains(key)) return null;
            if (_cache.TryGetValue(key, out var b)) return b;
            if (!_pres.Media.TryGetValue(key, out var m) || m.Data == null || m.Data.Length == 0) { _failed.Add(key); return null; }
            try { b = Decode(m.Data, m.Ext); }
            catch { b = null; }
            if (b == null) { _failed.Add(key); return null; }
            _cache[key] = b;
            return b;
        }

        public static BitmapSource Decode(byte[] data, string ext)
        {
            ext = (ext ?? "").ToLowerInvariant();
            if (ext == "emf" || ext == "wmf" || IsEmf(data) || IsWmf(data)) return Metafile.Render(data, ext == "wmf" || IsWmf(data), 1600);
            if (ext == "svg") return null;
            int w = 0, h = 0;
            using (var probe = new MemoryStream(data, false))
            {
                var dec = BitmapDecoder.Create(probe, BitmapCreateOptions.DelayCreation | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
                if (dec.Frames.Count == 0) return null;
                w = dec.Frames[0].PixelWidth; h = dec.Frames[0].PixelHeight;
            }
            if (w <= 0 || h <= 0 || (long)w * h > 400_000_000L) return null; // защита от «пиксельных бомб»
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.CreateOptions = BitmapCreateOptions.IgnoreColorProfile | BitmapCreateOptions.IgnoreImageCache;
            if (w > 4096 || h > 4096) { if (w >= h) bi.DecodePixelWidth = 4096; else bi.DecodePixelHeight = 4096; }
            bi.StreamSource = new MemoryStream(data, false);
            bi.EndInit();
            bi.Freeze();
            return bi;
        }

        static bool IsEmf(byte[] d) => d.Length > 44 && d[0] == 1 && d[1] == 0 && d[2] == 0 && d[3] == 0 && d[40] == 0x20 && d[41] == 0x45 && d[42] == 0x4D && d[43] == 0x46;
        static bool IsWmf(byte[] d) => d.Length > 4 && ((d[0] == 0xD7 && d[1] == 0xCD && d[2] == 0xC6 && d[3] == 0x9A) || (d[0] == 1 && d[1] == 0 && d[2] == 9 && d[3] == 0));
    }

    /// <summary>Отрисовка EMF/WMF через GDI в памяти (с восстановлением прозрачности).</summary>
    public static class Metafile
    {
        [DllImport("gdi32.dll")] static extern IntPtr SetEnhMetaFileBits(uint cb, byte[] data);
        [DllImport("gdi32.dll")] static extern IntPtr SetWinMetaFileBits(uint cb, byte[] data, IntPtr hdcRef, IntPtr mfp);
        [DllImport("gdi32.dll")] static extern bool DeleteEnhMetaFile(IntPtr h);
        [DllImport("gdi32.dll")] static extern uint GetEnhMetaFileHeader(IntPtr h, uint cb, ref ENHMETAHEADER hdr);
        [DllImport("gdi32.dll")] static extern bool PlayEnhMetaFile(IntPtr hdc, IntPtr h, ref RECT rc);
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFOHEADER bmi, uint usage, out IntPtr bits, IntPtr sec, uint off);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
        [DllImport("gdi32.dll")] static extern int SetStretchBltMode(IntPtr hdc, int mode);
        [DllImport("gdi32.dll")] static extern bool GdiFlush();

        [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
        [StructLayout(LayoutKind.Sequential)] struct SIZEL { public int cx, cy; }
        [StructLayout(LayoutKind.Sequential)]
        struct ENHMETAHEADER
        {
            public uint iType, nSize; public RECT rclBounds, rclFrame; public uint dSignature, nVersion, nBytes, nRecords; public ushort nHandles, sReserved;
            public uint nDescription, offDescription, nPalEntries; public SIZEL szlDevice, szlMillimeters; public uint cbPixelFormat, offPixelFormat, bOpenGL; public SIZEL szlMicrometers;
        }
        [StructLayout(LayoutKind.Sequential)]
        struct BITMAPINFOHEADER { public uint biSize; public int biWidth, biHeight; public ushort biPlanes, biBitCount; public uint biCompression, biSizeImage; public int biXPelsPerMeter, biYPelsPerMeter; public uint biClrUsed, biClrImportant; }

        public static BitmapSource Render(byte[] data, bool wmf, int maxDim)
        {
            if (data.Length > 64 * 1024 * 1024) return null;
            IntPtr hemf;
            if (wmf)
            {
                byte[] d = data;
                if (d.Length > 22 && d[0] == 0xD7 && d[1] == 0xCD && d[2] == 0xC6 && d[3] == 0x9A) { d = new byte[data.Length - 22]; Buffer.BlockCopy(data, 22, d, 0, d.Length); }
                hemf = SetWinMetaFileBits((uint)d.Length, d, IntPtr.Zero, IntPtr.Zero);
            }
            else hemf = SetEnhMetaFileBits((uint)data.Length, data);
            if (hemf == IntPtr.Zero) return null;
            try
            {
                var hdr = new ENHMETAHEADER();
                GetEnhMetaFileHeader(hemf, (uint)Marshal.SizeOf(typeof(ENHMETAHEADER)), ref hdr);
                double wmm = (hdr.rclFrame.R - hdr.rclFrame.L) / 100.0, hmm = (hdr.rclFrame.B - hdr.rclFrame.T) / 100.0;
                double w = wmm / 25.4 * 96 * 2, h = hmm / 25.4 * 96 * 2;
                if (w < 4 || h < 4) { w = Math.Max(4, hdr.rclBounds.R - hdr.rclBounds.L); h = Math.Max(4, hdr.rclBounds.B - hdr.rclBounds.T); }
                double k = Math.Min(1.0, maxDim / Math.Max(w, h));
                int W = Math.Max(8, (int)(w * k)), H = Math.Max(8, (int)(h * k));
                var black = Draw(hemf, W, H, 0x00);
                var white = Draw(hemf, W, H, 0xFF);
                if (black == null || white == null) return null;
                var outp = new byte[W * H * 4];
                for (int i = 0; i < W * H; i++)
                {
                    int o = i * 4;
                    int a = 255 - Math.Max(white[o] - black[o], Math.Max(white[o + 1] - black[o + 1], white[o + 2] - black[o + 2]));
                    if (a < 0) a = 0; if (a > 255) a = 255;
                    outp[o] = (byte)Math.Min(black[o], a); outp[o + 1] = (byte)Math.Min(black[o + 1], a); outp[o + 2] = (byte)Math.Min(black[o + 2], a); outp[o + 3] = (byte)a;
                }
                var bs = BitmapSource.Create(W, H, 96, 96, PixelFormats.Pbgra32, null, outp, W * 4);
                bs.Freeze();
                return bs;
            }
            finally { DeleteEnhMetaFile(hemf); }
        }

        static byte[] Draw(IntPtr hemf, int w, int h, byte bg)
        {
            var bmi = new BITMAPINFOHEADER { biSize = 40, biWidth = w, biHeight = -h, biPlanes = 1, biBitCount = 32 };
            var dc = CreateCompatibleDC(IntPtr.Zero);
            if (dc == IntPtr.Zero) return null;
            var dib = CreateDIBSection(dc, ref bmi, 0, out IntPtr bits, IntPtr.Zero, 0);
            if (dib == IntPtr.Zero) { DeleteDC(dc); return null; }
            var old = SelectObject(dc, dib);
            try
            {
                var buf = new byte[w * h * 4];
                for (int i = 0; i < buf.Length; i++) buf[i] = bg;
                Marshal.Copy(buf, 0, bits, buf.Length);
                SetStretchBltMode(dc, 4);
                var rc = new RECT { L = 0, T = 0, R = w, B = h };
                PlayEnhMetaFile(dc, hemf, ref rc);
                GdiFlush();
                Marshal.Copy(bits, buf, 0, buf.Length);
                return buf;
            }
            finally { SelectObject(dc, old); DeleteObject(dib); DeleteDC(dc); }
        }
    }

    public sealed class SlideRenderOptions
    {
        public bool PlaceholderHints;    // пунктирные рамки пустых заполнителей
        public bool Interactive;         // активные ссылки (показ)
        public bool Grayscale;
        public ShapeModel HideTextOf;    // при редактировании текста
        public Action<string> OnLink;
    }

    public sealed class SlideRenderer
    {
        readonly PresentationModel _p;
        readonly ImageCache _img;
        static readonly Dictionary<string, FontFamily> Fonts = new Dictionary<string, FontFamily>(StringComparer.OrdinalIgnoreCase);
        public SlideRenderer(PresentationModel p, ImageCache img) { _p = p; _img = img; }

        public static FontFamily Font(string name)
        {
            name = string.IsNullOrWhiteSpace(name) ? "Calibri" : name;
            if (!Fonts.TryGetValue(name, out var f)) { f = new FontFamily(name + ", Calibri, Segoe UI, Arial"); Fonts[name] = f; }
            return f;
        }

        public Canvas RenderSlide(SlideModel s, int number, SlideRenderOptions opt, Dictionary<ShapeModel, FrameworkElement> map = null)
        {
            opt = opt ?? new SlideRenderOptions();
            double W = Px.D(_p.SlideW), H = Px.D(_p.SlideH);
            var c = new Canvas { Width = W, Height = H, ClipToBounds = true, SnapsToDevicePixels = false };
            c.Background = FillBrush(s.Background, 1.0) ?? Brushes.White;
            foreach (var m in s.MasterShapes) { var e = RenderShape(m, opt, number, s); if (e != null) c.Children.Add(e); }
            foreach (var sh in s.Shapes)
            {
                var e = RenderShape(sh, opt, number, s);
                if (e == null) continue;
                c.Children.Add(e);
                if (map != null) map[sh] = e;
            }
            return c;
        }

        public Brush FillBrush(FillDef f, double shade)
        {
            if (f == null) return null;
            switch (f.Kind)
            {
                case FillKind.Solid: { var b = new SolidColorBrush(Px.Shade(Px.C(f.Color), shade)); b.Freeze(); return b; }
                case FillKind.Gradient:
                    {
                        var stops = new GradientStopCollection(f.Stops.Select(st => new GradientStop(Px.Shade(Px.C(st.Color), shade), st.Pos)));
                        GradientBrush g;
                        if (f.Radial) g = new RadialGradientBrush(stops) { GradientOrigin = new Point(0.5, 0.5), Center = new Point(0.5, 0.5), RadiusX = 0.7, RadiusY = 0.7 };
                        else
                        {
                            double a = f.Angle * Math.PI / 180, cx = Math.Cos(a) * 0.5, cy = Math.Sin(a) * 0.5;
                            g = new LinearGradientBrush(stops, new Point(0.5 - cx, 0.5 - cy), new Point(0.5 + cx, 0.5 + cy));
                        }
                        g.Freeze(); return g;
                    }
                case FillKind.Image:
                    {
                        var bmp = _img.Get(f.ImageKey);
                        if (bmp == null) return Brushes.LightGray;
                        var ib = new ImageBrush(bmp) { Stretch = Stretch.Fill };
                        if (f.Tile) { ib.TileMode = TileMode.Tile; ib.ViewportUnits = BrushMappingMode.Absolute; ib.Viewport = new Rect(0, 0, Math.Max(4, bmp.Width), Math.Max(4, bmp.Height)); ib.Stretch = Stretch.None; }
                        ib.Freeze(); return ib;
                    }
                default: return null;
            }
        }

        public static Geometry BuildGeometry(List<GeoPath> paths, double sx, double sy, bool onlyFilled, bool onlyStroked)
        {
            var sg = new StreamGeometry { FillRule = FillRule.Nonzero };
            using (var ctx = sg.Open())
            {
                foreach (var p in paths)
                {
                    if (onlyFilled && !p.Filled) continue;
                    if (onlyStroked && !p.Stroked) continue;
                    if (p.EvenOdd) sg.FillRule = FillRule.EvenOdd;
                    bool open = false;
                    foreach (var c in p.Cmds)
                    {
                        switch (c.Type)
                        {
                            case 'M': ctx.BeginFigure(new Point(c.P[0] * sx, c.P[1] * sy), p.Filled, false); open = true; break;
                            case 'L': if (!open) { ctx.BeginFigure(new Point(c.P[0] * sx, c.P[1] * sy), p.Filled, false); open = true; } else ctx.LineTo(new Point(c.P[0] * sx, c.P[1] * sy), true, true); break;
                            case 'C': if (!open) { ctx.BeginFigure(new Point(c.P[4] * sx, c.P[5] * sy), p.Filled, false); open = true; } else ctx.BezierTo(new Point(c.P[0] * sx, c.P[1] * sy), new Point(c.P[2] * sx, c.P[3] * sy), new Point(c.P[4] * sx, c.P[5] * sy), true, true); break;
                            case 'Z': if (open) { ctx.Close(); } break;
                        }
                    }
                }
            }
            sg.Freeze();
            return sg;
        }

        static void CloseFigures(StreamGeometryContext ctx) { }

        public static List<GeoPath> PathsOf(ShapeModel s)
        {
            if (s.Geometry == "custom" && s.CustomPaths != null && s.CustomPaths.Count > 0) return s.CustomPaths;
            return PresetGeometry.Build(s.Geometry, s.W, s.H, s.Adj);
        }

        public static DoubleCollection Dash(string d)
        {
            switch (d)
            {
                case "dash": return new DoubleCollection { 4, 3 };
                case "sysDash": return new DoubleCollection { 3, 1 };
                case "dot": case "sysDot": return new DoubleCollection { 1, 1 };
                case "dashDot": return new DoubleCollection { 4, 3, 1, 3 };
                case "lgDash": return new DoubleCollection { 8, 3 };
                case "lgDashDot": return new DoubleCollection { 8, 3, 1, 3 };
                case "lgDashDotDot": return new DoubleCollection { 8, 3, 1, 3, 1, 3 };
                case "sysDashDot": return new DoubleCollection { 3, 1, 1, 1 };
                case "sysDashDotDot": return new DoubleCollection { 3, 1, 1, 1, 1, 1 };
                default: return null;
            }
        }

        public FrameworkElement RenderShape(ShapeModel s, SlideRenderOptions opt, int number, SlideModel slide)
        {
            double w = Px.D(s.W), h = Px.D(s.H);
            FrameworkElement el;
            try
            {
                switch (s.Kind)
                {
                    case ShapeKind.Group: el = RenderGroup(s, s.Children, s.ChX, s.ChY, s.ChW, s.ChH, opt, number, slide); break;
                    case ShapeKind.Table: el = RenderTable(s, opt, number, slide); break;
                    case ShapeKind.Graphic:
                        if (s.Children != null && s.Children.Count > 0)
                        {
                            double minX = s.Children.Min(k => k.X), minY = s.Children.Min(k => k.Y);
                            bool abs = minX >= s.X - 2 && minY >= s.Y - 2 && s.X > 0;
                            el = RenderGroup(s, s.Children, abs ? s.X : 0, abs ? s.Y : 0, s.W, s.H, opt, number, slide);
                        }
                        else if (s.ImageKey != null) el = RenderPicture(s, w, h);
                        else el = Placeholder(w, h, s.GraphicLabel ?? "Объект", "");
                        break;
                    case ShapeKind.Picture: el = RenderPicture(s, w, h); break;
                    default: el = RenderGeometryShape(s, w, h, opt, number, slide); break;
                }
            }
            catch { el = Placeholder(w, h, "Не удалось отобразить объект", ""); }
            if (el == null) return null;
            Canvas.SetLeft(el, Px.D(s.X));
            Canvas.SetTop(el, Px.D(s.Y));
            el.Width = Math.Max(0.01, w); el.Height = Math.Max(0.01, h);
            if (Math.Abs(s.Rot) > 0.01) el.RenderTransform = new RotateTransform(s.Rot, w / 2, h / 2);
            return el;
        }

        FrameworkElement RenderGroup(ShapeModel g, List<ShapeModel> kids, double chX, double chY, double chW, double chH, SlideRenderOptions opt, int number, SlideModel slide)
        {
            var c = new Canvas { ClipToBounds = false };
            if (kids == null) return c;
            double sx = chW > 0 ? g.W / chW : 1, sy = chH > 0 ? g.H / chH : 1;
            foreach (var k in kids)
            {
                var t = k.Clone();
                t.X = (k.X - chX) * sx; t.Y = (k.Y - chY) * sy; t.W = k.W * sx; t.H = k.H * sy;
                if (t.Kind == ShapeKind.Group) { t.ChX = k.ChX; t.ChY = k.ChY; t.ChW = k.ChW; t.ChH = k.ChH; }
                if (t.CustomPaths != null) { t.CustW = k.CustW; t.CustH = k.CustH; }
                var e = RenderShape(t, opt, number, slide);
                if (e != null) c.Children.Add(e);
            }
            return c;
        }

        FrameworkElement Placeholder(double w, double h, string label, string glyph)
        {
            var g = new Grid();
            g.Children.Add(new Rectangle { Stroke = new SolidColorBrush(Color.FromArgb(160, 128, 128, 140)), StrokeDashArray = new DoubleCollection { 4, 3 }, Fill = new SolidColorBrush(Color.FromArgb(40, 128, 128, 160)) });
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
            var ic = Ui.Icon(glyph, Math.Max(10, Math.Min(36, Math.Min(w, h) / 4))); ic.Foreground = Brushes.Gray; sp.Children.Add(ic);
            sp.Children.Add(new TextBlock { Text = label, Foreground = Brushes.Gray, FontSize = Math.Max(8, Math.Min(16, Math.Min(w, h) / 7)), TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, MaxWidth = Math.Max(20, w - 8) });
            g.Children.Add(sp);
            return g;
        }

        FrameworkElement RenderPicture(ShapeModel s, double w, double h)
        {
            var bmp = _img.Get(s.ImageKey);
            if (bmp == null) return Placeholder(w, h, s.GraphicLabel ?? "Изображение недоступно", "");
            var g = new Grid();
            var paths = PathsOf(s);
            double sx = s.Geometry == "custom" ? w / Px.D(Math.Max(1, s.CustW)) : 1 / Units.EmuPerDip;
            double sy = s.Geometry == "custom" ? h / Px.D(Math.Max(1, s.CustH)) : 1 / Units.EmuPerDip;
            var geo = BuildGeometry(paths, s.Geometry == "custom" ? sx / Units.EmuPerDip : sx, s.Geometry == "custom" ? sy / Units.EmuPerDip : sy, true, false);
            var ib = new ImageBrush(bmp) { Stretch = Stretch.Fill };
            if (s.CropL != 0 || s.CropT != 0 || s.CropR != 0 || s.CropB != 0)
            {
                double vw = Math.Max(0.01, 1 - s.CropL - s.CropR), vh = Math.Max(0.01, 1 - s.CropT - s.CropB);
                ib.ViewboxUnits = BrushMappingMode.RelativeToBoundingBox;
                ib.Viewbox = new Rect(s.CropL, s.CropT, vw, vh);
            }
            ib.Freeze();
            if (s.Fill != null && s.Fill.Kind != FillKind.None) g.Children.Add(new System.Windows.Shapes.Path { Data = geo, Fill = FillBrush(s.Fill, 1), Stretch = Stretch.None });
            var path = new System.Windows.Shapes.Path { Data = geo, Fill = ib, Stretch = Stretch.None };
            if (s.Line != null && s.Line.Visible) { path.Stroke = new SolidColorBrush(Px.C(s.Line.Color)); path.StrokeThickness = Math.Max(0.5, Px.D(s.Line.WidthEmu)); path.StrokeDashArray = Dash(s.Line.Dash); }
            if (s.FlipH || s.FlipV) path.RenderTransform = new ScaleTransform(s.FlipH ? -1 : 1, s.FlipV ? -1 : 1, w / 2, h / 2);
            g.Children.Add(path);
            return g;
        }

        FrameworkElement RenderGeometryShape(ShapeModel s, double w, double h, SlideRenderOptions opt, int number, SlideModel slide)
        {
            var g = new Grid();
            var paths = PathsOf(s);
            double sx, sy;
            if (s.Geometry == "custom") { sx = w / Px.D(Math.Max(1, s.CustW)) / Units.EmuPerDip; sy = h / Px.D(Math.Max(1, s.CustH)) / Units.EmuPerDip; }
            else { sx = 1 / Units.EmuPerDip; sy = 1 / Units.EmuPerDip; }
            var shapeLayer = new Canvas { Width = w, Height = h };
            if (s.FlipH || s.FlipV) shapeLayer.RenderTransform = new ScaleTransform(s.FlipH ? -1 : 1, s.FlipV ? -1 : 1, w / 2, h / 2);
            bool hasFill = s.Fill != null && s.Fill.Kind != FillKind.None;
            bool hasLine = s.Line != null && s.Line.Visible;
            Brush stroke = null; double thick = 0;
            if (hasLine) { stroke = new SolidColorBrush(Px.C(s.Line.Color)); stroke.Freeze(); thick = Math.Max(0.75, Px.D(s.Line.WidthEmu)); }
            foreach (var p in paths)
            {
                var geo = BuildGeometry(new List<GeoPath> { p }, sx, sy, false, false);
                var path = new System.Windows.Shapes.Path { Data = geo };
                if (hasFill && p.Filled) path.Fill = FillBrush(s.Fill, p.ShadeFactor);
                if (hasLine && p.Stroked)
                {
                    path.Stroke = stroke; path.StrokeThickness = thick; path.StrokeDashArray = Dash(s.Line.Dash);
                    path.StrokeLineJoin = PenLineJoin.Round;
                    if (s.Line.Dash == "dot" || s.Line.Dash == "sysDot") path.StrokeDashCap = PenLineCap.Round;
                }
                shapeLayer.Children.Add(path);
            }
            if (hasLine && (s.Line.HeadEnd != "none" || s.Line.TailEnd != "none") && paths.Count > 0)
            {
                var pts = paths[0].Cmds.Where(c => c.Type != 'Z').Select(c => c.Type == 'C' ? new Point(c.P[4] * sx, c.P[5] * sy) : new Point(c.P[0] * sx, c.P[1] * sy)).ToList();
                var ctrlBeforeEnd = paths[0].Cmds.LastOrDefault(c => c.Type != 'Z');
                if (pts.Count >= 2)
                {
                    Point endPrev = ctrlBeforeEnd != null && ctrlBeforeEnd.Type == 'C' ? new Point(ctrlBeforeEnd.P[2] * sx, ctrlBeforeEnd.P[3] * sy) : pts[pts.Count - 2];
                    var second = paths[0].Cmds.Count > 1 && paths[0].Cmds[1].Type == 'C' ? new Point(paths[0].Cmds[1].P[0] * sx, paths[0].Cmds[1].P[1] * sy) : pts[1];
                    if (s.Line.HeadEnd != "none") shapeLayer.Children.Add(Arrow(pts[0], second, s.Line.HeadEnd, stroke, thick));
                    if (s.Line.TailEnd != "none") shapeLayer.Children.Add(Arrow(pts[pts.Count - 1], endPrev, s.Line.TailEnd, stroke, thick));
                }
            }
            g.Children.Add(shapeLayer);
            if (s.Text != null && s.Kind != ShapeKind.Connector && opt.HideTextOf != s)
            {
                if (!s.Text.IsEmpty) g.Children.Add(BuildText(s.Text, w, h, number, slide?.HyperlinkColor ?? Rgba.FromRgb(0x0563C1), opt));
                else if (opt.PlaceholderHints && s.PlaceholderType != null) g.Children.Add(HintBox(s, w, h));
            }
            if (opt.PlaceholderHints && s.PlaceholderType != null && s.Text != null && s.Text.IsEmpty && !hasFill && !hasLine)
                g.Children.Insert(0, new Rectangle { Stroke = new SolidColorBrush(Color.FromArgb(150, 120, 120, 140)), StrokeDashArray = new DoubleCollection { 3, 3 }, StrokeThickness = 1 });
            if (opt.Interactive && s.Hyperlink != null && opt.OnLink != null)
            {
                g.Cursor = System.Windows.Input.Cursors.Hand;
                var url = s.Hyperlink;
                g.MouseLeftButtonUp += (o, e) => { e.Handled = true; opt.OnLink(url); };
            }
            return g;
        }

        static FrameworkElement HintBox(ShapeModel s, double w, double h)
        {
            string hint = s.PlaceholderType == "title" || s.PlaceholderType == "ctrTitle" ? "Заголовок слайда" : s.PlaceholderType == "subTitle" ? "Подзаголовок" : s.PlaceholderType == "pic" ? "Рисунок" : "Текст слайда";
            var lv = s.Text.Lvl(0);
            return new TextBlock
            {
                Text = hint, Foreground = new SolidColorBrush(Color.FromArgb(150, 128, 128, 140)), FontSize = Math.Max(6, Px.PtToDip(lv.SizePt * s.Text.FontScale)), FontFamily = Font(lv.Font),
                VerticalAlignment = s.Text.Anchor == "ctr" ? VerticalAlignment.Center : s.Text.Anchor == "b" ? VerticalAlignment.Bottom : VerticalAlignment.Top,
                HorizontalAlignment = lv.Align == "ctr" ? HorizontalAlignment.Center : HorizontalAlignment.Left, Margin = new Thickness(Px.D(s.Text.LIns), Px.D(s.Text.TIns), Px.D(s.Text.RIns), Px.D(s.Text.BIns)), TextWrapping = TextWrapping.Wrap
            };
        }

        static UIElement Arrow(Point tip, Point from, string type, Brush b, double thick)
        {
            double size = Math.Max(6, thick * 3.2);
            var dir = tip - from; if (dir.Length < 0.001) dir = new Vector(1, 0); dir.Normalize();
            var n = new Vector(-dir.Y, dir.X);
            if (type == "oval")
            {
                var e = new Ellipse { Width = size, Height = size, Fill = b };
                Canvas.SetLeft(e, tip.X - size / 2); Canvas.SetTop(e, tip.Y - size / 2); return e;
            }
            PointCollection pc;
            if (type == "diamond") pc = new PointCollection { tip + dir * size / 2, tip + n * size / 2, tip - dir * size / 2, tip - n * size / 2 };
            else if (type == "stealth") pc = new PointCollection { tip, tip - dir * size + n * size / 2, tip - dir * size * 0.65, tip - dir * size - n * size / 2 };
            else pc = new PointCollection { tip, tip - dir * size + n * size / 2, tip - dir * size - n * size / 2 };
            if (type == "arrow") return new Polyline { Points = new PointCollection { tip - dir * size + n * size / 2, tip, tip - dir * size - n * size / 2 }, Stroke = b, StrokeThickness = thick, StrokeLineJoin = PenLineJoin.Round };
            return new Polygon { Points = pc, Fill = b };
        }

        // ---------------- Текст ----------------
        public FrameworkElement BuildText(TextBodyModel t, double w, double h, int slideNumber, Rgba linkColor, SlideRenderOptions opt)
        {
            var panel = new StackPanel();
            var counters = new int[9];
            foreach (var p in t.Paras)
            {
                var tb = new TextBlock { TextWrapping = t.Wrap ? TextWrapping.Wrap : TextWrapping.NoWrap };
                string align = t.EffAlign(p);
                tb.TextAlignment = align == "ctr" ? TextAlignment.Center : align == "r" ? TextAlignment.Right : align == "just" || align == "dist" ? TextAlignment.Justify : TextAlignment.Left;
                var lv = t.Lvl(p.Level);
                double maxSize = 0;
                foreach (var r in p.Runs) maxSize = Math.Max(maxSize, t.EffSize(p, r));
                if (maxSize <= 0) maxSize = p.EndSizePt ?? lv.SizePt;
                double scale = t.FontScale > 0.05 ? t.FontScale : 1;
                double sizeDip = Px.PtToDip(maxSize * scale);
                double pct = t.EffLineSpacing(p) * (1 - t.LnSpcReduction);
                if (Math.Abs(pct - 100) > 0.5) { tb.LineStackingStrategy = LineStackingStrategy.BlockLineHeight; tb.LineHeight = Math.Max(1, sizeDip * 1.2 * pct / 100); }
                double marL = Px.D(lv.MarLEmu), indent = Px.D(lv.IndentEmu);
                bool hasText = p.Runs.Any(r => !string.IsNullOrEmpty(r.Text));
                var bullet = hasText ? t.EffBullet(p) : null;
                if (bullet != null) { for (int i = p.Level + 1; i < 9; i++) counters[i] = 0; counters[p.Level]++; }
                else if (hasText) counters[p.Level] = 0;
                tb.Margin = new Thickness(Math.Max(0, marL + (bullet != null ? Math.Min(0, indent) : Math.Max(0, indent) * 0)), Px.PtToDip(t.EffSpaceBefore(p)), 0, Px.PtToDip(t.EffSpaceAfter(p)));
                if (bullet != null)
                {
                    var first = p.Runs.FirstOrDefault(r => !r.IsBreak);
                    string btxt = bullet[0] == '\u0001' ? Dml.AutoNumber(bullet.Substring(1), counters[p.Level]) : bullet;
                    var br = new Run(btxt + " ") { FontSize = Px.PtToDip(t.EffSize(p, first) * scale), Foreground = Solid(t.EffColor(p, first), opt), FontFamily = bullet[0] == '\u0001' ? Font(t.EffFont(p, first)) : Font("Arial") };
                    tb.Inlines.Add(br);
                }
                foreach (var r in p.Runs)
                {
                    if (r.IsBreak) { tb.Inlines.Add(new LineBreak()); continue; }
                    if (string.IsNullOrEmpty(r.Text)) continue;
                    var run = new Run(r.Text)
                    {
                        FontFamily = Font(t.EffFont(p, r)),
                        FontSize = Math.Max(1, Px.PtToDip(t.EffSize(p, r) * scale)),
                        FontWeight = t.EffBold(p, r) ? FontWeights.Bold : FontWeights.Normal,
                        FontStyle = t.EffItalic(p, r) ? FontStyles.Italic : FontStyles.Normal,
                        Foreground = Solid(r.Hyperlink != null && !r.Color.HasValue ? linkColor : t.EffColor(p, r), opt),
                    };
                    var deco = new TextDecorationCollection();
                    if (t.EffUnderline(p, r) || r.Hyperlink != null) deco.Add(TextDecorations.Underline[0]);
                    if (t.EffStrike(p, r)) deco.Add(TextDecorations.Strikethrough[0]);
                    if (deco.Count > 0) run.TextDecorations = deco;
                    if (r.Hyperlink != null && opt != null && opt.Interactive && opt.OnLink != null)
                    {
                        var hl = new Hyperlink(run) { Foreground = run.Foreground, TextDecorations = run.TextDecorations, Cursor = System.Windows.Input.Cursors.Hand };
                        var url = r.Hyperlink;
                        hl.Click += (s, e) => opt.OnLink(url);
                        tb.Inlines.Add(hl);
                    }
                    else tb.Inlines.Add(run);
                }
                if (tb.Inlines.Count == 0) tb.Inlines.Add(new Run("​") { FontSize = sizeDip, FontFamily = Font(lv.Font) });
                panel.Children.Add(tb);
            }
            var host = new Grid { Margin = new Thickness(Px.D(t.LIns), Px.D(t.TIns), Px.D(t.RIns), Px.D(t.BIns)), ClipToBounds = false };
            panel.VerticalAlignment = t.Anchor == "ctr" ? VerticalAlignment.Center : t.Anchor == "b" ? VerticalAlignment.Bottom : VerticalAlignment.Top;
            if (!t.Wrap)
            {
                var a = t.Paras.Count > 0 ? t.EffAlign(t.Paras[0]) : "l";
                panel.HorizontalAlignment = a == "ctr" ? HorizontalAlignment.Center : a == "r" ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            }
            if (t.Vert == "vert" || t.Vert == "eaVert") panel.LayoutTransform = new RotateTransform(90);
            else if (t.Vert == "vert270") panel.LayoutTransform = new RotateTransform(270);
            host.Children.Add(panel);
            return host;
        }

        static Brush Solid(Rgba c, SlideRenderOptions opt)
        {
            var b = new SolidColorBrush(Px.C(c)); b.Freeze(); return b;
        }

        // ---------------- Таблица ----------------
        FrameworkElement RenderTable(ShapeModel s, SlideRenderOptions opt, int number, SlideModel slide)
        {
            var t = s.Table;
            var grid = new Grid { VerticalAlignment = VerticalAlignment.Top };
            if (t == null) return grid;
            foreach (var cw in t.ColWidths) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Math.Max(1, Px.D(cw))) });
            foreach (var rh in t.RowHeights) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto, MinHeight = Math.Max(1, Px.D(rh)) });
            var accent = Px.C(t.StyleAccent);
            Color band1 = ThemeManager.Mix(accent, Colors.White, 0.62), band2 = ThemeManager.Mix(accent, Colors.White, 0.80);
            for (int r = 0; r < t.Rows.Count && r < grid.RowDefinitions.Count; r++)
            {
                for (int c = 0; c < t.Rows[r].Count && c < grid.ColumnDefinitions.Count; c++)
                {
                    var cell = t.Rows[r][c];
                    if (cell.HMerge || cell.VMerge) continue;
                    bool header = t.FirstRow && r == 0;
                    Brush bg = cell.Fill != null ? FillBrush(cell.Fill, 1) : header ? new SolidColorBrush(accent) : t.BandRow ? new SolidColorBrush(((t.FirstRow ? r - 1 : r) % 2 == 0) ? band1 : band2) : null;
                    var txt = cell.Text;
                    if (header && cell.Fill == null)
                    {
                        txt = txt.Clone();
                        foreach (var l in txt.Levels) { l.Color = Rgba.White; l.Bold = true; }
                    }
                    var b = new Border { Background = bg };
                    var styled = t.FirstRow || t.BandRow;
                    b.BorderBrush = new SolidColorBrush(styled ? Colors.White : Color.FromRgb(160, 160, 170));
                    b.BorderThickness = new Thickness(BW(cell.BorderL, styled), BW(cell.BorderT, styled), BW(cell.BorderR, styled), BW(cell.BorderB, styled));
                    var col = cell.BorderB?.Visible == true ? cell.BorderB.Color : cell.BorderL?.Visible == true ? cell.BorderL.Color : (Rgba?)null;
                    if (col.HasValue) b.BorderBrush = new SolidColorBrush(Px.C(col.Value));
                    var inner = BuildText(txt, 0, 0, number, slide?.HyperlinkColor ?? Rgba.Black, opt);
                    b.Child = inner;
                    Grid.SetRow(b, r); Grid.SetColumn(b, c);
                    if (cell.GridSpan > 1) Grid.SetColumnSpan(b, Math.Min(cell.GridSpan, grid.ColumnDefinitions.Count - c));
                    if (cell.RowSpan > 1) Grid.SetRowSpan(b, Math.Min(cell.RowSpan, grid.RowDefinitions.Count - r));
                    grid.Children.Add(b);
                }
            }
            return grid;
        }

        static double BW(LineDef l, bool styled)
        {
            if (l == null) return styled ? 0.5 : 0.75;
            return l.Visible ? Math.Max(0.5, Px.D(l.WidthEmu) / 2) : 0;
        }

        // ---------------- Растеризация ----------------
        public BitmapSource Rasterize(SlideModel s, int number, double width, SlideRenderOptions opt = null)
        {
            var canvas = RenderSlide(s, number, opt ?? new SlideRenderOptions());
            double scale = width / canvas.Width;
            var host = new Border { Child = canvas, LayoutTransform = new ScaleTransform(scale, scale) };
            host.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            host.Arrange(new Rect(host.DesiredSize));
            host.UpdateLayout();
            int pw = Math.Max(1, (int)Math.Round(canvas.Width * scale)), ph = Math.Max(1, (int)Math.Round(canvas.Height * scale));
            var rtb = new RenderTargetBitmap(pw, ph, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(host);
            rtb.Freeze();
            return rtb;
        }

        public static byte[] Jpeg(BitmapSource b, int quality = 90)
        {
            var enc = new JpegBitmapEncoder { QualityLevel = quality };
            enc.Frames.Add(BitmapFrame.Create(new FormatConvertedBitmap(b, PixelFormats.Bgr24, null, 0)));
            var ms = new MemoryStream(); enc.Save(ms); return ms.ToArray();
        }

        public static byte[] Png(BitmapSource b)
        {
            var enc = new PngBitmapEncoder();
            enc.Frames.Add(BitmapFrame.Create(b));
            var ms = new MemoryStream(); enc.Save(ms); return ms.ToArray();
        }
    }
}
