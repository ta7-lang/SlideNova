// Главное окно: документ, миниатюры, инспектор, команды.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using SlideNova.Core;

namespace SlideNova
{
    public sealed partial class MainWindow
    {
        // ================== Стартовая страница ==================
        void ShowStart()
        {
            _startPage.Children.Clear();
            _startPage.Visibility = Visibility.Visible;
            _startPage.SetResourceReference(Panel.BackgroundProperty, "B.Canvas");
            var sp = new StackPanel { MaxWidth = 620 };
            var head = Ui.Row(Ui.Logo(54), Ui.Spacer(16), Ui.Column(Ui.Text("SlideNova", 30, true), Ui.Text("Безопасный офлайн-редактор презентаций", 14, false, "B.SubText")));
            head.Margin = new Thickness(0, 0, 0, 22);
            sp.Children.Add(head);
            var actions = new WrapPanel();
            actions.Children.Add(Ui.Action("Новая 16:9", () => NewPresentation(12192000, 6858000), true, "\uE8A5"));
            actions.Children.Add(Ui.Action("Новая 4:3", () => NewPresentation(9144000, 6858000), false, "\uE8A5"));
            actions.Children.Add(Ui.Action("Открыть…", OpenDialog, false, "\uE838"));
            sp.Children.Add(actions);
            if (S.KeepRecent && S.Recent.Count > 0)
            {
                var h = Ui.Header("Недавние файлы"); h.Margin = new Thickness(4, 22, 0, 8); sp.Children.Add(h);
                foreach (var r in S.Recent.Take(8))
                {
                    var path = r;
                    var row = Ui.Row(Ui.Icon("\uE8A5", 18), Ui.Spacer(10), Ui.Column(Ui.Text(Path.GetFileName(path), 13.5, true), Ui.Text(Path.GetDirectoryName(path) ?? "", 11.5, false, "B.SubText")));
                    var b = new FancyButton { Content = row, HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(12, 7, 12, 7), Margin = new Thickness(2), Flat = true };
                    b.Click += (s, e) => OpenFile(path);
                    sp.Children.Add(b);
                }
            }
            var tip = Ui.Text("Перетащите файл .pptx, .ppt, .ppsx или .potx в это окно. Макросы, ActiveX, OLE и внешние ссылки блокируются автоматически.", 12, false, "B.Faint", true);
            tip.Margin = new Thickness(4, 24, 0, 0); sp.Children.Add(tip);
            var card = Ui.Card(sp, 30);
            card.HorizontalAlignment = HorizontalAlignment.Center; card.VerticalAlignment = VerticalAlignment.Center; card.Margin = new Thickness(20);
            _startPage.Children.Add(card);
            UpdateStatus();
        }

        // ================== Документ ==================
        public void NewPresentation(long w, long h)
        {
            if (!ConfirmClose()) return;
            var p = Core.Template.NewPresentation(w, h);
            LoadModel(p, null, false, null);
            MarkDirty();
        }

        void OpenDialog()
        {
            var dlg = new OpenFileDialog
            {
                Filter = "Презентации (*.pptx;*.ppt;*.ppsx;*.pps;*.potx;*.pot;*.pptm;*.ppsm;*.potm)|*.pptx;*.ppt;*.ppsx;*.pps;*.potx;*.pot;*.pptm;*.ppsm;*.potm|Все файлы (*.*)|*.*",
                Title = "Открыть презентацию",
                CheckFileExists = true,
                DereferenceLinks = true,
            };
            if (dlg.ShowDialog(this) == true) OpenFile(dlg.FileName);
        }

        public void OpenFile(string path)
        {
            if (!ConfirmClose()) return;
            try
            {
                path = Path.GetFullPath(path);
                if (path.StartsWith(@"\\.\", StringComparison.Ordinal) || path.StartsWith(@"\\?\GLOBALROOT", StringComparison.OrdinalIgnoreCase)) throw new UnsafeFileException("Недопустимый путь к устройству.");
                var fi = new FileInfo(path);
                if (!fi.Exists) throw new FileNotFoundException("Файл не найден: " + path);
                if ((fi.Attributes & FileAttributes.Directory) != 0 || (fi.Attributes & FileAttributes.Device) != 0) throw new UnsafeFileException("Это не обычный файл.");
                if (fi.Length > Limits.MaxFileBytes) throw new UnsafeFileException("Файл слишком большой (" + (fi.Length / 1048576) + " МБ). Предел задаётся в настройках.");
                byte[] data;
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 65536, FileOptions.SequentialScan))
                {
                    data = new byte[fs.Length]; int off = 0, n;
                    while (off < data.Length && (n = fs.Read(data, off, data.Length - off)) > 0) off += n;
                }
                Mouse.OverrideCursor = Cursors.Wait;
                PresentationModel p;
                try { p = PresentationLoader.Load(data); }
                finally { Mouse.OverrideCursor = null; }
                if (p.SourceFormat == "ppt") ConvertLegacyMedia(p);
                string reason = null;
                int zone = Security.ZoneOf(path);
                if (zone >= 3 && S.ProtectedView) reason = "Файл получен из Интернета (зона " + (zone == 3 ? "Интернет" : "Ограниченные узлы") + "). Открыт в защищённом режиме: редактирование отключено.";
                else if (fi.IsReadOnly) reason = "Файл доступен только для чтения. Изменения можно сохранить под другим именем.";
                LoadModel(p, path, reason != null && zone >= 3 && S.ProtectedView, reason);
                if (!(reason != null && fi.IsReadOnly && zone < 3)) { }
                S.AddRecent(path);
                var sec = p.Security;
                if (sec.HasMacros || sec.HasActiveX || sec.OleObjects.Count > 0 || sec.ExternalLinks.Count > 0)
                    ShowBanner("Обнаружено активное содержимое: " + string.Join(", ", new[] { sec.HasMacros ? "макросы VBA" : null, sec.HasActiveX ? "ActiveX" : null, sec.OleObjects.Count > 0 ? "OLE-объекты (" + sec.OleObjects.Count + ")" : null, sec.ExternalLinks.Count > 0 ? "внешние ссылки (" + sec.ExternalLinks.Count + ")" : null }.Where(x => x != null)) + ". Всё заблокировано — ничего не выполняется и не загружается.", false);
                if (p.Warnings.Count > 0 && p.SourceFormat == "ppt") _stHint.Text = p.Warnings[0];
            }
            catch (UnsafeFileException ex) { Dialogs.Error("Файл не открыт", ex.Message); }
            catch (UnauthorizedAccessException) { Dialogs.Error("Нет доступа", "Недостаточно прав для чтения файла."); }
            catch (IOException ex) { Dialogs.Error("Ошибка чтения", ex.Message); }
            catch (Exception ex) { Dialogs.Error("Файл повреждён или не поддерживается", ex.Message); }
        }

        /// <summary>WMF/DIB/TIFF из старого формата переводятся в PNG для надёжной совместимости.</summary>
        static void ConvertLegacyMedia(PresentationModel p)
        {
            foreach (var m in p.Media.Values.ToList())
            {
                if (m.Ext != "wmf" && m.Ext != "bmp" && m.Ext != "tiff") continue;
                try
                {
                    var bmp = ImageCache.Decode(m.Data, m.Ext);
                    if (bmp == null) continue;
                    m.Data = SlideRenderer.Png(bmp); m.Ext = "png"; m.ContentType = "image/png";
                }
                catch { }
            }
        }

        void LoadModel(PresentationModel p, string path, bool protectedView, string reason)
        {
            _pres = p; _path = path; _dirty = false;
            _protected = protectedView; _protectedReason = reason;
            _img = new ImageCache(p);
            _startPage.Visibility = Visibility.Collapsed;
            _ed.ReadOnly = protectedView;
            _ed.Load(p, _img);
            HideBanner();
            if (reason != null) ShowBanner(reason, protectedView);
            RebuildThumbs();
            LoadNotes();
            UpdateTitle(); UpdateStatus(); RebuildRibbon(); OnSelectionChanged();
        }

        void ShowBanner(string text, bool withUnlock)
        {
            var dock = new DockPanel();
            var ic = Ui.Icon("\uEA18", 18); ic.Margin = new Thickness(0, 0, 10, 0); ic.SetResourceReference(TextBlock.ForegroundProperty, "B.OnAccent");
            DockPanel.SetDock(ic, Dock.Left); dock.Children.Add(ic);
            var close = Ui.Small("\uE711", null, "Скрыть", "Скрыть уведомление.", HideBanner);
            DockPanel.SetDock(close, Dock.Right); dock.Children.Add(close);
            if (withUnlock)
            {
                var b = Ui.Action("Разрешить редактирование", () =>
                {
                    if (Dialogs.Ask("Разрешить редактирование?", "Включайте редактирование, только если доверяете источнику файла. Макросы и активное содержимое останутся заблокированными в любом случае.", "Разрешить", "Отмена") == true)
                    { _protected = false; _ed.ReadOnly = false; HideBanner(); UpdateTitle(); _ed.DrawSelection(); }
                });
                DockPanel.SetDock(b, Dock.Right); dock.Children.Add(b);
            }
            var t = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center, FontSize = 13 };
            t.SetResourceReference(TextBlock.ForegroundProperty, "B.OnAccent");
            dock.Children.Add(t);
            _banner.Child = dock;
            _banner.SetResourceReference(Border.BackgroundProperty, "B.AccentH");
            _banner.Visibility = Visibility.Visible;
        }

        void HideBanner() => _banner.Visibility = Visibility.Collapsed;

        bool EnsureEditable()
        {
            if (_pres == null) return false;
            if (_protected) { Dialogs.Info("Защищённый просмотр", "Документ открыт в защищённом режиме. Нажмите «Разрешить редактирование» на жёлтой панели, если доверяете файлу."); return false; }
            return true;
        }

        void MarkDirty() { if (!_dirty) { _dirty = true; UpdateTitle(); } }

        void UpdateTitle()
        {
            var name = _path != null ? Path.GetFileName(_path) : _pres != null ? "Новая презентация" : null;
            Title = (name != null ? (_dirty ? "● " : "") + name + (_protected ? " [защищённый просмотр]" : "") + " — " : "") + "SlideNova";
        }

        bool ConfirmClose()
        {
            if (_pres == null || !_dirty) return true;
            var r = Dialogs.Ask("Сохранить изменения?", "Документ «" + (_path != null ? Path.GetFileName(_path) : "Новая презентация") + "» был изменён.", "Сохранить", "Не сохранять", "Отмена");
            if (r == null) return false;
            if (r == true) return Save(false);
            return true;
        }

        void OnClosing(object sender, CancelEventArgs e)
        {
            _ed.EndTextEdit(true);
            if (!ConfirmClose()) { e.Cancel = true; return; }
            _img?.Clear();
            S.Save();
        }

        bool Save(bool saveAs)
        {
            if (_pres == null) return false;
            _ed.EndTextEdit(true);
            string target = _path;
            string ext = target != null ? Path.GetExtension(target).ToLowerInvariant() : "";
            bool needDialog = saveAs || target == null || _pres.SourceFormat == "ppt" || (ext != ".pptx" && ext != ".ppsx" && ext != ".potx");
            if (_protected && !saveAs) needDialog = true;
            string kind = ext == ".ppsx" ? "ppsx" : ext == ".potx" ? "potx" : "pptx";
            if (needDialog)
            {
                var dlg = new SaveFileDialog
                {
                    Filter = "Презентация PowerPoint (*.pptx)|*.pptx|Демонстрация PowerPoint (*.ppsx)|*.ppsx|Шаблон PowerPoint (*.potx)|*.potx",
                    FileName = target != null ? Path.GetFileNameWithoutExtension(target) : (string.IsNullOrWhiteSpace(_pres.Info.Title) ? "Презентация" : MakeSafeName(_pres.Info.Title)),
                    InitialDirectory = target != null ? Path.GetDirectoryName(target) : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    AddExtension = true, OverwritePrompt = true, Title = "Сохранить презентацию"
                };
                if (dlg.ShowDialog(this) != true) return false;
                target = dlg.FileName;
                kind = dlg.FilterIndex == 2 ? "ppsx" : dlg.FilterIndex == 3 ? "potx" : "pptx";
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                byte[] thumb = null;
                if (S.SaveThumbnail && _pres.Slides.Count > 0)
                    try { thumb = SlideRenderer.Jpeg(_ed.Renderer.Rasterize(_pres.Slides[0], 1, 512), 85); } catch { }
                bool hadMacros = _pres.Security.HasMacros || _pres.Security.HasActiveX;
                var bytes = PptxWriter.Save(_pres, new SaveOptions { Kind = kind, ThumbnailJpeg = thumb, UserName = S.UserName });
                Security.AtomicWrite(target, bytes);
                _path = target; _dirty = false; _protected = false; _ed.ReadOnly = false;
                if (hadMacros) ShowBanner("Сохранено. Из файла удалено: " + string.Join(", ", _pres.Security.RemovedOnSave.Distinct()) + ".", false);
                S.AddRecent(target);
                UpdateTitle();
                _stHint.Text = "Сохранено: " + target;
                return true;
            }
            catch (UnauthorizedAccessException) { Dialogs.Error("Не удалось сохранить", "Нет прав на запись в эту папку или файл открыт только для чтения. Выберите другое место."); }
            catch (IOException ex) { Dialogs.Error("Не удалось сохранить", ex.Message); }
            catch (Exception ex) { Dialogs.Error("Ошибка сохранения", ex.Message); }
            finally { Mouse.OverrideCursor = null; }
            return false;
        }

        static string MakeSafeName(string s)
        {
            foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Length > 80 ? s.Substring(0, 80) : s;
        }

        void OnDrop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            var files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files == null || files.Length == 0) return;
            var f = files[0];
            var ext = Path.GetExtension(f).ToLowerInvariant();
            if (_pres != null && !_protected && (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif" || ext == ".bmp" || ext == ".tif" || ext == ".tiff" || ext == ".emf" || ext == ".wmf" || ext == ".ico"))
                InsertPictureFile(f);
            else Dispatcher.BeginInvoke(new Action(() => OpenFile(f)));
        }

        // ================== Миниатюры ==================
        readonly List<Border> _thumbItems = new List<Border>();

        void RebuildThumbs()
        {
            _thumbs.Children.Clear(); _thumbItems.Clear();
            if (_pres == null) return;
            for (int i = 0; i < _pres.Slides.Count; i++)
            {
                var item = MakeThumb(i);
                _thumbs.Children.Add(item); _thumbItems.Add(item);
            }
            HighlightThumb();
        }

        Border MakeThumb(int i)
        {
            var slide = _pres.Slides[i];
            var img = new Image { Stretch = Stretch.Uniform };
            var renderer = _ed.Renderer;
            img.Stretch = Stretch.Uniform;
            Dispatcher.BeginInvoke(new Action(() => { if (_pres == null || !_pres.Slides.Contains(slide)) return; try { img.Source = renderer.Rasterize(slide, _pres.Slides.IndexOf(slide) + 1, 340); } catch { } }), System.Windows.Threading.DispatcherPriority.Background);
            int ph = Math.Max(1, (int)Math.Round(64 * _pres.SlideH / _pres.SlideW));
            var blank = BitmapSource.Create(64, ph, 96, 96, PixelFormats.Gray8, null, Enumerable.Repeat((byte)235, 64 * ph).ToArray(), 64);
            img.Source = blank;
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            var frame = new Border { Child = img, BorderThickness = new Thickness(0), CornerRadius = new CornerRadius(3), ClipToBounds = true, Opacity = slide.Hidden ? 0.45 : 1 };
            var num = Ui.Text((i + 1).ToString(), 12, true, "B.SubText"); num.Width = 22; num.VerticalAlignment = VerticalAlignment.Top; num.TextAlignment = TextAlignment.Right; num.Margin = new Thickness(0, 2, 6, 0);
            var g = new DockPanel();
            var left = Ui.Column(num);
            if (slide.Hidden) { var hid = Ui.Icon("\uED1A", 11); hid.SetResourceReference(TextBlock.ForegroundProperty, "B.Faint"); hid.ToolTip = "Скрытый слайд"; left.Children.Add(hid); }
            DockPanel.SetDock(left, Dock.Left); g.Children.Add(left); g.Children.Add(frame);
            var b = new Border { Child = g, Padding = new Thickness(4), Margin = new Thickness(0, 3, 0, 3), BorderThickness = new Thickness(2), Cursor = Cursors.Hand, Background = Brushes.Transparent };
            b.SetResourceReference(Border.CornerRadiusProperty, "R.CornerSmall");
            int idx = i;
            Point down = default; bool dragging = false;
            b.MouseLeftButtonDown += (s, e) => { down = e.GetPosition(_thumbs); dragging = false; GoTo(idx); };
            b.MouseMove += (s, e) =>
            {
                if (e.LeftButton != MouseButtonState.Pressed || _protected) return;
                if (!dragging && (e.GetPosition(_thumbs) - down).Length > 8) { dragging = true; DragDrop.DoDragDrop(b, new DataObject("SlideNovaSlide", idx), DragDropEffects.Move); }
            };
            b.AllowDrop = true;
            b.Drop += (s, e) =>
            {
                if (!e.Data.GetDataPresent("SlideNovaSlide")) return;
                int from = (int)e.Data.GetData("SlideNovaSlide");
                e.Handled = true;
                if (from == idx) return;
                PushUndo("Перемещение слайда");
                var sl = _pres.Slides[from]; _pres.Slides.RemoveAt(from); _pres.Slides.Insert(idx, sl);
                AfterStructure(idx);
            };
            var cm = new ContextMenu();
            void MI(string h, Action a) { var m = new MenuItem { Header = h }; m.Click += (o, e) => { GoTo(idx); a(); }; cm.Items.Add(m); }
            MI("Новый слайд", () => NewSlideMenu(b)); MI("Дублировать слайд", DuplicateSlide); MI("Удалить слайд", DeleteSlide);
            MI(slide.Hidden ? "Показать слайд" : "Скрыть слайд", ToggleHidden); MI("Переместить выше", () => MoveSlide(-1)); MI("Переместить ниже", () => MoveSlide(1));
            MI("Показ с этого слайда", () => StartShow(idx));
            cm.SetResourceReference(Control.BackgroundProperty, "B.PanelSolid"); cm.SetResourceReference(Control.ForegroundProperty, "B.Text");
            b.ContextMenu = cm;
            Ui.Tip(b, "Слайд " + (i + 1) + (slide.Hidden ? " (скрыт)" : ""), string.IsNullOrEmpty(slide.Title) ? "Без заголовка" : slide.Title + (string.IsNullOrEmpty(slide.LayoutName) ? "" : "\nМакет: " + slide.LayoutName));
            return b;
        }

        void RefreshThumb(int i)
        {
            if (_pres == null || i < 0 || i >= _pres.Slides.Count || i >= _thumbItems.Count) { RebuildThumbs(); return; }
            var nb = MakeThumb(i);
            _thumbs.Children.RemoveAt(i); _thumbs.Children.Insert(i, nb); _thumbItems[i] = nb;
            HighlightThumb();
        }

        void HighlightThumb()
        {
            for (int i = 0; i < _thumbItems.Count; i++)
            {
                if (i == _ed.SlideIndex) { _thumbItems[i].SetResourceReference(Border.BorderBrushProperty, "B.Accent"); _thumbItems[i].SetResourceReference(Border.BackgroundProperty, "B.AccentSoft"); }
                else { _thumbItems[i].BorderBrush = Brushes.Transparent; _thumbItems[i].Background = Brushes.Transparent; }
            }
            if (_ed.SlideIndex < _thumbItems.Count) _thumbItems[_ed.SlideIndex].BringIntoView();
        }

        void GoTo(int idx)
        {
            if (_pres == null) return;
            _thumbTimer.Stop();
            if (_ed.IsEditingText) { _ed.EndTextEdit(true); RefreshThumb(_ed.SlideIndex); }
            _ed.ShowSlide(idx);
            LoadNotes();
            HighlightThumb();
            UpdateStatus();
        }

        void LoadNotes()
        {
            _suppressNotes = true;
            _notes.Text = _ed.Slide?.Notes ?? "";
            _notes.IsReadOnly = _protected;
            _suppressNotes = false;
        }

        void PushUndo(string label) => _ed.Undo.Push(_pres, _ed.SlideIndex, label);

        void AfterStructure(int newIndex)
        {
            MarkDirty();
            RebuildThumbs();
            _ed.ShowSlide(newIndex);
            LoadNotes(); HighlightThumb(); UpdateStatus();
        }

        // ================== Статус и инспектор ==================
        void UpdateStatus()
        {
            if (_pres == null) { _stSlide.Text = "Документ не открыт"; _stSel.Text = ""; _stSec.Text = "Защита активна"; return; }
            _stSlide.Text = "Слайд " + (_ed.SlideIndex + 1) + " из " + _pres.Slides.Count;
            _stSel.Text = _ed.Selection.Count == 0 ? "" : _ed.Selection.Count == 1 ? _ed.Selection[0].KindName : "Выделено объектов: " + _ed.Selection.Count;
            var sec = _pres.Security;
            _stSec.Text = sec.HasMacros || sec.HasActiveX ? "Активное содержимое заблокировано" : _protected ? "Защищённый просмотр" : "Защищено";
            _stZoom.Text = Math.Round(_ed.Zoom * 100) + "%";
        }

        void OnSelectionChanged()
        {
            UpdateStatus();
            BuildInspector();
            if (_tab == "text") RebuildRibbon();
        }

        static string Cm(double emu) => (emu / Units.EmuPerCm).ToString("0.##", CultureInfo.CurrentCulture);

        void BuildInspector()
        {
            _inspector.Children.Clear();
            if (_pres == null) { _inspector.Children.Add(Ui.Text("Откройте или создайте презентацию.", 12.5, false, "B.SubText", true)); return; }
            var sel = _ed.Selection;
            if (sel.Count == 0)
            {
                var sl = _ed.Slide;
                if (sl == null) return;
                _inspector.Children.Add(Ui.Header("Слайд " + (_ed.SlideIndex + 1)));
                _inspector.Children.Add(Prop("Макет", sl.LayoutName ?? "—"));
                _inspector.Children.Add(Prop("Объектов", sl.Shapes.Count.ToString()));
                _inspector.Children.Add(Prop("Размер", Cm(_pres.SlideW) + " × " + Cm(_pres.SlideH) + " см"));
                _inspector.Children.Add(Ui.Check("Скрытый слайд", sl.Hidden, v => { if (sl.Hidden != v) ToggleHidden(); }, "Скрыть", "Скрытый слайд не показывается при демонстрации."));
                _inspector.Children.Add(Ui.Separator());
                _inspector.Children.Add(Ui.Text("Фон слайда", 12.5, true));
                _inspector.Children.Add(Swatches(c => _ed.ModifySlide("Фон слайда", s => { s.Background = FillDef.Solid(c); s.BackgroundDirty = true; })));
                _inspector.Children.Add(Ui.Separator());
                _inspector.Children.Add(Ui.Text("Подсказка: дважды щёлкните по фигуре, чтобы изменить текст. Перетаскивайте маркеры для изменения размера, круглый маркер — поворот. Shift — сохранить пропорции.", 12, false, "B.Faint", true));
                return;
            }
            if (sel.Count > 1)
            {
                _inspector.Children.Add(Ui.Header("Выделено: " + sel.Count));
                _inspector.Children.Add(Ui.Text("Изменения заливки, контура и текста применятся ко всем выделенным объектам.", 12, false, "B.SubText", true));
                _inspector.Children.Add(Ui.Separator());
                _inspector.Children.Add(Ui.Text("Заливка", 12.5, true));
                _inspector.Children.Add(Swatches(c => _ed.Modify("Заливка", s => { s.Fill = FillDef.Solid(c); s.DirtyFill = true; }, s => s.Kind == ShapeKind.Shape)));
                return;
            }
            var sh = sel[0];
            _inspector.Children.Add(Ui.Header(sh.KindName));
            var nameBox = Ui.Input(sh.Name);
            nameBox.LostKeyboardFocus += (s, e) => { if (nameBox.Text != sh.Name && !_protected) { _ed.Modify("Имя объекта", x => { x.Name = nameBox.Text; MarkOrigName(x); }); } };
            _inspector.Children.Add(Labeled("Имя", nameBox));
            bool ro = _protected || sh.Locked;
            var grid = new Grid { Margin = new Thickness(0, 6, 0, 0) };
            grid.ColumnDefinitions.Add(new ColumnDefinition()); grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.RowDefinitions.Add(new RowDefinition()); grid.RowDefinitions.Add(new RowDefinition()); grid.RowDefinitions.Add(new RowDefinition());
            void Cell(int r, int c, string label, double val, Action<double> set, string tip)
            {
                var nb = Ui.Number(val, 0.1, set, "0.##", 70);
                nb.IsReadOnly = ro;
                var lb = Labeled(label, nb); Ui.Tip(lb, label, tip, "↑/↓, колесо мыши");
                Grid.SetRow(lb, r); Grid.SetColumn(lb, c); grid.Children.Add(lb);
            }
            Cell(0, 0, "X, см", sh.X / Units.EmuPerCm, v => _ed.Modify("Положение", x => { x.X = v * Units.EmuPerCm; x.DirtyXfrm = true; }), "Расстояние от левого края слайда.");
            Cell(0, 1, "Y, см", sh.Y / Units.EmuPerCm, v => _ed.Modify("Положение", x => { x.Y = v * Units.EmuPerCm; x.DirtyXfrm = true; }), "Расстояние от верхнего края слайда.");
            Cell(1, 0, "Ширина, см", sh.W / Units.EmuPerCm, v => _ed.Modify("Размер", x => { x.W = Math.Max(0, v) * Units.EmuPerCm; x.DirtyXfrm = true; }), "Ширина объекта.");
            Cell(1, 1, "Высота, см", sh.H / Units.EmuPerCm, v => _ed.Modify("Размер", x => { x.H = Math.Max(0, v) * Units.EmuPerCm; x.DirtyXfrm = true; }), "Высота объекта.");
            var rot = Ui.Number(sh.Rot, 1, v => _ed.Modify("Поворот", x => { x.Rot = ((v % 360) + 360) % 360; x.DirtyXfrm = true; }), "0.#", 70);
            rot.IsReadOnly = ro;
            var rl = Labeled("Поворот, °", rot); Grid.SetRow(rl, 2); grid.Children.Add(rl);
            _inspector.Children.Add(grid);
            if (sh.Kind == ShapeKind.Shape || sh.Kind == ShapeKind.Connector)
            {
                _inspector.Children.Add(Ui.Separator());
                if (sh.Kind == ShapeKind.Shape)
                {
                    _inspector.Children.Add(Ui.Text("Заливка", 12.5, true));
                    _inspector.Children.Add(Swatches(c => _ed.Modify("Заливка", s => { s.Fill = FillDef.Solid(c); s.DirtyFill = true; })));
                    var op = Ui.Slider(0, 100, sh.Fill.Kind == FillKind.Solid ? sh.Fill.Color.A / 2.55 : 100, v => { }, 200);
                    op.PreviewMouseLeftButtonUp += (s, e) => _ed.Modify("Прозрачность", x => { if (x.Fill.Kind == FillKind.Solid) { x.Fill.Color = x.Fill.Color.WithAlpha((byte)(op.Value * 2.55)); x.DirtyFill = true; } });
                    var opl = Labeled("Непрозрачность заливки", op); Ui.Tip(opl, "Непрозрачность", "0% — полностью прозрачная заливка, 100% — сплошная.");
                    _inspector.Children.Add(opl);
                }
                _inspector.Children.Add(Ui.Text("Контур", 12.5, true));
                _inspector.Children.Add(Swatches(c => _ed.Modify("Контур", s => { s.Line = s.Line?.Clone() ?? new LineDef(); s.Line.Visible = true; s.Line.Color = c; s.DirtyLine = true; })));
                var lw = Ui.Number(sh.Line.Visible ? sh.Line.WidthEmu / Units.EmuPerPt : 0, 0.25, v => _ed.Modify("Толщина контура", x => { x.Line = x.Line.Clone(); x.Line.WidthEmu = Math.Max(0, v) * Units.EmuPerPt; x.Line.Visible = v > 0; x.DirtyLine = true; }), "0.##", 70);
                _inspector.Children.Add(Labeled("Толщина, пт", lw));
            }
            if (sh.Kind == ShapeKind.Picture && _pres.Media.TryGetValue(sh.ImageKey ?? "", out var mi))
            {
                _inspector.Children.Add(Ui.Separator());
                var bmp = _img.Get(sh.ImageKey);
                _inspector.Children.Add(Prop("Формат", (mi.Ext ?? "").ToUpperInvariant()));
                _inspector.Children.Add(Prop("Размер данных", (mi.Data.Length / 1024.0).ToString("0.#") + " КБ"));
                if (bmp != null) _inspector.Children.Add(Prop("Пиксели", bmp.PixelWidth + " × " + bmp.PixelHeight));
                _inspector.Children.Add(Ui.Action("Исходный размер", () => _ed.Modify("Сброс размера", x => { if (bmp != null) { x.W = Px.E(bmp.PixelWidth * 96 / Math.Max(1, bmp.DpiX)); x.H = Px.E(bmp.PixelHeight * 96 / Math.Max(1, bmp.DpiY)); x.DirtyXfrm = true; } })));
            }
            if (sh.Kind == ShapeKind.Table) { _inspector.Children.Add(Ui.Separator()); _inspector.Children.Add(Ui.Action("Редактировать таблицу", () => EditTable(sh), true, "\uE70F")); }
            if (sh.Kind == ShapeKind.Graphic) _inspector.Children.Add(Ui.Text("Этот объект (" + sh.GraphicLabel + ") отображается в режиме просмотра. Его можно перемещать и изменять размер; содержимое сохраняется без изменений.", 12, false, "B.SubText", true));
            if (sh.Hyperlink != null) { _inspector.Children.Add(Ui.Separator()); _inspector.Children.Add(Prop("Ссылка", sh.Hyperlink)); }
            _inspector.Children.Add(Ui.Separator());
            var alt = Ui.Input(sh.AltText ?? ""); alt.TextWrapping = TextWrapping.Wrap; alt.AcceptsReturn = false;
            alt.LostKeyboardFocus += (s, e) => { if ((sh.AltText ?? "") != alt.Text && !_protected) _ed.Modify("Замещающий текст", x => { x.AltText = alt.Text; MarkOrigName(x); }); };
            var altl = Labeled("Замещающий текст", alt); Ui.Tip(altl, "Замещающий текст", "Описание объекта для экранных дикторов и при недоступности изображения.");
            _inspector.Children.Add(altl);
        }

        static void MarkOrigName(ShapeModel s)
        {
            if (s.Original == null) return;
            var c = s.Original.Descendants().FirstOrDefault(e => e.Name.LocalName == "cNvPr");
            if (c == null) return;
            var copy = new System.Xml.Linq.XElement(s.Original);
            var cc = copy.Descendants().First(e => e.Name.LocalName == "cNvPr");
            cc.SetAttributeValue("name", s.Name);
            cc.SetAttributeValue("descr", string.IsNullOrEmpty(s.AltText) ? null : s.AltText);
            s.Original = copy;
            s.DirtyXfrm = true;
        }

        FrameworkElement Prop(string k, string v)
        {
            var g = new DockPanel { Margin = new Thickness(0, 2, 0, 2) };
            var kt = Ui.Text(k, 12, false, "B.SubText"); kt.Width = 110; DockPanel.SetDock(kt, Dock.Left);
            g.Children.Add(kt); var vt = Ui.Text(v, 12, false, "B.Text", true); g.Children.Add(vt);
            return g;
        }

        static FrameworkElement Labeled(string label, FrameworkElement control)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 3, 6, 3) };
            sp.Children.Add(Ui.Text(label, 11.5, false, "B.SubText"));
            control.Margin = new Thickness(0, 2, 0, 0);
            if (control is TextBox) control.HorizontalAlignment = HorizontalAlignment.Stretch;
            sp.Children.Add(control);
            return sp;
        }

        IEnumerable<Rgba> ThemeColors()
        {
            var th = _pres?.Theme;
            foreach (var k in new[] { "dk1", "lt1", "dk2", "lt2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6" })
                if (th != null && th.Colors.TryGetValue(k, out var c)) yield return c;
        }

        FrameworkElement Swatches(Action<Rgba> pick)
        {
            var w = new WrapPanel { Margin = new Thickness(0, 4, 0, 6) };
            var cols = ThemeColors().Concat(new[] { 0xC00000, 0xFF0000, 0xFFC000, 0xFFFF00, 0x92D050, 0x00B050, 0x00B0F0, 0x0070C0, 0x002060, 0x7030A0 }.Select(Rgba.FromRgb)).ToList();
            foreach (var c in cols)
            {
                var col = c;
                var b = new FancyButton { Content = Ui.Swatch(Px.C(c), 16, false), Padding = new Thickness(2), Margin = new Thickness(1), Flat = true };
                b.Click += (s, e) => { if (EnsureEditable()) pick(col); };
                b.ToolTip = "#" + c.Hex;
                w.Children.Add(b);
            }
            var more = new FancyButton { Content = Ui.Icon("\uE710", 12), Padding = new Thickness(4), Margin = new Thickness(1), Flat = true };
            more.Click += (s, e) => { if (!EnsureEditable()) return; var r = ColorPicker.Show(Rgba.FromRgb(0x4472C4), ThemeColors().ToList()); if (r.HasValue) pick(r.Value); };
            Ui.Tip(more, "Другие цвета", "Палитра, HEX-код, RGB и прозрачность.");
            w.Children.Add(more);
            return w;
        }

        // ================== Клавиатура ==================
        void OnKey(object sender, KeyEventArgs e)
        {
            var mods = Keyboard.Modifiers;
            bool ctrl = mods.HasFlag(ModifierKeys.Control), shift = mods.HasFlag(ModifierKeys.Shift);
            var key = e.Key == Key.System ? e.SystemKey : e.Key;
            bool inText = _ed.IsEditingText;
            bool inInput = Keyboard.FocusedElement is TextBox;
            if (ctrl)
            {
                switch (key)
                {
                    case Key.N: NewPresentation(12192000, 6858000); e.Handled = true; return;
                    case Key.O: OpenDialog(); e.Handled = true; return;
                    case Key.S: Save(shift); e.Handled = true; return;
                    case Key.P: PrintNow(); e.Handled = true; return;
                    case Key.F: ShowFind(false); e.Handled = true; return;
                    case Key.H: ShowFind(true); e.Handled = true; return;
                    case Key.M: NewSlideMenu(null); e.Handled = true; return;
                    case Key.D0: case Key.NumPad0: _ed.Fit(); e.Handled = true; return;
                    case Key.OemPlus: case Key.Add: _ed.SetZoom(_ed.Zoom * 1.15); e.Handled = true; return;
                    case Key.OemMinus: case Key.Subtract: _ed.SetZoom(_ed.Zoom / 1.15); e.Handled = true; return;
                }
                if (inText)
                {
                    switch (key)
                    {
                        case Key.E: ParaAlign("ctr"); e.Handled = true; break;
                        case Key.L: ParaAlign("l"); e.Handled = true; break;
                        case Key.R: ParaAlign("r"); e.Handled = true; break;
                        case Key.J: ParaAlign("just"); e.Handled = true; break;
                        case Key.OemCloseBrackets: GrowFont(1); e.Handled = true; break;
                        case Key.OemOpenBrackets: GrowFont(-1); e.Handled = true; break;
                    }
                    return;
                }
                if (inInput) return;
                switch (key)
                {
                    case Key.Z: DoUndo(); e.Handled = true; break;
                    case Key.Y: DoRedo(); e.Handled = true; break;
                    case Key.C: Copy(); e.Handled = true; break;
                    case Key.X: Cut(); e.Handled = true; break;
                    case Key.V: Paste(); e.Handled = true; break;
                    case Key.D: Duplicate(); e.Handled = true; break;
                    case Key.A: _ed.SelectAll(); e.Handled = true; break;
                    case Key.G: if (shift) UngroupSel(); else GroupSel(); e.Handled = true; break;
                    case Key.B: ToggleStyle("b"); e.Handled = true; break;
                    case Key.I: ToggleStyle("i"); e.Handled = true; break;
                    case Key.U: ToggleStyle("u"); e.Handled = true; break;
                    case Key.E: ParaAlign("ctr"); e.Handled = true; break;
                    case Key.L: ParaAlign("l"); e.Handled = true; break;
                    case Key.R: ParaAlign("r"); e.Handled = true; break;
                    case Key.OemCloseBrackets: if (shift) Arrange(2); else Arrange(1); e.Handled = true; break;
                    case Key.OemOpenBrackets: if (shift) Arrange(-2); else Arrange(-1); e.Handled = true; break;
                    case Key.Up: MoveSlide(-1); e.Handled = true; break;
                    case Key.Down: MoveSlide(1); e.Handled = true; break;
                }
                return;
            }
            if (key == Key.F5) { StartShow(shift ? _ed.SlideIndex : 0); e.Handled = true; return; }
            if (mods == ModifierKeys.Alt && key == Key.Enter) { ShowProperties(); e.Handled = true; return; }
            if (inText || inInput) return;
            if (_pres != null && !_ed.ReadOnly && (mods == ModifierKeys.None || mods == ModifierKeys.Shift))
            {
                double step = shift ? 10 : 1;
                if (_ed.Selection.Count > 0)
                {
                    switch (key)
                    {
                        case Key.Left: _ed.Nudge(-step, 0); e.Handled = true; return;
                        case Key.Right: _ed.Nudge(step, 0); e.Handled = true; return;
                        case Key.Up: _ed.Nudge(0, -step); e.Handled = true; return;
                        case Key.Down: _ed.Nudge(0, step); e.Handled = true; return;
                        case Key.Delete: _ed.DeleteSelection(); e.Handled = true; return;
                        case Key.F2:
                        case Key.Enter: if (_ed.Selection.Count == 1 && _ed.Selection[0].Kind == ShapeKind.Shape) { _ed.BeginTextEdit(_ed.Selection[0]); e.Handled = true; return; } if (_ed.Selection.Count == 1 && _ed.Selection[0].Kind == ShapeKind.Table) { EditTable(_ed.Selection[0]); e.Handled = true; return; } break;
                    }
                }
                if (key == Key.Escape) { if (_ed.Tool != null) { _ed.SetTool(null); RebuildRibbon(); } else _ed.ClearSelection(); e.Handled = true; return; }
            }
            if (key == Key.PageDown) { GoTo(Math.Min(_ed.SlideIndex + 1, (_pres?.Slides.Count ?? 1) - 1)); e.Handled = true; }
            else if (key == Key.PageUp) { GoTo(Math.Max(0, _ed.SlideIndex - 1)); e.Handled = true; }
            else if (key == Key.Delete && _ed.Selection.Count == 0 && _thumbScroll.IsKeyboardFocusWithin) { DeleteSlide(); e.Handled = true; }
        }

        // ================== История и буфер ==================
        void DoUndo()
        {
            if (_pres == null || _protected) return;
            _ed.EndTextEdit(true);
            if (!_ed.Undo.CanUndo) return;
            int idx = _ed.Undo.Undo(_pres, _ed.SlideIndex);
            AfterUndoRedo(idx);
        }

        void DoRedo()
        {
            if (_pres == null || _protected || !_ed.Undo.CanRedo) return;
            int idx = _ed.Undo.Redo(_pres, _ed.SlideIndex);
            AfterUndoRedo(idx);
        }

        void AfterUndoRedo(int idx)
        {
            _ed.ReplaceAfterUndo(idx);
            MarkDirty(); RebuildThumbs(); LoadNotes(); UpdateStatus(); _ed.Fit();
            if (_tab == "home") RebuildRibbon();
        }

        void Copy()
        {
            if (_pres == null || _ed.Selection.Count == 0) return;
            ShapeClipboard.Items = _ed.Selection.Select(s => s.Clone()).ToList();
            ShapeClipboard.Source = _pres; ShapeClipboard.SourceSlide = _ed.Slide;
            var txt = string.Join("\n", _ed.Selection.Where(s => s.Text != null && !s.Text.IsEmpty).Select(s => s.Text.PlainText));
            try
            {
                var data = new DataObject();
                data.SetData("SlideNovaShapes", "1");
                if (!string.IsNullOrEmpty(txt)) data.SetData(DataFormats.UnicodeText, txt);
                Clipboard.SetDataObject(data, false);
            }
            catch { }
            _stHint.Text = "Скопировано объектов: " + ShapeClipboard.Items.Count;
        }

        void Cut() { if (!EnsureEditable()) return; Copy(); _ed.DeleteSelection(); }

        void Paste()
        {
            if (!EnsureEditable()) return;
            try
            {
                bool ours = false;
                try { ours = Clipboard.ContainsData("SlideNovaShapes"); } catch { }
                if (!ours && Clipboard.ContainsImage()) { PasteImage(); return; }
                if (!ours && Clipboard.ContainsText()) { InsertTextBox(Clipboard.GetText()); return; }
                if (ShapeClipboard.Items.Count > 0)
                {
                    var items = new List<ShapeModel>();
                    bool sameSlide = ShapeClipboard.Source == _pres && ShapeClipboard.SourceSlide == _ed.Slide;
                    bool samePres = ShapeClipboard.Source == _pres;
                    int skipped = 0;
                    foreach (var s in ShapeClipboard.Items)
                    {
                        var c = s.Clone();
                        if (!sameSlide || c.Original != null)
                        {
                            if (!c.CanDetach) { skipped++; continue; }
                            c.Detach();
                        }
                        if (!samePres) CopyMediaFrom(ShapeClipboard.Source, c);
                        if (sameSlide) { c.X += Px.E(18); c.Y += Px.E(18); }
                        c.PlaceholderType = null; c.PlaceholderIdx = null; c.Locked = false;
                        items.Add(c);
                    }
                    ShapeClipboard.Items = ShapeClipboard.Items.Select(s => { var c = s.Clone(); if (sameSlide) { c.X += Px.E(18); c.Y += Px.E(18); } return c; }).ToList();
                    if (items.Count > 0) _ed.AddShapes(items, "Вставка");
                    if (skipped > 0) _stHint.Text = "Диаграммы/SmartArt/OLE нельзя перенести на другой слайд — пропущено: " + skipped;
                    return;
                }
                if (Clipboard.ContainsText()) InsertTextBox(Clipboard.GetText());
            }
            catch (Exception ex) { Dialogs.Error("Вставка не выполнена", ex.Message); }
        }

        void CopyMediaFrom(PresentationModel src, ShapeModel s)
        {
            void Fix(ShapeModel x)
            {
                if (x.ImageKey != null && src.Media.TryGetValue(x.ImageKey, out var m)) x.ImageKey = _pres.AddMedia(m.Data, m.Ext);
                if (x.Fill?.Kind == FillKind.Image && x.Fill.ImageKey != null && src.Media.TryGetValue(x.Fill.ImageKey, out var m2)) x.Fill.ImageKey = _pres.AddMedia(m2.Data, m2.Ext);
                if (x.Children != null) foreach (var k in x.Children) Fix(k);
            }
            Fix(s);
        }

        void Duplicate()
        {
            if (!EnsureEditable() || _ed.Selection.Count == 0) return;
            var items = new List<ShapeModel>();
            foreach (var s in _ed.Selection)
            {
                if (!s.CanDetach) continue;
                var c = s.Clone(); c.Detach(); c.X += Px.E(18); c.Y += Px.E(18); c.PlaceholderType = null; c.PlaceholderIdx = null;
                items.Add(c);
            }
            if (items.Count > 0) _ed.AddShapes(items, "Дублирование");
        }

        // ================== Слайды ==================
        void NewSlideMenu(UIElement anchor)
        {
            if (!EnsureEditable()) return;
            if (_pres.Layouts.Count == 0) { InsertSlide(Core.Template.NewSlide(_pres, null)); return; }
            Ui.Pick(anchor ?? (UIElement)_thumbScroll, _pres.Layouts, l =>
            {
                var sl = Core.Template.NewSlide(_pres, l);
                Image img = null;
                try { img = new Image { Source = _ed.Renderer.Rasterize(sl, 0, 120, new SlideRenderOptions { PlaceholderHints = true }), Width = 96 }; } catch { }
                return Ui.Row(img ?? (UIElement)Ui.Spacer(96), Ui.Spacer(10), Ui.Text(l.Name, 13));
            }, l => InsertSlide(Core.Template.NewSlide(_pres, l)), 460, 300);
        }

        void InsertSlide(SlideModel s)
        {
            PushUndo("Новый слайд");
            int at = Math.Min(_ed.SlideIndex + 1, _pres.Slides.Count);
            _pres.Slides.Insert(at, s);
            AfterStructure(at);
        }

        void DuplicateSlide()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            _ed.EndTextEdit(true);
            PushUndo("Дублирование слайда");
            var c = _ed.Slide.Clone();
            c.RelsSource = _ed.Slide.RelsSource ?? _ed.Slide.PartName; c.PartName = null; c.NotesPartName = null; c.NotesDirty = !string.IsNullOrEmpty(c.Notes);
            c.OrigSldId = 0;
            int at = _ed.SlideIndex + 1;
            _pres.Slides.Insert(at, c);
            AfterStructure(at);
        }

        void DeleteSlide()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            if (_pres.Slides.Count <= 1) { Dialogs.Info("Нельзя удалить", "В презентации должен остаться хотя бы один слайд."); return; }
            PushUndo("Удаление слайда");
            int idx = _ed.SlideIndex;
            _pres.Slides.RemoveAt(idx);
            AfterStructure(Math.Min(idx, _pres.Slides.Count - 1));
        }

        void ToggleHidden()
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            PushUndo("Скрытие слайда");
            _ed.Slide.Hidden = !_ed.Slide.Hidden; _ed.Slide.HiddenDirty = true;
            MarkDirty(); RefreshThumb(_ed.SlideIndex); BuildInspector();
        }

        void MoveSlide(int dir)
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            int i = _ed.SlideIndex, j = i + dir;
            if (j < 0 || j >= _pres.Slides.Count) return;
            PushUndo("Перемещение слайда");
            var s = _pres.Slides[i]; _pres.Slides.RemoveAt(i); _pres.Slides.Insert(j, s);
            AfterStructure(j);
        }

        void SetSlideSize(long w, long h)
        {
            if (!EnsureEditable()) return;
            if (Math.Abs(_pres.SlideW - w) < 1 && Math.Abs(_pres.SlideH - h) < 1) return;
            PushUndo("Размер слайда");
            double k = Math.Min(w / _pres.SlideW, h / _pres.SlideH);
            double ox = (w - _pres.SlideW * k) / 2, oy = (h - _pres.SlideH * k) / 2;
            foreach (var sl in _pres.Slides)
                foreach (var s in sl.Shapes)
                {
                    s.X = s.X * k + ox; s.Y = s.Y * k + oy; s.W *= k; s.H *= k; s.DirtyXfrm = true;
                    if (s.Table != null) { s.Table.ColWidths = s.Table.ColWidths.Select(x => x * k).ToList(); s.Table.RowHeights = s.Table.RowHeights.Select(x => x * k).ToList(); s.DirtyTable = true; }
                }
            _pres.SlideW = w; _pres.SlideH = h; _pres.SizeDirty = true;
            AfterStructure(_ed.SlideIndex);
            _ed.Fit();
            _stHint.Text = "Размер слайда изменён, содержимое отмасштабировано. Оформление образца слайдов сохраняет исходную разметку.";
        }

        // ================== Вставка ==================
        void InsertTextBox(string text)
        {
            if (!EnsureEditable() || _ed.Slide == null) return;
            var th = _pres.Theme;
            var s = new ShapeModel { IsTextBox = true, Name = "Надпись", Fill = FillDef.NoFill(), Line = LineDef.None() };
            s.Text = TextBodyModel.FromPlain(text, new LevelStyle { SizePt = 20, Font = th.MinorFont, Color = th.Colors.TryGetValue("dk1", out var dk) ? dk : Rgba.Black });
            s.Text.AutoFitShape = true;
            int lines = Math.Max(1, text.Split('\n').Length);
            s.W = Math.Min(_pres.SlideW * 0.6, Px.E(Math.Max(120, Math.Min(900, text.Split('\n').Max(l => l.Length) * 11 + 30))));
            s.H = Px.E(Math.Min(lines, 20) * 32 + 12);
            s.X = (_pres.SlideW - s.W) / 2; s.Y = (_pres.SlideH - s.H) / 2;
            _ed.AddShapes(new[] { s }, "Вставка текста");
        }

        void InsertPicture()
        {
            if (!EnsureEditable()) return;
            var dlg = new OpenFileDialog { Filter = "Изображения|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff;*.ico;*.emf;*.wmf|Все файлы|*.*", Title = "Вставить рисунок" };
            if (dlg.ShowDialog(this) == true) InsertPictureFile(dlg.FileName);
        }

        void InsertPictureFile(string path)
        {
            try
            {
                var fi = new FileInfo(path);
                if (fi.Length > 100L * 1024 * 1024) throw new UnsafeFileException("Изображение больше 100 МБ.");
                var data = File.ReadAllBytes(path);
                var ext = Path.GetExtension(path).TrimStart('.').ToLowerInvariant();
                if (ext == "jpg") ext = "jpeg"; if (ext == "tif") ext = "tiff";
                var bmp = ImageCache.Decode(data, ext);
                if (bmp == null) throw new UnsafeFileException("Файл не является поддерживаемым изображением.");
                if (ext == "gif" || ext == "ico" || ext == "wmf" || ext == "tiff" || ext == "bmp") { data = SlideRenderer.Png(bmp); ext = "png"; }
                AddPictureShape(data, ext, bmp, Path.GetFileNameWithoutExtension(path));
            }
            catch (Exception ex) { Dialogs.Error("Рисунок не вставлен", ex.Message); }
        }

        void PasteImage()
        {
            if (!EnsureEditable()) return;
            try
            {
                if (!Clipboard.ContainsImage()) { _stHint.Text = "В буфере обмена нет изображения"; return; }
                var src = Clipboard.GetImage();
                if (src == null) return;
                var bmp = new FormatConvertedBitmap(src, PixelFormats.Bgra32, null, 0); bmp.Freeze();
                AddPictureShape(SlideRenderer.Png(bmp), "png", bmp, "Рисунок");
            }
            catch (Exception ex) { Dialogs.Error("Не удалось вставить изображение", ex.Message); }
        }

        void AddPictureShape(byte[] data, string ext, BitmapSource bmp, string name)
        {
            var key = _pres.AddMedia(data, ext);
            double w = Px.E(bmp.PixelWidth * 96 / Math.Max(1, bmp.DpiX)), h = Px.E(bmp.PixelHeight * 96 / Math.Max(1, bmp.DpiY));
            double k = Math.Min(1, Math.Min(_pres.SlideW * 0.7 / w, _pres.SlideH * 0.7 / h));
            w *= k; h *= k;
            var s = new ShapeModel { Kind = ShapeKind.Picture, ImageKey = key, Name = name, W = w, H = h, X = (_pres.SlideW - w) / 2, Y = (_pres.SlideH - h) / 2, Fill = FillDef.NoFill(), Line = LineDef.None() };
            _ed.AddShapes(new[] { s }, "Вставка рисунка");
        }

        void EditTable(ShapeModel s)
        {
            if (!EnsureEditable() || s?.Table == null) return;
            var th = _pres.Theme;
            var c = s.Clone();
            if (TableDialog.Edit(c, th.Colors.TryGetValue("dk1", out var dk) ? dk : Rgba.Black, th.MinorFont))
                _ed.Modify("Правка таблицы", x => { x.Table = c.Table; x.W = c.W; x.H = c.H; x.DirtyTable = true; x.DirtyXfrm = true; }, x => x == s);
        }

        void InsertTable()
        {
            if (!EnsureEditable()) return;
            var r = TableDialog.Show();
            if (r == null) return;
            int rows = r.Item1, cols = r.Item2;
            var th = _pres.Theme;
            var t = new TableModel { FirstRow = true, BandRow = true, StyleAccent = th.Colors.TryGetValue("accent1", out var ac) ? ac : Rgba.FromRgb(0x4472C4) };
            double w = _pres.SlideW * 0.8;
            for (int c = 0; c < cols; c++) t.ColWidths.Add(w / cols);
            for (int i = 0; i < rows; i++)
            {
                t.RowHeights.Add(370840);
                var row = new List<Core.TableCell>();
                for (int c = 0; c < cols; c++)
                {
                    var cell = new Core.TableCell { Text = TextBodyModel.FromPlain(i == 0 ? "Заголовок " + (c + 1) : "", new LevelStyle { SizePt = 18, Font = th.MinorFont, Color = th.Colors.TryGetValue("dk1", out var dk) ? dk : Rgba.Black }) };
                    row.Add(cell);
                }
                t.Rows.Add(row);
            }
            var s = new ShapeModel { Kind = ShapeKind.Table, Table = t, Name = "Таблица", W = w, H = 370840.0 * rows, X = (_pres.SlideW - w) / 2, Y = _pres.SlideH * 0.25 };
            _ed.AddShapes(new[] { s }, "Вставка таблицы");
            _stHint.Text = "Дважды щёлкните по таблице, чтобы ввести текст в ячейки, добавить строки или столбцы.";
        }
    }
}
