// Окно свойств: файл, документ, слайды, содержимое, безопасность, структура пакета.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SlideNova.Core;

namespace SlideNova
{
    public sealed class PropertiesWindow : ThemedWindow
    {
        readonly PresentationModel _p;
        readonly string _path;
        readonly ImageCache _img;
        readonly bool _protected;
        readonly Action _onChanged;
        readonly ContentControl _host = new ContentControl();
        readonly StringBuilder _report = new StringBuilder();
        readonly Dictionary<string, FancyButton> _tabs = new Dictionary<string, FancyButton>();

        public PropertiesWindow(PresentationModel p, string path, ImageCache img, bool prot, Action onChanged)
        {
            _p = p; _path = path; _img = img; _protected = prot; _onChanged = onChanged;
            Title = "Свойства — " + (path != null ? Path.GetFileName(path) : "Новая презентация");
            Width = 900; Height = 720; ResizeMode = ResizeMode.CanResize;
            var dock = new DockPanel { Margin = new Thickness(14) };
            var head = Ui.Row(Ui.Logo(36), Ui.Spacer(12), Ui.Column(Ui.Text(path != null ? Path.GetFileName(path) : "Новая презентация", 18, true), Ui.Text(path ?? "Ещё не сохранена", 12, false, "B.SubText")));
            head.Margin = new Thickness(0, 0, 0, 12);
            DockPanel.SetDock(head, Dock.Top); dock.Children.Add(head);
            var tabs = new WrapPanel { Margin = new Thickness(0, 0, 0, 10) };
            void Tab(string id, string label, string glyph, Func<UIElement> build)
            {
                var b = new FancyButton { Content = Ui.Row(Ui.Icon(glyph, 13), Ui.Spacer(6), new TextBlock { Text = label }), Padding = new Thickness(12, 6, 12, 6), Margin = new Thickness(2) };
                b.Click += (s, e) => { foreach (var x in _tabs.Values) x.IsToggled = x == b; _host.Content = Wrap(build()); };
                _tabs[id] = b; tabs.Children.Add(b);
            }
            Tab("file", "Файл", "", FileTab);
            Tab("doc", "Документ", "", DocTab);
            Tab("slides", "Слайды", "", SlidesTab);
            Tab("content", "Содержимое", "", ContentTab);
            Tab("sec", "Безопасность", "", SecurityTab);
            Tab("pkg", "Структура файла", "", PackageTab);
            DockPanel.SetDock(tabs, Dock.Top); dock.Children.Add(tabs);
            var btns = Ui.Row(Ui.Action("Копировать отчёт", CopyReport, false, ""), Ui.Action("Закрыть", Close, true));
            btns.HorizontalAlignment = HorizontalAlignment.Right; btns.Margin = new Thickness(0, 10, 0, 0);
            DockPanel.SetDock(btns, Dock.Bottom); dock.Children.Add(btns);
            dock.Children.Add(Ui.Card(_host, 14));
            Content = dock;
            _tabs["file"].IsToggled = true;
            _host.Content = Wrap(FileTab());
        }

        static UIElement Wrap(UIElement e) => new ScrollViewer { Content = e, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };

        StackPanel _cur;
        StackPanel Begin(string title) { _cur = new StackPanel(); _cur.Children.Add(Ui.Header(title)); _report.AppendLine("== " + title + " =="); return _cur; }

        void Row(string k, string v, string brush = "B.Text")
        {
            var g = new Grid { Margin = new Thickness(0, 3, 0, 3) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) }); g.ColumnDefinitions.Add(new ColumnDefinition());
            var kt = Ui.Text(k, 12.5, false, "B.SubText"); kt.VerticalAlignment = VerticalAlignment.Top;
            var vt = new TextBox { Text = v ?? "—", IsReadOnly = true, BorderThickness = new Thickness(0), Background = Brushes.Transparent, TextWrapping = TextWrapping.Wrap, FontSize = 12.5, Padding = new Thickness(0) };
            vt.SetResourceReference(ForegroundProperty, brush);
            Grid.SetColumn(vt, 1); g.Children.Add(kt); g.Children.Add(vt);
            _cur.Children.Add(g);
            _report.AppendLine(k + ": " + v);
        }

        void Sub(string t) { var x = Ui.Text(t, 13.5, true); x.Margin = new Thickness(0, 14, 0, 4); _cur.Children.Add(x); _report.AppendLine("-- " + t); }

        static string Size(long b) => b < 1024 ? b + " Б" : b < 1048576 ? (b / 1024.0).ToString("0.##") + " КБ (" + b.ToString("N0") + " Б)" : (b / 1048576.0).ToString("0.##") + " МБ (" + b.ToString("N0") + " Б)";
        static string Dt(DateTime d) => d.ToString("dddd, d MMMM yyyy, HH:mm:ss", new CultureInfo("ru-RU"));
        static string Iso(string s) => DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var d) ? Dt(d.ToLocalTime()) : (string.IsNullOrEmpty(s) ? "—" : s);

        UIElement FileTab()
        {
            var sp = Begin("Сведения о файле");
            if (_path == null || !File.Exists(_path)) { Row("Состояние", "Презентация ещё не сохранена на диск"); return sp; }
            var fi = new FileInfo(_path);
            Row("Имя файла", fi.Name);
            Row("Папка", fi.DirectoryName);
            Row("Расширение", fi.Extension);
            Row("Размер на диске", Size(fi.Length));
            byte[] data = null;
            try { if (fi.Length <= Limits.MaxFileBytes) data = File.ReadAllBytes(_path); } catch { }
            if (data != null)
            {
                var fmt = FormatDetect.Detect(data);
                Row("Фактический формат (по содержимому)", FormatDetect.Describe(fmt));
                var ext = fi.Extension.ToLowerInvariant();
                bool mismatch = (fmt == FileFormat.Ooxml && (ext == ".ppt" || ext == ".pps" || ext == ".pot")) || (fmt == FileFormat.Ppt && ext.EndsWith("x"));
                if (mismatch) Row("Внимание", "Расширение не соответствует содержимому файла — файл открыт по фактическому формату.", "B.Accent2Solid");
                using (var sha = SHA256.Create()) Row("Контрольная сумма SHA-256", BitConverter.ToString(sha.ComputeHash(data)).Replace("-", ""));
            }
            Row("Тип содержимого презентации", _p.MainContentType ?? (_p.SourceFormat == "ppt" ? "application/vnd.ms-powerpoint" : "—"));
            Sub("Даты файловой системы");
            Row("Создан", Dt(fi.CreationTime));
            Row("Изменён", Dt(fi.LastWriteTime));
            Row("Открыт", Dt(fi.LastAccessTime));
            Sub("Атрибуты");
            var at = fi.Attributes;
            Row("Только чтение", (at & FileAttributes.ReadOnly) != 0 ? "да" : "нет");
            Row("Скрытый", (at & FileAttributes.Hidden) != 0 ? "да" : "нет");
            Row("Системный", (at & FileAttributes.System) != 0 ? "да" : "нет");
            Row("Архивный", (at & FileAttributes.Archive) != 0 ? "да" : "нет");
            Row("Сжатый / зашифрованный (NTFS)", ((at & FileAttributes.Compressed) != 0 ? "сжат " : "") + ((at & FileAttributes.Encrypted) != 0 ? "зашифрован EFS" : "") + ((at & (FileAttributes.Compressed | FileAttributes.Encrypted)) == 0 ? "нет" : ""));
            int zone = Security.ZoneOf(_path);
            Row("Происхождение (метка зоны)", zone < 0 ? "Локальный файл (метки нет)" : zone == 3 ? "Загружен из Интернета (зона 3)" : zone == 4 ? "Ограниченные узлы (зона 4)" : zone == 2 ? "Надёжные узлы (зона 2)" : zone == 1 ? "Локальная сеть (зона 1)" : "Компьютер (зона 0)");
            Row("Режим открытия", _protected ? "Защищённый просмотр (только чтение)" : "Редактирование");
            return sp;
        }

        UIElement DocTab()
        {
            var sp = Begin("Свойства документа");
            var info = _p.Info;
            sp.Children.Add(Ui.Text("Эти поля можно изменить — они сохранятся в файле.", 12, false, "B.Faint"));
            void Edit(string label, Func<string> get, Action<string> set)
            {
                var tb = Ui.Input(get()); tb.IsReadOnly = _protected;
                tb.LostKeyboardFocus += (s, e) => { if (tb.Text != get()) { set(tb.Text); info.Dirty = true; _onChanged(); } };
                var g = new Grid { Margin = new Thickness(0, 3, 0, 3) };
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) }); g.ColumnDefinitions.Add(new ColumnDefinition());
                g.Children.Add(Ui.Text(label, 12.5, false, "B.SubText")); Grid.SetColumn(tb, 1); g.Children.Add(tb);
                sp.Children.Add(g);
                _report.AppendLine(label + ": " + get());
            }
            Edit("Название", () => info.Title, v => info.Title = v);
            Edit("Тема", () => info.Subject, v => info.Subject = v);
            Edit("Автор", () => info.Creator, v => info.Creator = v);
            Edit("Ключевые слова", () => info.Keywords, v => info.Keywords = v);
            Edit("Категория", () => info.Category, v => info.Category = v);
            Edit("Примечание", () => info.Description, v => info.Description = v);
            Sub("Служебные сведения");
            Row("Последним изменил", info.LastModifiedBy);
            Row("Редакция", info.Revision);
            Row("Создан (по документу)", Iso(info.Created));
            Row("Изменён (по документу)", Iso(info.Modified));
            Row("Статус", info.ContentStatus);
            Row("Язык", info.Language);
            Row("Приложение", (info.Application + " " + info.AppVersion).Trim());
            Row("Организация", info.Company);
            Row("Руководитель", info.Manager);
            Row("Шаблон", info.Template);
            Row("Общее время правки", string.IsNullOrEmpty(info.TotalTime) ? "—" : info.TotalTime + " мин.");
            Row("Формат показа", info.PresentationFormat);
            return sp;
        }

        static string Ratio(double w, double h)
        {
            double r = w / h;
            var known = new[] { (16.0 / 9, "16:9"), (4.0 / 3, "4:3"), (16.0 / 10, "16:10"), (1.0, "1:1"), (9906000.0 / 6858000, "A4 (альбомный)"), (3.0 / 2, "3:2"), (2.35, "2,35:1 (кино)") };
            foreach (var k in known) if (Math.Abs(r - k.Item1) < 0.01) return k.Item2;
            return r.ToString("0.###", CultureInfo.CurrentCulture) + ":1";
        }

        UIElement SlidesTab()
        {
            var sp = Begin("Слайды");
            Row("Количество слайдов", _p.Slides.Count.ToString());
            Row("Скрытых", _p.Slides.Count(s => s.Hidden).ToString());
            Row("С заметками", _p.Slides.Count(s => !string.IsNullOrWhiteSpace(s.Notes)).ToString());
            Row("Размер слайда", (_p.SlideW / Units.EmuPerCm).ToString("0.##") + " × " + (_p.SlideH / Units.EmuPerCm).ToString("0.##") + " см  ·  " + (_p.SlideW / Units.EmuPerInch).ToString("0.##") + " × " + (_p.SlideH / Units.EmuPerInch).ToString("0.##") + " дюйма  ·  " + Math.Round(Px.D(_p.SlideW)) + " × " + Math.Round(Px.D(_p.SlideH)) + " пикс. (96 dpi)");
            Row("Соотношение сторон", Ratio(_p.SlideW, _p.SlideH) + (_p.SlideW >= _p.SlideH ? ", альбомная" : ", книжная"));
            Row("Образцов слайдов", _p.MasterCount.ToString());
            Row("Макетов", _p.Layouts.Count + (_p.Layouts.Count > 0 ? ": " + string.Join(", ", _p.Layouts.Select(l => l.Name)) : ""));
            Sub("По слайдам");
            var grid = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            string[] heads = { "№", "Заголовок", "Макет", "Объекты", "Рисунки", "Таблицы", "Слов", "Заметки" };
            double[] widths = { 34, 240, 150, 64, 60, 60, 56, 60 };
            foreach (var w in widths) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(w) });
            grid.RowDefinitions.Add(new RowDefinition());
            for (int c = 0; c < heads.Length; c++) { var t = Ui.Text(heads[c], 12, true, "B.SubText"); Grid.SetColumn(t, c); grid.Children.Add(t); }
            for (int i = 0; i < _p.Slides.Count && i < 2000; i++)
            {
                var s = _p.Slides[i];
                var all = Flatten(s.Shapes).ToList();
                int words = all.Where(x => x.Text != null).Sum(x => Words(x.Text.PlainText)) + all.Where(x => x.Table != null).Sum(x => x.Table.Rows.Sum(r => r.Sum(c => Words(c.Text.PlainText))));
                string[] vals = { (i + 1) + (s.Hidden ? "*" : ""), string.IsNullOrEmpty(s.Title) ? "—" : s.Title, s.LayoutName ?? "—", all.Count.ToString(), all.Count(x => x.Kind == ShapeKind.Picture).ToString(), all.Count(x => x.Kind == ShapeKind.Table).ToString(), words.ToString(), string.IsNullOrWhiteSpace(s.Notes) ? "нет" : "есть" };
                grid.RowDefinitions.Add(new RowDefinition());
                for (int c = 0; c < vals.Length; c++) { var t = Ui.Text(vals[c], 12); t.TextTrimming = TextTrimming.CharacterEllipsis; t.Margin = new Thickness(0, 2, 6, 2); Grid.SetRow(t, i + 1); Grid.SetColumn(t, c); grid.Children.Add(t); }
                _report.AppendLine(string.Join(" | ", vals));
            }
            sp.Children.Add(grid);
            sp.Children.Add(Ui.Text("* — скрытый слайд", 11.5, false, "B.Faint"));
            return sp;
        }

        static IEnumerable<ShapeModel> Flatten(IEnumerable<ShapeModel> list)
        {
            foreach (var s in list)
            {
                yield return s;
                if (s.Children != null) foreach (var k in Flatten(s.Children)) yield return k;
            }
        }

        static int Words(string s) => string.IsNullOrWhiteSpace(s) ? 0 : s.Split(new[] { ' ', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;

        UIElement ContentTab()
        {
            var sp = Begin("Содержимое");
            var all = _p.Slides.SelectMany(s => Flatten(s.Shapes)).ToList();
            Row("Всего объектов", all.Count.ToString());
            Row("Фигуры", all.Count(s => s.Kind == ShapeKind.Shape && !s.IsTextBox && s.PlaceholderType == null).ToString());
            Row("Надписи и заполнители", all.Count(s => s.Kind == ShapeKind.Shape && (s.IsTextBox || s.PlaceholderType != null)).ToString());
            Row("Линии и соединители", all.Count(s => s.Kind == ShapeKind.Connector).ToString());
            Row("Рисунки", all.Count(s => s.Kind == ShapeKind.Picture).ToString());
            Row("Таблицы", all.Count(s => s.Kind == ShapeKind.Table).ToString());
            Row("Группы", all.Count(s => s.Kind == ShapeKind.Group).ToString());
            var graphics = all.Where(s => s.Kind == ShapeKind.Graphic).GroupBy(s => s.GraphicLabel ?? "Объект").Select(g => g.Key + ": " + g.Count()).ToList();
            Row("Диаграммы / SmartArt / OLE / медиа", graphics.Count == 0 ? "нет" : string.Join(", ", graphics));
            var texts = all.Where(s => s.Text != null).Select(s => s.Text.PlainText).Concat(all.Where(s => s.Table != null).SelectMany(s => s.Table.Rows.SelectMany(r => r.Select(c => c.Text.PlainText)))).ToList();
            Row("Слов на слайдах", texts.Sum(Words).ToString("N0"));
            Row("Символов (без пробелов)", texts.Sum(t => t.Count(ch => !char.IsWhiteSpace(ch))).ToString("N0"));
            Row("Абзацев", all.Where(s => s.Text != null).Sum(s => s.Text.Paras.Count(p => !string.IsNullOrWhiteSpace(p.PlainText))).ToString("N0"));
            Row("Слов в заметках", _p.Slides.Sum(s => Words(s.Notes)).ToString("N0"));
            var fonts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in all.Where(x => x.Text != null))
                foreach (var p in s.Text.Paras) foreach (var r in p.Runs.Where(r => !r.IsBreak && !string.IsNullOrEmpty(r.Text))) fonts.Add(s.Text.EffFont(p, r));
            var installed = new HashSet<string>(Fonts.SystemFontFamilies.Select(f => f.Source), StringComparer.OrdinalIgnoreCase);
            Row("Используемые шрифты", fonts.Count == 0 ? "—" : string.Join(", ", fonts.OrderBy(f => f).Select(f => installed.Contains(f) ? f : f + " (не установлен — заменён)")));
            Sub("Тема оформления");
            Row("Название темы", string.IsNullOrEmpty(_p.Theme.Name) ? "—" : _p.Theme.Name);
            Row("Шрифты темы", "заголовки: " + _p.Theme.MajorFont + ", основной текст: " + _p.Theme.MinorFont);
            var sw = new WrapPanel { Margin = new Thickness(230, 4, 0, 6) };
            foreach (var kv in _p.Theme.Colors)
            {
                var b = Ui.Swatch(Px.C(kv.Value), 24, false); b.Margin = new Thickness(2); b.ToolTip = kv.Key + " — #" + kv.Value.Hex;
                sw.Children.Add(b);
            }
            sp.Children.Add(sw);
            _report.AppendLine("Цвета темы: " + string.Join(", ", _p.Theme.Colors.Select(kv => kv.Key + "=#" + kv.Value.Hex)));
            Sub("Внедрённые изображения и медиа");
            var used = new HashSet<string>(all.Select(s => s.ImageKey).Where(k => k != null).Concat(all.Where(s => s.Fill?.Kind == FillKind.Image).Select(s => s.Fill.ImageKey)), StringComparer.OrdinalIgnoreCase);
            long total = 0; int count = 0;
            foreach (var kv in _p.Media.OrderBy(k => k.Key))
            {
                if (!used.Contains(kv.Key) && _p.Slides.All(s => s.Background?.ImageKey != kv.Key)) continue;
                count++; total += kv.Value.Data?.Length ?? 0;
                var bmp = _img.Get(kv.Key);
                Row(Path.GetFileName(kv.Value.PartName ?? kv.Key), (kv.Value.Ext ?? "").ToUpperInvariant() + ", " + Size(kv.Value.Data?.Length ?? 0) + (bmp != null ? ", " + bmp.PixelWidth + "×" + bmp.PixelHeight + " пикс." : ", не отображается"));
                if (count > 300) break;
            }
            if (count == 0) Row("Изображения", "нет");
            else Row("Итого изображений", count + ", " + Size(total));
            return sp;
        }

        UIElement SecurityTab()
        {
            var sp = Begin("Безопасность");
            var sec = _p.Security;
            void Item(bool danger, string title, string text)
            {
                var ic = Ui.Icon(danger ? "" : "", 16);
                ic.Foreground = danger ? new SolidColorBrush(Color.FromRgb(255, 170, 40)) : new SolidColorBrush(Color.FromRgb(40, 200, 120));
                ic.Margin = new Thickness(0, 2, 10, 0); ic.VerticalAlignment = VerticalAlignment.Top;
                var row = new DockPanel { Margin = new Thickness(0, 4, 0, 4) };
                DockPanel.SetDock(ic, Dock.Left); row.Children.Add(ic);
                row.Children.Add(Ui.Column(Ui.Text(title, 13, true), Ui.Text(text, 12, false, "B.SubText", true)));
                sp.Children.Add(row);
                _report.AppendLine((danger ? "[!] " : "[ok] ") + title + " — " + text);
            }
            int risks = (sec.HasMacros ? 1 : 0) + (sec.HasActiveX ? 1 : 0) + (sec.OleObjects.Count > 0 ? 1 : 0) + (sec.ExternalLinks.Count > 0 ? 1 : 0);
            var verdict = Ui.Card(Ui.Text(risks == 0 ? "Активного или внешнего содержимого не обнаружено. Файл безопасен для просмотра." : "Обнаружено потенциально опасных элементов: " + risks + ". Все они заблокированы — ничего не выполняется, не загружается и не запускается.", 13, true, "B.Text", true), 10);
            verdict.Margin = new Thickness(0, 0, 0, 10);
            sp.Children.Add(verdict);
            Item(sec.HasMacros, "Макросы VBA", sec.HasMacros ? "Обнаружены. Никогда не выполняются; при сохранении удаляются." : "Отсутствуют.");
            Item(sec.HasActiveX, "Элементы ActiveX", sec.HasActiveX ? "Обнаружены. Не создаются и не активируются; удаляются при сохранении." : "Отсутствуют.");
            Item(sec.OleObjects.Count > 0, "Внедрённые OLE-объекты", sec.OleObjects.Count > 0 ? "Не запускаются, показывается только изображение: " + string.Join("; ", sec.OleObjects.Take(20)) : "Отсутствуют.");
            Item(sec.ExternalLinks.Count > 0, "Внешние ссылки на ресурсы", sec.ExternalLinks.Count > 0 ? "Не загружаются (программа не обращается к сети): " + string.Join("; ", sec.ExternalLinks.Take(20)) : "Отсутствуют.");
            var bad = sec.Hyperlinks.Where(h => !Security.IsSafeUrl(h, out _)).ToList();
            Item(bad.Count > 0, "Гиперссылки", sec.Hyperlinks.Count == 0 ? "Нет." : "Всего: " + sec.Hyperlinks.Count + (bad.Count > 0 ? ". Заблокированы как небезопасные: " + string.Join("; ", bad.Take(10)) : ". Все используют безопасные схемы (http/https/mailto).") + (sec.Hyperlinks.Count > 0 ? "\n" + string.Join("\n", sec.Hyperlinks.Take(30)) : ""));
            Item(false, "Внедрённые шрифты", sec.HasEmbeddedFonts ? "Есть, но не загружаются в систему (используются установленные шрифты)." : "Отсутствуют.");
            Item(false, "Цифровая подпись", sec.HasSignature ? "Документ подписан. После изменения и сохранения подпись станет недействительной." : "Отсутствует.");
            Item(false, "Комментарии рецензентов", sec.HasComments ? "Присутствуют (сохраняются без изменений)." : "Отсутствуют.");
            Item(false, "Пользовательские XML-данные", sec.HasCustomXml ? "Присутствуют (не обрабатываются)." : "Отсутствуют.");
            Item(_p.Warnings.Count > 0, "Целостность файла", _p.Warnings.Count == 0 ? "Структура прочитана без ошибок." : string.Join("\n", _p.Warnings.Take(15)));
            if (sec.Notes.Count > 0) { Sub("Примечания"); foreach (var n in sec.Notes) Row("•", n); }
            Sub("Защита программы");
            Row("Чтение файла", "Только в память; тип определяется по сигнатуре; защита от zip-бомб, XXE и пиксельных бомб; лимиты размеров.");
            Row("Сеть", "Программа не выполняет сетевых запросов.");
            Row("Кэш и временные файлы", "Не создаются. Эскизы и изображения хранятся только в памяти и освобождаются при закрытии.");
            Row("Меры Windows", Hardening.Applied.Count == 0 ? "—" : string.Join("; ", Hardening.Applied));
            return sp;
        }

        UIElement PackageTab()
        {
            var sp = Begin("Структура файла");
            if (_p.SourceFormat == "ppt")
            {
                Row("Контейнер", "Составной документ OLE2 (PowerPoint 97–2003)");
                Sub("Потоки");
                foreach (var s in _p.CfbStreams.Take(500)) Row("•", s);
                return sp;
            }
            var pkg = _p.Package;
            if (pkg == null) return sp;
            Row("Частей в пакете", pkg.Parts.Count.ToString());
            Row("Распакованный размер", Size(pkg.TotalUncompressed > 0 ? pkg.TotalUncompressed : pkg.Parts.Sum(p => (long)p.Value.Length)));
            if (pkg.Anomalies.Count > 0) Row("Аномалии", string.Join("; ", pkg.Anomalies), "B.Accent2Solid");
            Sub("Части");
            foreach (var kv in pkg.Parts.OrderBy(k => k.Key).Take(2000))
                Row(kv.Key, Size(kv.Value.Length) + " · " + (pkg.ContentTypeOf(kv.Key) ?? "тип не указан"));
            return sp;
        }

        void CopyReport()
        {
            _report.Clear();
            foreach (var f in new Func<UIElement>[] { FileTab, DocTab, SlidesTab, ContentTab, SecurityTab }) f();
            try { Clipboard.SetText(_report.ToString()); Dialogs.Info("Готово", "Полный отчёт о файле скопирован в буфер обмена."); } catch { }
        }
    }
}
