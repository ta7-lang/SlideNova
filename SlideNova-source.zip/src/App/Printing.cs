// Печать: слайды, выдачи (2/3/4/6/9), страницы заметок, структура; цвет/серый/Ч-Б; предпросмотр. PDF-экспорт.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Printing;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SlideNova.Core;

namespace SlideNova
{
    public sealed class PrintWindow : ThemedWindow
    {
        readonly PresentationModel _p;
        readonly SlideRenderer _r;
        readonly int _current;
        readonly string _docName;
        readonly DocumentViewer _viewer = new DocumentViewer();
        string _mode = "full"; int _perPage = 6; string _range = "all"; string _custom = ""; bool _hidden; string _color = "color"; string _orient = "auto"; bool _frame = true; bool _headers = true;
        double _pageW = 793.7, _pageH = 1122.5;
        readonly TextBlock _info = Ui.Text("", 12, false, "B.SubText", true);

        public PrintWindow(PresentationModel p, ImageCache img, int current, string docName)
        {
            _p = p; _r = new SlideRenderer(p, img); _current = current; _docName = docName;
            var S = AppSettings.Current; _mode = S.PrintMode ?? "full"; _perPage = S.PrintPerPage;
            Title = "Печать — " + docName; Width = 1180; Height = 820; ResizeMode = ResizeMode.CanResize; WindowStartupLocation = WindowStartupLocation.CenterOwner;
            var root = new Grid { Margin = new Thickness(12) };
            root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(320) });
            root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
            root.ColumnDefinitions.Add(new ColumnDefinition());
            var opts = new StackPanel();
            opts.Children.Add(Ui.Header("Параметры печати"));
            opts.Children.Add(Section("Что печатать"));
            opts.Children.Add(Radio("mode", "Слайды — по одному на странице", _mode == "full", () => { _mode = "full"; Refresh(); }, "Каждый слайд занимает весь лист."));
            opts.Children.Add(Radio("mode", "Выдачи — несколько слайдов на листе", _mode == "handout", () => { _mode = "handout"; Refresh(); }, "Раздаточный материал для слушателей. При 3 слайдах на листе справа печатаются линии для заметок."));
            var per = new WrapPanel { Margin = new Thickness(24, 2, 0, 4) };
            foreach (var n in new[] { 2, 3, 4, 6, 9 })
            {
                int k = n;
                var b = new FancyButton { Content = n.ToString(), MinWidth = 34, Margin = new Thickness(2), IsToggled = _perPage == n };
                b.Click += (s, e) => { _perPage = k; _mode = "handout"; foreach (FancyButton x in per.Children) x.IsToggled = x == b; Refresh(); };
                Ui.Tip(b, n + " слайд(а/ов) на листе", null);
                per.Children.Add(b);
            }
            opts.Children.Add(per);
            opts.Children.Add(Radio("mode", "Страницы заметок", _mode == "notes", () => { _mode = "notes"; Refresh(); }, "Слайд вверху листа и заметки докладчика под ним."));
            opts.Children.Add(Radio("mode", "Структура (только текст)", _mode == "outline", () => { _mode = "outline"; Refresh(); }, "Заголовки и текст всех слайдов списком — экономит чернила."));
            opts.Children.Add(Section("Диапазон"));
            opts.Children.Add(Radio("range", "Все слайды", true, () => { _range = "all"; Refresh(); }, null));
            opts.Children.Add(Radio("range", "Текущий слайд (" + (current + 1) + ")", false, () => { _range = "cur"; Refresh(); }, null));
            var custom = Ui.Input("", 150); custom.Margin = new Thickness(24, 2, 0, 2);
            custom.TextChanged += (s, e) => { _custom = custom.Text; if (_range == "custom") Refresh(); };
            opts.Children.Add(Radio("range", "Слайды, например 1-3, 5", false, () => { _range = "custom"; Refresh(); }, "Номера слайдов и диапазоны через запятую."));
            opts.Children.Add(custom);
            opts.Children.Add(Ui.Check("Печатать скрытые слайды", _hidden, v => { _hidden = v; Refresh(); }));
            opts.Children.Add(Section("Цвет"));
            opts.Children.Add(Radio("color", "Цветная", true, () => { _color = "color"; Refresh(); }, "Векторная печать в полном цвете."));
            opts.Children.Add(Radio("color", "Оттенки серого", false, () => { _color = "gray"; Refresh(); }, "Для монохромных принтеров, сохраняет полутона."));
            opts.Children.Add(Radio("color", "Чёрно-белая", false, () => { _color = "bw"; Refresh(); }, "Только чёрный и белый — максимальная экономия тонера."));
            opts.Children.Add(Section("Ориентация и оформление"));
            opts.Children.Add(Radio("or", "Автоматически", true, () => { _orient = "auto"; Refresh(); }, "Альбомная для слайдов, книжная для выдач, заметок и структуры."));
            opts.Children.Add(Radio("or", "Книжная", false, () => { _orient = "portrait"; Refresh(); }, null));
            opts.Children.Add(Radio("or", "Альбомная", false, () => { _orient = "landscape"; Refresh(); }, null));
            opts.Children.Add(Ui.Check("Рамка вокруг слайдов", _frame, v => { _frame = v; Refresh(); }));
            opts.Children.Add(Ui.Check("Колонтитулы (имя, дата, номер страницы)", _headers, v => { _headers = v; Refresh(); }));
            var btns = Ui.Row(Ui.Action("Печать…", DoPrint, true, ""), Ui.Action("Закрыть", Close));
            btns.Margin = new Thickness(0, 14, 0, 6);
            opts.Children.Add(btns);
            opts.Children.Add(_info);
            var optScroll = new ScrollViewer { Content = opts, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(4, 0, 10, 0) };
            var card = Ui.Card(optScroll, 12);
            root.Children.Add(card);
            var vb = Ui.Card(_viewer, 4); Grid.SetColumn(vb, 2); root.Children.Add(vb);
            Content = root;
            Loaded += (s, e) => Refresh();
        }

        static TextBlock Section(string t) { var x = Ui.Text(t, 12.5, true, "B.SubText"); x.Margin = new Thickness(0, 12, 0, 4); return x; }

        static RadioButton Radio(string group, string label, bool check, Action act, string tip)
        {
            var r = new RadioButton { GroupName = group, Content = label, IsChecked = check, Margin = new Thickness(0, 3, 0, 3), FontSize = 13 };
            r.SetResourceReference(ForegroundProperty, "B.Text");
            r.Checked += (s, e) => act();
            if (tip != null) Ui.Tip(r, label, tip);
            return r;
        }

        List<int> Slides()
        {
            var all = Enumerable.Range(0, _p.Slides.Count).ToList();
            List<int> res;
            if (_range == "cur") res = new List<int> { _current };
            else if (_range == "custom") res = ParseRange(_custom, _p.Slides.Count);
            else res = all;
            if (!_hidden && _range != "cur") res = res.Where(i => !_p.Slides[i].Hidden).ToList();
            return res;
        }

        public static List<int> ParseRange(string s, int count)
        {
            var res = new List<int>();
            foreach (var part in (s ?? "").Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var ab = part.Split('-', '–');
                if (ab.Length == 2 && int.TryParse(ab[0], out var a) && int.TryParse(ab[1], out var b)) { for (int i = Math.Max(1, a); i <= Math.Min(count, b); i++) res.Add(i - 1); }
                else if (int.TryParse(part, out var n) && n >= 1 && n <= count) res.Add(n - 1);
            }
            return res.Distinct().ToList();
        }

        bool Landscape()
        {
            if (_orient == "landscape") return true;
            if (_orient == "portrait") return false;
            return _mode == "full" && _p.SlideW >= _p.SlideH;
        }

        void Refresh()
        {
            try
            {
                bool land = Landscape();
                double a = Math.Max(_pageW, _pageH), b = Math.Min(_pageW, _pageH);
                var doc = Build(land ? a : b, land ? b : a);
                _viewer.Document = doc;
                _info.Text = "Страниц: " + doc.Pages.Count + ". Размер листа в предпросмотре: " + (_pageW / 96 * 2.54).ToString("0.#") + " × " + (_pageH / 96 * 2.54).ToString("0.#") + " см.";
            }
            catch (Exception ex) { _info.Text = "Не удалось построить предпросмотр: " + ex.Message; }
        }

        void DoPrint()
        {
            try
            {
                AppSettings.Current.PrintMode = _mode; AppSettings.Current.PrintPerPage = _perPage; AppSettings.Current.Save();
                var pd = new PrintDialog { UserPageRangeEnabled = false };
                try { pd.PrintTicket.PageOrientation = Landscape() ? PageOrientation.Landscape : PageOrientation.Portrait; } catch { }
                if (pd.ShowDialog() != true) return;
                double w = pd.PrintableAreaWidth, h = pd.PrintableAreaHeight;
                if (w < 100 || h < 100) { w = 793.7; h = 1122.5; }
                _pageW = Math.Min(w, h); _pageH = Math.Max(w, h);
                bool land = Landscape();
                var doc = Build(land ? Math.Max(w, h) : Math.Min(w, h), land ? Math.Min(w, h) : Math.Max(w, h));
                pd.PrintDocument(doc.DocumentPaginator, "SlideNova — " + _docName);
                Refresh();
                _info.Text = "Задание отправлено на принтер «" + (pd.PrintQueue?.FullName ?? "") + "».";
            }
            catch (Exception ex)
            {
                Dialogs.Error("Печать не выполнена", ex.Message + "\n\nПроверьте, что принтер установлен и доступен. Также можно выбрать «Microsoft Print to PDF» или воспользоваться экспортом в PDF.");
            }
        }

        // ---------------- Построение документа ----------------
        FixedDocument Build(double pw, double ph)
        {
            var doc = new FixedDocument();
            doc.DocumentPaginator.PageSize = new Size(pw, ph);
            var slides = Slides();
            const double M = 36;
            double top = _headers ? M + 18 : M, bottom = _headers ? M + 18 : M;
            int pageNo = 0;
            int totalPages = _mode == "full" || _mode == "notes" ? slides.Count : _mode == "handout" ? (slides.Count + _perPage - 1) / Math.Max(1, _perPage) : 0;
            FixedPage NewPage()
            {
                var fp = new FixedPage { Width = pw, Height = ph, Background = Brushes.White };
                pageNo++;
                return fp;
            }
            void AddPage(FixedPage fp)
            {
                if (_headers) Headers(fp, pw, ph, pageNo, M);
                var pc = new PageContent { Child = fp }; doc.Pages.Add(pc);
            }
            double sw = _p.SlideW, sh = _p.SlideH;
            switch (_mode)
            {
                case "full":
                    foreach (var i in slides)
                    {
                        var fp = NewPage();
                        Place(fp, i, new Rect(M, top, pw - 2 * M, ph - top - bottom));
                        AddPage(fp);
                    }
                    break;
                case "notes":
                    foreach (var i in slides)
                    {
                        var fp = NewPage();
                        double areaH = (ph - top - bottom) * 0.48;
                        var r = Place(fp, i, new Rect(M, top, pw - 2 * M, areaH));
                        var notes = _p.Slides[i].Notes;
                        var tb = new TextBlock { Text = string.IsNullOrWhiteSpace(notes) ? "(заметок нет)" : notes, TextWrapping = TextWrapping.Wrap, FontSize = 13, FontFamily = new FontFamily("Segoe UI"), Foreground = string.IsNullOrWhiteSpace(notes) ? Brushes.Gray : Brushes.Black, Width = pw - 2 * M - 20 };
                        FixedPage.SetLeft(tb, M + 10); FixedPage.SetTop(tb, r.Bottom + 24);
                        tb.MaxHeight = ph - r.Bottom - 24 - bottom;
                        fp.Children.Add(tb);
                        AddPage(fp);
                    }
                    break;
                case "handout":
                    {
                        int n = Math.Max(1, _perPage);
                        int cols = n == 2 || n == 3 ? 1 : n == 4 || n == 6 ? 2 : 3;
                        int rows = (n + cols - 1) / cols;
                        if (pw > ph && (n == 6)) { cols = 3; rows = 2; }
                        for (int start = 0; start < slides.Count; start += n)
                        {
                            var fp = NewPage();
                            double cw = (pw - 2 * M) / cols, ch = (ph - top - bottom) / rows;
                            for (int k = 0; k < n && start + k < slides.Count; k++)
                            {
                                int c = k % cols, rr = k / cols;
                                var cell = new Rect(M + c * cw + 8, top + rr * ch + 8, cw - 16, ch - 16);
                                if (n == 3) cell = new Rect(M, top + rr * ch + 8, (pw - 2 * M) * 0.5, ch - 16);
                                var placed = Place(fp, slides[start + k], cell);
                                var num = new TextBlock { Text = (slides[start + k] + 1).ToString(), FontSize = 10, Foreground = Brushes.Gray };
                                FixedPage.SetLeft(num, placed.Left); FixedPage.SetTop(num, placed.Bottom + 2); fp.Children.Add(num);
                                if (n == 3)
                                {
                                    double lx = M + (pw - 2 * M) * 0.55, lw = (pw - 2 * M) * 0.45;
                                    for (double y = placed.Top + 14; y < placed.Bottom; y += 22)
                                        fp.Children.Add(new Line { X1 = lx, X2 = lx + lw, Y1 = y, Y2 = y, Stroke = Brushes.LightGray, StrokeThickness = 0.8 });
                                }
                            }
                            AddPage(fp);
                        }
                        break;
                    }
                case "outline":
                    {
                        var fp = NewPage(); double y = top; double width = pw - 2 * M;
                        foreach (var i in slides)
                        {
                            var sl = _p.Slides[i];
                            var blocks = new List<TextBlock>();
                            blocks.Add(new TextBlock { Text = (i + 1) + ". " + (string.IsNullOrEmpty(sl.Title) ? "Слайд без заголовка" : sl.Title), FontWeight = FontWeights.Bold, FontSize = 15, TextWrapping = TextWrapping.Wrap, Width = width, Margin = new Thickness(0, 8, 0, 2) });
                            var titleShape = sl.Shapes.FirstOrDefault(s => (s.PlaceholderType == "title" || s.PlaceholderType == "ctrTitle") && s.Text != null && !s.Text.IsEmpty);
                            foreach (var s in sl.Shapes.Where(s => s != titleShape && s.Text != null && !s.Text.IsEmpty))
                                foreach (var para in s.Text.Paras.Where(p => !string.IsNullOrWhiteSpace(p.PlainText)))
                                    blocks.Add(new TextBlock { Text = "•  " + para.PlainText.Replace("\n", " "), FontSize = 12, TextWrapping = TextWrapping.Wrap, Width = width - 24 - para.Level * 18, Margin = new Thickness(24 + para.Level * 18, 1, 0, 1) });
                            foreach (var b in blocks)
                            {
                                b.Foreground = Brushes.Black; b.FontFamily = new FontFamily("Segoe UI");
                                b.Measure(new Size(b.Width, double.PositiveInfinity));
                                double hgt = b.DesiredSize.Height + b.Margin.Top + b.Margin.Bottom;
                                if (y + hgt > ph - bottom && y > top) { AddPage(fp); fp = NewPage(); y = top; }
                                FixedPage.SetLeft(b, M + b.Margin.Left); FixedPage.SetTop(b, y + b.Margin.Top);
                                b.Margin = new Thickness(0);
                                fp.Children.Add(b);
                                y += hgt;
                            }
                        }
                        AddPage(fp);
                        break;
                    }
            }
            if (doc.Pages.Count == 0)
            {
                var fp = NewPage();
                var t = new TextBlock { Text = "Нет слайдов для печати в выбранном диапазоне.", FontSize = 16, Foreground = Brushes.Gray };
                FixedPage.SetLeft(t, 60); FixedPage.SetTop(t, 60); fp.Children.Add(t);
                AddPage(fp);
            }
            return doc;
        }

        void Headers(FixedPage fp, double pw, double ph, int page, double m)
        {
            var left = new TextBlock { Text = _docName, FontSize = 9.5, Foreground = Brushes.Gray, FontFamily = new FontFamily("Segoe UI") };
            FixedPage.SetLeft(left, m); FixedPage.SetTop(left, m - 18); fp.Children.Add(left);
            var date = new TextBlock { Text = DateTime.Now.ToString("d MMMM yyyy", new CultureInfo("ru-RU")), FontSize = 9.5, Foreground = Brushes.Gray, FontFamily = new FontFamily("Segoe UI") };
            date.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            FixedPage.SetLeft(date, pw - m - date.DesiredSize.Width); FixedPage.SetTop(date, m - 18); fp.Children.Add(date);
            var num = new TextBlock { Text = page.ToString(), FontSize = 9.5, Foreground = Brushes.Gray, FontFamily = new FontFamily("Segoe UI") };
            num.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            FixedPage.SetLeft(num, (pw - num.DesiredSize.Width) / 2); FixedPage.SetTop(num, ph - m + 4); fp.Children.Add(num);
        }

        Rect Place(FixedPage fp, int idx, Rect area)
        {
            double sw = Px.D(_p.SlideW), sh = Px.D(_p.SlideH);
            double k = Math.Min(area.Width / sw, area.Height / sh);
            double w = sw * k, h = sh * k;
            var r = new Rect(area.X + (area.Width - w) / 2, area.Y + (area.Height - h) / 2, w, h);
            UIElement visual;
            if (_color == "color")
            {
                var c = _r.RenderSlide(_p.Slides[idx], idx + 1, new SlideRenderOptions());
                visual = new Viewbox { Child = c, Width = w, Height = h, Stretch = Stretch.Fill };
            }
            else
            {
                var bmp = _r.Rasterize(_p.Slides[idx], idx + 1, Math.Min(3000, Math.Max(800, w * 3)));
                BitmapSource conv = new FormatConvertedBitmap(bmp, _color == "bw" ? PixelFormats.BlackWhite : PixelFormats.Gray8, _color == "bw" ? BitmapPalettes.BlackAndWhite : null, 0.5);
                conv.Freeze();
                var im = new Image { Source = conv, Width = w, Height = h, Stretch = Stretch.Fill };
                RenderOptions.SetBitmapScalingMode(im, BitmapScalingMode.HighQuality);
                visual = im;
            }
            FixedPage.SetLeft(visual, r.X); FixedPage.SetTop(visual, r.Y);
            fp.Children.Add(visual);
            if (_frame)
            {
                var fr = new Rectangle { Width = w, Height = h, Stroke = Brushes.DarkGray, StrokeThickness = 0.75 };
                FixedPage.SetLeft(fr, r.X); FixedPage.SetTop(fr, r.Y); fp.Children.Add(fr);
            }
            return r;
        }
    }

    /// <summary>Минимальный генератор PDF из JPEG-изображений страниц (без сторонних библиотек).</summary>
    public static class PdfWriter
    {
        public static byte[] FromJpegs(List<Tuple<byte[], int, int>> pages, double wPt, double hPt, string title)
        {
            var ms = new MemoryStream();
            var offsets = new List<long>();
            void W(string s) { var b = Encoding.ASCII.GetBytes(s); ms.Write(b, 0, b.Length); }
            void Obj(int n) { while (offsets.Count < n) offsets.Add(0); offsets[n - 1] = ms.Position; W(n + " 0 obj\n"); }
            string F(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);
            W("%PDF-1.4\n%âãÏÓ\n");
            int n = pages.Count;
            // 1 — каталог, 2 — дерево страниц, 3 — сведения; далее по 3 объекта на страницу
            Obj(1); W("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
            var kids = string.Join(" ", Enumerable.Range(0, n).Select(i => (4 + i * 3) + " 0 R"));
            Obj(2); W("<< /Type /Pages /Count " + n + " /Kids [" + kids + "] >>\nendobj\n");
            var t = title ?? "";
            var hex = new StringBuilder("FEFF");
            foreach (var ch in t) hex.Append(((int)ch).ToString("X4"));
            Obj(3); W("<< /Producer (SlideNova) /Title <" + hex + "> >>\nendobj\n");
            for (int i = 0; i < n; i++)
            {
                int pg = 4 + i * 3, content = pg + 1, img = pg + 2;
                Obj(pg); W("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + F(wPt) + " " + F(hPt) + "] /Resources << /XObject << /Im0 " + img + " 0 R >> >> /Contents " + content + " 0 R >>\nendobj\n");
                var cs = "q " + F(wPt) + " 0 0 " + F(hPt) + " 0 0 cm /Im0 Do Q";
                Obj(content); W("<< /Length " + cs.Length + " >>\nstream\n" + cs + "\nendstream\nendobj\n");
                var jpg = pages[i].Item1;
                Obj(img); W("<< /Type /XObject /Subtype /Image /Width " + pages[i].Item2 + " /Height " + pages[i].Item3 + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpg.Length + " >>\nstream\n");
                ms.Write(jpg, 0, jpg.Length);
                W("\nendstream\nendobj\n");
            }
            long xref = ms.Position;
            W("xref\n0 " + (offsets.Count + 1) + "\n0000000000 65535 f \n");
            foreach (var o in offsets) W(o.ToString("D10") + " 00000 n \n");
            W("trailer\n<< /Size " + (offsets.Count + 1) + " /Root 1 0 R /Info 3 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
            return ms.ToArray();
        }
    }
}
