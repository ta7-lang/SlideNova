// Настройки: оформление (темы и конструктор), безопасность, интеграция с Проводником, конфиденциальность.
using System;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SlideNova.Core;

namespace SlideNova
{
    public sealed class SettingsWindow : ThemedWindow
    {
        readonly AppSettings S = AppSettings.Current;
        readonly ContentControl _host = new ContentControl();
        readonly System.Collections.Generic.List<FancyButton> _tabs = new System.Collections.Generic.List<FancyButton>();

        public SettingsWindow()
        {
            Title = "Настройки SlideNova"; Width = 860; Height = 680; ResizeMode = ResizeMode.CanResize;
            var dock = new DockPanel { Margin = new Thickness(14) };
            var nav = new StackPanel { Width = 200, Margin = new Thickness(0, 0, 12, 0) };
            void Tab(string label, string glyph, Func<UIElement> build)
            {
                var b = new FancyButton { Content = Ui.Row(Ui.Icon(glyph, 15), Ui.Spacer(10), new TextBlock { Text = label, FontSize = 13.5 }), HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(12, 9, 12, 9), Margin = new Thickness(0, 2, 0, 2), Flat = true };
                b.Click += (s, e) => { foreach (var t in _tabs) t.IsToggled = t == b; _host.Content = new ScrollViewer { Content = build(), VerticalScrollBarVisibility = ScrollBarVisibility.Auto }; };
                _tabs.Add(b); nav.Children.Add(b);
            }
            Tab("Оформление", "", Appearance);
            Tab("Безопасность", "", SecurityPage);
            Tab("Проводник Windows", "", Explorer);
            Tab("Конфиденциальность", "", Privacy);
            Tab("О программе", "", About);
            DockPanel.SetDock(nav, Dock.Left); dock.Children.Add(Ui.Card(nav, 8)); DockPanel.SetDock(dock.Children[0], Dock.Left);
            var close = Ui.Action("Готово", Close, true); close.HorizontalAlignment = HorizontalAlignment.Right;
            DockPanel.SetDock(close, Dock.Bottom); dock.Children.Add(close);
            dock.Children.Add(Ui.Card(_host, 16));
            Content = dock;
            _tabs[0].IsToggled = true;
            _host.Content = new ScrollViewer { Content = Appearance(), VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            Closed += (s, e) => S.Save();
        }

        static TextBlock Note(string t) { var x = Ui.Text(t, 12, false, "B.SubText", true); x.Margin = new Thickness(0, 2, 0, 8); return x; }

        UIElement Appearance()
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Header("Тема оформления"));
            sp.Children.Add(Note("Темы меняются мгновенно. Градиенты фона и акцентов, скругления и цвет заголовка окна подстраиваются автоматически."));
            var wrap = new WrapPanel();
            foreach (var t in ThemeManager.All())
            {
                var th = t;
                var card = new Border { Width = 168, Height = 96, CornerRadius = new CornerRadius(t.Radius), Background = new LinearGradientBrush(t.Bg1, t.Bg2, 45), BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromArgb(80, 128, 128, 128)) };
                var inner = new StackPanel { Margin = new Thickness(10) };
                inner.Children.Add(new TextBlock { Text = t.Name, Foreground = new SolidColorBrush(t.Text), FontWeight = FontWeights.SemiBold, FontSize = 13 });
                inner.Children.Add(new Border { Height = 8, CornerRadius = new CornerRadius(4), Margin = new Thickness(0, 8, 30, 0), Background = new LinearGradientBrush(t.Accent1, t.Accent2, 0) });
                inner.Children.Add(new Border { Height = 18, CornerRadius = new CornerRadius(t.Radius / 2), Margin = new Thickness(0, 8, 60, 0), Background = new SolidColorBrush(t.Panel2) });
                card.Child = inner;
                var b = new FancyButton { Content = card, Padding = new Thickness(3), Margin = new Thickness(4), Flat = true, IsToggled = ThemeManager.Current.Name == t.Name };
                b.Click += (s, e) => { S.ThemeName = th.Description == "Пользовательская тема" ? "@custom" : th.Name; S.Save(); ThemeManager.Apply(th); _host.Content = new ScrollViewer { Content = Appearance() }; };
                Ui.Tip(b, t.Name, t.Description);
                wrap.Children.Add(b);
            }
            sp.Children.Add(wrap);
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Header("Конструктор собственной темы"));
            sp.Children.Add(Note("Настройте каждый цвет — изменения видны сразу. Тема сохраняется под названием «" + S.Custom.Name + "»."));
            var c = S.Custom;
            void ColorRow(string label, Func<string> get, Action<string> set, string tip)
            {
                Rgba.TryParseHex(get(), out var cur);
                var sw = Ui.Swatch(Px.C(cur), 22, false);
                var btn = new FancyButton { Content = Ui.Row(sw, Ui.Spacer(8), new TextBlock { Text = "#" + cur.Hex }), Padding = new Thickness(6, 3, 10, 3) };
                btn.Click += (s, e) =>
                {
                    var r = ColorPicker.Show(cur, null, label);
                    if (!r.HasValue) return;
                    set("#" + r.Value.Hex); S.ThemeName = "@custom"; S.Save();
                    ThemeManager.Apply(AppTheme.FromCustom(S.Custom));
                    _host.Content = new ScrollViewer { Content = Appearance() };
                };
                var row = new DockPanel { Margin = new Thickness(0, 3, 0, 3) };
                var l = Ui.Text(label, 12.5); l.Width = 220; DockPanel.SetDock(l, Dock.Left);
                row.Children.Add(l); row.Children.Add(btn); btn.HorizontalAlignment = HorizontalAlignment.Left;
                Ui.Tip(row, label, tip);
                sp.Children.Add(row);
            }
            ColorRow("Фон окна — начало градиента", () => c.Bg1, v => c.Bg1 = v, "Цвет левого верхнего угла фона.");
            ColorRow("Фон окна — конец градиента", () => c.Bg2, v => c.Bg2 = v, "Цвет правого нижнего угла фона.");
            ColorRow("Панели", () => c.Panel, v => c.Panel = v, "Фон ленты, боковых панелей и диалогов.");
            ColorRow("Кнопки и поля", () => c.Panel2, v => c.Panel2 = v, "Фон кнопок в обычном состоянии.");
            ColorRow("Текст интерфейса", () => c.Text, v => c.Text = v, "Цвет надписей.");
            ColorRow("Акцент 1", () => c.Accent1, v => c.Accent1 = v, "Начало акцентного градиента: выделение, активные кнопки.");
            ColorRow("Акцент 2", () => c.Accent2, v => c.Accent2 = v, "Конец акцентного градиента.");
            ColorRow("Фон рабочей области", () => c.Canvas, v => c.Canvas = v, "Подложка вокруг слайда.");
            sp.Children.Add(Ui.Check("Тёмная тема (тёмный заголовок окна)", c.Dark, v => { c.Dark = v; S.ThemeName = "@custom"; S.Save(); ThemeManager.Apply(AppTheme.FromCustom(S.Custom)); }));
            var nameBox = Ui.Input(c.Name, 220);
            nameBox.LostKeyboardFocus += (s, e) => { c.Name = string.IsNullOrWhiteSpace(nameBox.Text) ? "Моя тема" : nameBox.Text.Trim(); S.Save(); };
            sp.Children.Add(Ui.Row(Ui.Text("Название темы", 12.5), Ui.Spacer(12), nameBox));
            sp.Children.Add(Ui.Row(Ui.Text("Скругление углов", 12.5), Ui.Spacer(12), Ui.Slider(0, 22, c.Radius, v => { c.Radius = v; if (S.ThemeName == "@custom") ThemeManager.Apply(AppTheme.FromCustom(S.Custom)); }, 220)));
            sp.Children.Add(Ui.Row(Ui.Action("Взять за основу текущую тему", () =>
            {
                var t = ThemeManager.Current;
                string H(Color x) => "#" + x.R.ToString("X2") + x.G.ToString("X2") + x.B.ToString("X2");
                c.Bg1 = H(t.Bg1); c.Bg2 = H(t.Bg2); c.Panel = H(t.Panel); c.Panel2 = H(t.Panel2); c.Text = H(t.Text); c.Accent1 = H(t.Accent1); c.Accent2 = H(t.Accent2); c.Canvas = H(t.Canvas); c.Radius = t.Radius; c.Dark = t.Dark;
                S.ThemeName = "@custom"; S.Save(); ThemeManager.Apply(AppTheme.FromCustom(S.Custom)); _host.Content = new ScrollViewer { Content = Appearance() };
            }, false, "")));
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Header("Интерфейс"));
            sp.Children.Add(Ui.Check("Полупрозрачные «стеклянные» панели", S.GlassPanels, v => { S.GlassPanels = v; ThemeManager.Apply(ThemeManager.Current); }, "Стекло", "Панели слегка пропускают градиент фона."));
            sp.Children.Add(Ui.Row(Ui.Text("Масштаб интерфейса (после перезапуска)", 12.5), Ui.Spacer(12), Ui.Slider(0.8, 1.6, S.UiScale, v => S.UiScale = Math.Round(v, 2), 200)));
            var user = Ui.Input(S.UserName, 220);
            user.LostKeyboardFocus += (s, e) => S.UserName = user.Text;
            sp.Children.Add(Ui.Row(Ui.Text("Имя автора изменений", 12.5), Ui.Spacer(12), user));
            return sp;
        }

        UIElement SecurityPage()
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Header("Защита"));
            sp.Children.Add(Ui.Check("Строгий режим: запрет запуска других программ", S.StrictMode, v => S.StrictMode = v, "Строгий режим", "Процесс SlideNova не сможет запускать другие программы (даже при уязвимости). Ссылки копируются в буфер обмена вместо открытия браузера. Вступает в силу после перезапуска."));
            sp.Children.Add(Note("Сейчас: " + (Hardening.ChildProcessesBlocked ? "включён" : "выключен") + ". Изменение применяется после перезапуска программы."));
            sp.Children.Add(Ui.Check("Защищённый просмотр файлов из Интернета", S.ProtectedView, v => S.ProtectedView = v, "Защищённый просмотр", "Файлы с меткой «загружено из Интернета» открываются только для чтения, пока вы явно не разрешите редактирование."));
            sp.Children.Add(Ui.Check("Подтверждать переход по ссылкам", S.ConfirmLinks, v => S.ConfirmLinks = v, "Подтверждение ссылок", "Перед открытием адреса показывается, куда ведёт ссылка. Ссылки на файлы и программы блокируются всегда."));
            var mb = Ui.Number(S.MaxFileMb, 64, v => { S.MaxFileMb = (int)Units.Clamp(v, 16, 4096); Limits.MaxFileBytes = S.MaxFileMb * 1024L * 1024L; }, "0", 80);
            sp.Children.Add(Ui.Row(Ui.Text("Максимальный размер открываемого файла, МБ", 12.5), Ui.Spacer(12), mb));
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Header("Что делает SlideNova для вашей безопасности"));
            foreach (var t in new[]
            {
                "Макросы VBA, элементы ActiveX и OLE-объекты никогда не выполняются; при сохранении макросы и ActiveX удаляются.",
                "Программа не обращается к сети: внешние изображения, связанные файлы и ресурсы не загружаются.",
                "Тип файла определяется по его содержимому, а не по расширению — переименованный исполняемый файл не будет открыт.",
                "Защита от zip-бомб, «пиксельных бомб», атак через XML (XXE, «миллиард смехов») и подмены путей в архиве.",
                "Гиперссылки разрешены только по схемам http, https и mailto; ссылки на файлы, программы и сценарии блокируются.",
                "При вставке в текст из буфера обмена принимается только простой текст.",
                "Обработчик эскизов Проводника работает в изолированном процессе Windows, с лимитами и без доступа к сети.",
                "Средства Windows: безопасный поиск DLL, запрет загрузки модулей из сети и с низким уровнем целостности, отключение устаревших точек внедрения.",
                "Сохранение — атомарное: сначала во временный файл рядом, затем замена; при сбое исходный файл не повреждается, временный удаляется.",
            }) sp.Children.Add(Ui.Row(Ui.Text("✓", 13, true, "B.AccentSolid"), Ui.Spacer(8), Ui.Text(t, 12.5, false, "B.Text", true)));
            foreach (UIElement e in sp.Children) if (e is StackPanel r && r.Orientation == Orientation.Horizontal && r.Children.Count == 3 && r.Children[2] is TextBlock tb && tb.TextWrapping == TextWrapping.Wrap) { tb.MaxWidth = 520; r.Margin = new Thickness(0, 3, 0, 3); }
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Text("Активные меры защиты процесса:", 12.5, true));
            foreach (var a in Hardening.Applied) sp.Children.Add(Ui.Text("• " + a, 12, false, "B.SubText", true));
            return sp;
        }

        UIElement Explorer()
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Header("Эскизы презентаций в Проводнике"));
            sp.Children.Add(Note("SlideNova показывает в Проводнике миниатюры первого слайда для файлов " + string.Join(", ", ShellIntegration.Extensions) + ". Регистрация выполняется только для текущего пользователя и не требует прав администратора. Эскизы создаются в изолированном процессе Windows; собственного кэша SlideNova не ведёт."));
            var status = Ui.Text("", 12.5, true);
            Action upd = () => status.Text = "Эскизы: " + (ShellIntegration.IsThumbnailRegistered() ? "подключены ✓" : "не подключены") + "    ·    «Открыть с помощью»: " + (ShellIntegration.IsOpenWithRegistered() ? "подключено ✓" : "не подключено") + (ShellIntegration.ThumbDllPresent ? "" : "\nВнимание: файл SlideNova.Thumbnails.dll не найден рядом с программой.");
            upd();
            sp.Children.Add(status);
            var log = Ui.Text("", 12, false, "B.SubText", true);
            var btns = new WrapPanel { Margin = new Thickness(0, 10, 0, 6) };
            btns.Children.Add(Ui.Action("Подключить эскизы и «Открыть с помощью»", () => { try { log.Text = ShellIntegration.Register(true, true); } catch (Exception ex) { log.Text = "Ошибка: " + ex.Message; } upd(); }, true, ""));
            btns.Children.Add(Ui.Action("Отключить всё", () => { log.Text = ShellIntegration.Unregister(); upd(); }, false, ""));
            sp.Children.Add(btns);
            sp.Children.Add(log);
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Header("Программа по умолчанию"));
            sp.Children.Add(Note("Windows 10/11 позволяет выбрать программу по умолчанию только самому пользователю. После подключения: щёлкните правой кнопкой по файлу .pptx → «Открыть с помощью» → «Выбрать другое приложение» → SlideNova → «Всегда использовать это приложение». Эскизы при этом остаются чистыми: показывается именно первый слайд, без значков поверх."));
            sp.Children.Add(Ui.Separator());
            sp.Children.Add(Ui.Header("Системный кэш эскизов"));
            sp.Children.Add(Note("Сам SlideNova кэш не создаёт. Проводник Windows хранит собственный кэш миниатюр всех файлов; его можно очистить здесь, например если эскизы устарели."));
            var cl = Ui.Text("", 12, false, "B.SubText", true);
            sp.Children.Add(Ui.Action("Очистить кэш эскизов Проводника", () => cl.Text = ShellIntegration.ClearExplorerThumbCache(), false, ""));
            sp.Children.Add(cl);
            return sp;
        }

        UIElement Privacy()
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Header("Конфиденциальность и следы работы"));
            sp.Children.Add(Note("SlideNova не создаёт кэш, временные копии документов и журналы. Хранится только небольшой файл настроек (%AppData%\\SlideNova\\settings.json, несколько килобайт)."));
            sp.Children.Add(Ui.Check("Запоминать недавние файлы (не более 10)", S.KeepRecent, v => { S.KeepRecent = v; if (!v) { S.Recent.Clear(); } S.Save(); }, "Недавние файлы", "Только пути к файлам; содержимое не сохраняется."));
            sp.Children.Add(Ui.Check("Сохранять эскиз первого слайда внутри файла", S.SaveThumbnail, v => S.SaveThumbnail = v, "Эскиз в файле", "Небольшое изображение внутри .pptx — так Проводник и другие программы быстрее показывают миниатюру. Хранится в самом документе, не в системе."));
            var info = Ui.Text("", 12, false, "B.SubText", true);
            var w = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
            w.Children.Add(Ui.Action("Очистить список недавних", () => { S.Recent.Clear(); S.Save(); info.Text = "Список недавних файлов очищен."; }, false, ""));
            w.Children.Add(Ui.Action("Удалить все данные SlideNova", () =>
            {
                if (Dialogs.Ask("Удалить все данные?", "Будут удалены настройки, пользовательская тема и список недавних файлов. Сами презентации не затрагиваются.", "Удалить", "Отмена") == true)
                { AppSettings.WipeAll(); info.Text = "Данные удалены. Настройки по умолчанию применятся после перезапуска."; }
            }, false, ""));
            sp.Children.Add(w);
            sp.Children.Add(info);
            return sp;
        }

        UIElement About()
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Row(Ui.Logo(56), Ui.Spacer(14), Ui.Column(Ui.Text("SlideNova", 26, true), Ui.Text("Версия " + (Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0"), 12.5, false, "B.SubText"))));
            sp.Children.Add(Note("\nОфлайн-средство просмотра и редактирования презентаций для Windows 10/11 (x64)."));
            foreach (var t in new[]
            {
                "Форматы: PPTX, PPSX, POTX, PPTM/PPSM/POTM (макросы блокируются), PPT, PPS, POT (PowerPoint 97–2003). Сохранение: PPTX, PPSX, POTX; экспорт PDF и PNG.",
                "Сохранение без потерь: неизменённые объекты (диаграммы, SmartArt, анимации, переходы, видео) записываются в исходном виде.",
                "Горячие клавиши: Ctrl+N/O/S/P, Ctrl+Z/Y, Ctrl+C/X/V/D, Ctrl+G, Ctrl+M — новый слайд, F5 — показ, Alt+Enter — свойства.",
            }) sp.Children.Add(Ui.Text("• " + t, 12.5, false, "B.Text", true));
            return sp;
        }
    }
}
