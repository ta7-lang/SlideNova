// Интеграция с Проводником Windows (только для текущего пользователя, без прав администратора).
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace SlideNova
{
    public static class ShellIntegration
    {
        public const string Clsid = "{6B3E1C2A-4F7D-4E21-9C5B-8A1D2E3F4A5B}";
        const string ThumbIface = "{e357fccd-a995-4576-b01f-234630154e96}";
        const string ProgId = "SlideNova.Presentation";
        public static readonly string[] Extensions = { ".pptx", ".ppt", ".pptm", ".ppsx", ".pps", ".ppsm", ".potx", ".pot", ".potm" };

        [DllImport("shell32.dll")] static extern void SHChangeNotify(int eventId, uint flags, IntPtr i1, IntPtr i2);

        public static string ExePath => Environment.ProcessPath ?? Path.Combine(Program.AppDir, "SlideNova.exe");
        public static string ThumbDll => Path.Combine(Program.AppDir, "SlideNova.Thumbnails.dll");
        public static bool ThumbDllPresent => File.Exists(ThumbDll);

        public static bool IsThumbnailRegistered()
        {
            try
            {
                using var k = Registry.CurrentUser.OpenSubKey(@"Software\Classes\CLSID\" + Clsid + @"\InprocServer32");
                var cb = k?.GetValue("CodeBase") as string;
                return cb != null && File.Exists(new Uri(cb).LocalPath);
            }
            catch { return false; }
        }

        public static bool IsOpenWithRegistered()
        {
            try { using var k = Registry.CurrentUser.OpenSubKey(@"Software\Classes\" + ProgId + @"\shell\open\command"); return k != null; }
            catch { return false; }
        }

        public static string Register(bool thumbnails, bool openWith)
        {
            var log = new List<string>();
            var exe = ExePath;
            if (openWith)
            {
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\" + ProgId))
                {
                    k.SetValue("", "Презентация (SlideNova)");
                    k.SetValue("FriendlyTypeName", "Презентация (SlideNova)");
                    using (var i = k.CreateSubKey("DefaultIcon")) i.SetValue("", "\"" + exe + "\",0");
                    using (var c = k.CreateSubKey(@"shell\open\command")) c.SetValue("", "\"" + exe + "\" \"%1\"");
                    using (var sh = k.CreateSubKey(@"shell\open")) sh.SetValue("FriendlyAppName", "SlideNova");
                }
                using (var app = Registry.CurrentUser.CreateSubKey(@"Software\Classes\Applications\SlideNova.exe"))
                {
                    app.SetValue("FriendlyAppName", "SlideNova");
                    using (var c = app.CreateSubKey(@"shell\open\command")) c.SetValue("", "\"" + exe + "\" \"%1\"");
                    using (var st = app.CreateSubKey("SupportedTypes")) foreach (var e in Extensions) st.SetValue(e, "");
                }
                foreach (var ext in Extensions)
                    using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\" + ext + @"\OpenWithProgids"))
                        k.SetValue(ProgId, new byte[0], RegistryValueKind.None);
                log.Add("Команда «Открыть с помощью → SlideNova» зарегистрирована.");
            }
            if (thumbnails)
            {
                if (!ThumbDllPresent) log.Add("Файл SlideNova.Thumbnails.dll не найден рядом с программой — эскизы не подключены.");
                else
                {
                    var asmName = AssemblyName.GetAssemblyName(ThumbDll).FullName;
                    var codeBase = new Uri(ThumbDll).AbsoluteUri;
                    using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\CLSID\" + Clsid))
                    {
                        k.SetValue("", "SlideNova Thumbnail Provider");
                        k.SetValue("DisableProcessIsolation", 0, RegistryValueKind.DWord);
                        using (var s = k.CreateSubKey("InprocServer32"))
                        {
                            s.SetValue("", "mscoree.dll");
                            s.SetValue("ThreadingModel", "Both");
                            s.SetValue("Class", "SlideNova.Thumbnails.ThumbnailProvider");
                            s.SetValue("Assembly", asmName);
                            s.SetValue("RuntimeVersion", "v4.0.30319");
                            s.SetValue("CodeBase", codeBase);
                            using (var v = s.CreateSubKey("1.0.0.0"))
                            {
                                v.SetValue("Class", "SlideNova.Thumbnails.ThumbnailProvider");
                                v.SetValue("Assembly", asmName);
                                v.SetValue("RuntimeVersion", "v4.0.30319");
                                v.SetValue("CodeBase", codeBase);
                            }
                        }
                        using (var c = k.CreateSubKey(@"Implemented Categories\{62C8FE65-4EBB-45e7-B440-6E39B2CDBF29}")) { }
                    }
                    foreach (var ext in Extensions)
                    {
                        using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\" + ext + @"\ShellEx\" + ThumbIface)) k.SetValue("", Clsid);
                        using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\SystemFileAssociations\" + ext + @"\ShellEx\" + ThumbIface)) k.SetValue("", Clsid);
                    }
                    using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\" + ProgId + @"\ShellEx\" + ThumbIface)) k.SetValue("", Clsid);
                    log.Add("Обработчик эскизов зарегистрирован для: " + string.Join(", ", Extensions) + ".");
                }
            }
            SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            return string.Join("\n", log);
        }

        public static string Unregister()
        {
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\CLSID\" + Clsid, false); } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\" + ProgId, false); } catch { }
            try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\Applications\SlideNova.exe", false); } catch { }
            foreach (var ext in Extensions)
            {
                foreach (var path in new[] { @"Software\Classes\" + ext + @"\ShellEx\" + ThumbIface, @"Software\Classes\SystemFileAssociations\" + ext + @"\ShellEx\" + ThumbIface })
                {
                    try
                    {
                        using var k = Registry.CurrentUser.OpenSubKey(path, true);
                        if (k != null && string.Equals(k.GetValue("") as string, Clsid, StringComparison.OrdinalIgnoreCase)) { k.Close(); Registry.CurrentUser.DeleteSubKeyTree(path, false); }
                    }
                    catch { }
                }
                try { using var k = Registry.CurrentUser.OpenSubKey(@"Software\Classes\" + ext + @"\OpenWithProgids", true); k?.DeleteValue(ProgId, false); } catch { }
            }
            SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            return "Все записи SlideNova удалены из реестра текущего пользователя.";
        }

        /// <summary>Очистка системного кэша эскизов Проводника (файлы, не занятые Проводником).</summary>
        public static string ClearExplorerThumbCache()
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Windows\Explorer");
            int ok = 0, busy = 0; long freed = 0;
            try
            {
                foreach (var f in Directory.GetFiles(dir, "thumbcache_*.db").Concat(Directory.GetFiles(dir, "iconcache_*.db")))
                {
                    try { var len = new FileInfo(f).Length; File.Delete(f); ok++; freed += len; } catch { busy++; }
                }
            }
            catch (Exception ex) { return "Не удалось получить доступ к кэшу: " + ex.Message; }
            SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            var msg = "Удалено файлов кэша: " + ok + " (" + (freed / 1048576.0).ToString("0.#") + " МБ).";
            if (busy > 0) msg += "\nЗанято Проводником: " + busy + ". Они будут очищены после перезапуска Проводника или выхода из системы. Также можно использовать «Очистку диска» → «Эскизы».";
            return msg;
        }
    }
}
