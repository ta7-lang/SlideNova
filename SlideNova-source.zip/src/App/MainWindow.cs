// Главное окно SlideNova.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using SlideNova.Core;

namespace SlideNova
{
    public sealed partial class MainWindow : Window
    {
        readonly AppSettings S = AppSettings.Current;
        PresentationModel _pres;
        string _path;
        bool _dirty;
        bool _protected;
        string _protectedReason;
        ImageCache _img;
        readonly SlideEditor _ed = new SlideEditor();
        readonly StackPanel _thumbs = new StackPanel();
        readonly ScrollViewer _thumbScroll;
        TextBox _notes;
        readonly ContentControl _ribbonHost = new ContentControl();
        readonly Dictionary<string, Func<UIElement>> _tabBuilders = new Dictionary<string, Func<UIElement>>();
        readonly Dictionary<string, FancyButton> _tabButtons = new Dictionary<string, FancyButton>();
        string _tab = "home";
        readonly TextBlock _stSlide = new TextBlock(), _stSel = new TextBlock(), _stHint = new TextBlock(), _stZoom = new TextBlock(), _stSec = new TextBlock();
        Slider _zoomSlider;
        readonly Border _banner = new Border();
        readonly StackPanel _inspector = new StackPanel();
        Grid _mainGrid; Grid _startPage; Grid _centerGrid;
        ColumnDefinition _colThumbs, _colInspector; RowDefinition _rowNotes;
        readonly DispatcherTimer _thumbTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        bool _suppressNotes;

        public MainWindow()
        {
            Title = "SlideNova";
            Width = 1440; Height = 900; MinWidth = 960; MinHeight = 600;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            FontFamily = Ui.UiFont; FontSize = 13;
            SetResourceReference(BackgroundProperty, "B.WindowBg");
            SetResourceReference(ForegroundProperty, "B.Text");
            UseLayoutRounding = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
            try { Icon = BitmapFrame.Create(new Uri(Path.Combine(Program.AppDir, "SlideNova.ico"), UriKind.Absolute)); } catch { }
            SourceInitialized += (s, e) => ThemeManager.ApplyTitleBar(this);
            AllowDrop = true;
            Drop += OnDrop;
            DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent("SlideNovaSlide") ? DragDropEffects.Move : e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
            Closing += OnClosing;
            PreviewKeyDown += OnKey;
            Ui.Hint += h => _stHint.Text = h ?? "";
            ThemeManager.Changed += () => { RebuildRibbon(); _ed.DrawSelection(); };

            _thumbScroll = new ScrollViewer { Content = _thumbs, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(6) };
            _thumbTimer.Tick += (s, e) => { _thumbTimer.Stop(); RefreshThumb(_ed.SlideIndex); };

            _ed.SelectionChanged += OnSelectionChanged;
            _ed.Changed += label => { MarkDirty(); _thumbTimer.Stop(); _thumbTimer.Start(); UpdateStatus(); };
            _ed.ZoomChanged += () => { _stZoom.Text = Math.Round(_ed.Zoom * 100) + "%"; if (_zoomSlider != null && Math.Abs(_zoomSlider.Value - _ed.Zoom * 100) > 1) _zoomSlider.Value = _ed.Zoom * 100; };
            _ed.ToolFinished += () => RebuildRibbon();
            _ed.TableEditRequested += EditTable;
            _ed.ShowGrid = S.ShowGrid; _ed.Snap = S.Snap;

            Content = BuildLayout();
            if (S.UiScale != 1.0) ((FrameworkElement)Content).LayoutTransform = new ScaleTransform(S.UiScale, S.UiScale);
            ShowStart();
        }

        // ================== Разметка окна ==================
        UIElement BuildLayout()
        {
            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Заголовок с вкладками
            var header = new Border { Padding = new Thickness(10, 6, 10, 6) };
            header.SetResourceReference(Border.BackgroundProperty, "B.Header");
            var hd = new DockPanel { LastChildFill = false };
            var logo = Ui.Row(Ui.Logo(28), Ui.Spacer(8));
            var name = Ui.Text("SlideNova", 16, true); logo.Children.Add(name);
            logo.Margin = new Thickness(0, 0, 18, 0);
            DockPanel.SetDock(logo, Dock.Left); hd.Children.Add(logo);
            var tabs = new StackPanel { Orientation = Orientation.Horizontal };
            void Tab(string id, string label, Func<UIElement> builder)
            {
                _tabBuilders[id] = builder;
                var b = new FancyButton { Content = label, Padding = new Thickness(14, 5, 14, 5), Margin = new Thickness(2, 0, 2, 0), Flat = true, Focusable = false };
                b.Click += (s, e) => { _tab = id; RebuildRibbon(); };
                _tabButtons[id] = b;
                tabs.Children.Add(b);
            }
            Tab("home", "Главная", BuildHome);
            Tab("insert", "Вставка", BuildInsert);
            Tab("format", "Формат", BuildFormat);
            Tab("text", "Текст", BuildTextTab);
            Tab("slide", "Слайд", BuildSlideTab);
            Tab("view", "Вид", BuildView);
            Tab("show", "Показ", BuildShow);
            DockPanel.SetDock(tabs, Dock.Left); hd.Children.Add(tabs);
            var quick = Ui.Row(
                Ui.Small("", null, "Открыть", "Открыть презентацию PPTX, PPT, PPSX, POTX и др. Тип файла определяется по содержимому, а не по расширению.", OpenDialog, "Ctrl+O"),
                Ui.Small("", null, "Сохранить", "Сохранить изменения. Файлы PPT сохраняются в современном формате PPTX.", () => Save(false), "Ctrl+S"),
                Ui.Small("", null, "Отменить", "Отменить последнее действие.", DoUndo, "Ctrl+Z"),
                Ui.Small("", null, "Вернуть", "Повторить отменённое действие.", DoRedo, "Ctrl+Y"),
                Ui.Small("", null, "Печать", "Печать слайдов, выдач, заметок или структуры с предпросмотром.", PrintNow, "Ctrl+P"),
                Ui.Small("", null, "Свойства", "Подробные сведения о файле, документе, содержимом и безопасности.", ShowProperties, "Alt+Enter"),
                Ui.Small("", null, "Настройки", "Темы оформления, безопасность, интеграция с Проводником, конфиденциальность.", ShowSettings));
            DockPanel.SetDock(quick, Dock.Right); hd.Children.Add(quick);
            header.Child = hd;
            Grid.SetRow(header, 0); root.Children.Add(header);

            // Лента
            var ribbon = new Border { Margin = new Thickness(8, 6, 8, 0), Padding = new Thickness(6, 6, 6, 4), BorderThickness = new Thickness(1), MinHeight = 92, Child = new ScrollViewer { Content = _ribbonHost, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled } };
            ribbon.SetResourceReference(Border.BackgroundProperty, "B.Panel");
            ribbon.SetResourceReference(Border.BorderBrushProperty, "B.Border");
            ribbon.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            Grid.SetRow(ribbon, 1); root.Children.Add(ribbon);

            // Баннер (защищённый просмотр / предупреждения)
            _banner.Visibility = Visibility.Collapsed; _banner.Margin = new Thickness(8, 6, 8, 0); _banner.Padding = new Thickness(12, 8, 12, 8);
            _banner.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            Grid.SetRow(_banner, 2); root.Children.Add(_banner);

            // Основная область
            _mainGrid = new Grid { Margin = new Thickness(8) };
            _colThumbs = new ColumnDefinition { Width = new GridLength(S.ShowThumbs ? 212 : 0) };
            _colInspector = new ColumnDefinition { Width = new GridLength(S.ShowInspector ? 270 : 0) };
            _mainGrid.ColumnDefinitions.Add(_colThumbs);
            _mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(6) });
            _mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(6) });
            _mainGrid.ColumnDefinitions.Add(_colInspector);

            var thumbPanel = PanelBox("Слайды", _thumbScroll, Ui.Small("", null, "Новый слайд", "Добавить слайд после текущего с выбором макета.", () => NewSlideMenu(null), "Ctrl+M"));
            Grid.SetColumn(thumbPanel, 0); _mainGrid.Children.Add(thumbPanel);
            var sp1 = new GridSplitter { Width = 6, HorizontalAlignment = HorizontalAlignment.Stretch, Background = Brushes.Transparent }; Grid.SetColumn(sp1, 1); _mainGrid.Children.Add(sp1);

            _centerGrid = new Grid();
            _centerGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            _centerGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(6) });
            _rowNotes = new RowDefinition { Height = new GridLength(S.ShowNotes ? 110 : 0) };
            _centerGrid.RowDefinitions.Add(_rowNotes);
            var edBorder = new Border { Child = _ed, ClipToBounds = true };
            edBorder.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            _centerGrid.Children.Add(edBorder);
            var sp3 = new GridSplitter { Height = 6, HorizontalAlignment = HorizontalAlignment.Stretch, Background = Brushes.Transparent, ResizeDirection = GridResizeDirection.Rows }; Grid.SetRow(sp3, 1); _centerGrid.Children.Add(sp3);
            _notes = Ui.Input(""); _notes.AcceptsReturn = true; _notes.TextWrapping = TextWrapping.Wrap; _notes.VerticalScrollBarVisibility = ScrollBarVisibility.Auto; _notes.VerticalContentAlignment = VerticalAlignment.Top;
            _notes.TextChanged += (s, e) =>
            {
                if (_suppressNotes || _ed.Slide == null || _ed.ReadOnly) return;
                _ed.Slide.Notes = _notes.Text; _ed.Slide.NotesDirty = true; MarkDirty();
            };
            var notesBox = PanelBox("Заметки докладчика", _notes, null);
            Grid.SetRow(notesBox, 2); _centerGrid.Children.Add(notesBox);
            _startPage = new Grid(); _centerGrid.Children.Add(_startPage); Grid.SetRowSpan(_startPage, 3);
            Grid.SetColumn(_centerGrid, 2); _mainGrid.Children.Add(_centerGrid);

            var sp2 = new GridSplitter { Width = 6, HorizontalAlignment = HorizontalAlignment.Stretch, Background = Brushes.Transparent }; Grid.SetColumn(sp2, 3); _mainGrid.Children.Add(sp2);
            var insp = PanelBox("Инспектор", new ScrollViewer { Content = _inspector, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(10, 4, 10, 10) }, null);
            Grid.SetColumn(insp, 4); _mainGrid.Children.Add(insp);
            Grid.SetRow(_mainGrid, 3); root.Children.Add(_mainGrid);

            // Строка состояния
            var status = new Border { Padding = new Thickness(12, 4, 12, 5) };
            status.SetResourceReference(Border.BackgroundProperty, "B.Header");
            var sd = new DockPanel();
            foreach (var t in new[] { _stSlide, _stSel, _stHint, _stZoom, _stSec }) { t.SetResourceReference(TextBlock.ForegroundProperty, "B.SubText"); t.VerticalAlignment = VerticalAlignment.Center; t.FontSize = 12; }
            _stSlide.Margin = new Thickness(0, 0, 18, 0); _stSel.Margin = new Thickness(0, 0, 18, 0);
            _stHint.TextTrimming = TextTrimming.CharacterEllipsis;
            var right = new StackPanel { Orientation = Orientation.Horizontal };
            var shield = Ui.Icon("", 13); shield.SetResourceReference(TextBlock.ForegroundProperty, "B.AccentSolid"); shield.Margin = new Thickness(0, 0, 5, 0);
            right.Children.Add(shield); right.Children.Add(_stSec); right.Children.Add(Ui.Spacer(16));
            _zoomSlider = Ui.Slider(10, 400, 100, v => { if (Math.Abs(v - _ed.Zoom * 100) > 0.9) _ed.SetZoom(v / 100); }, 140);
            right.Children.Add(Ui.Small("", null, "Уменьшить", "Уменьшить масштаб.", () => _ed.SetZoom(_ed.Zoom / 1.15), "Ctrl+−"));
            right.Children.Add(_zoomSlider);
            right.Children.Add(Ui.Small("", null, "Увеличить", "Увеличить масштаб.", () => _ed.SetZoom(_ed.Zoom * 1.15), "Ctrl++"));
            _stZoom.Width = 44; _stZoom.TextAlignment = TextAlignment.Right; right.Children.Add(_stZoom);
            right.Children.Add(Ui.Small("", null, "По размеру окна", "Вписать слайд в окно.", () => _ed.Fit(), "Ctrl+0"));
            DockPanel.SetDock(right, Dock.Right); sd.Children.Add(right);
            DockPanel.SetDock(_stSlide, Dock.Left); sd.Children.Add(_stSlide);
            DockPanel.SetDock(_stSel, Dock.Left); sd.Children.Add(_stSel);
            sd.Children.Add(_stHint);
            status.Child = sd;
            Grid.SetRow(status, 4); root.Children.Add(status);

            RebuildRibbon();
            return root;
        }

        Border PanelBox(string title, UIElement content, UIElement action)
        {
            var dock = new DockPanel();
            var head = new DockPanel { Margin = new Thickness(10, 6, 6, 4) };
            if (action != null) { DockPanel.SetDock(action, Dock.Right); head.Children.Add(action); }
            head.Children.Add(Ui.Text(title, 12.5, true, "B.SubText"));
            DockPanel.SetDock(head, Dock.Top); dock.Children.Add(head);
            dock.Children.Add(content);
            var b = new Border { Child = dock, BorderThickness = new Thickness(1) };
            b.SetResourceReference(Border.BackgroundProperty, "B.Panel");
            b.SetResourceReference(Border.BorderBrushProperty, "B.Border");
            b.SetResourceReference(Border.CornerRadiusProperty, "R.Corner");
            return b;
        }

        void RebuildRibbon()
        {
            foreach (var kv in _tabButtons) kv.Value.IsToggled = kv.Key == _tab;
            _ribbonHost.Content = _tabBuilders[_tab]();
        }

        static StackPanel Strip(params UIElement[] groups) { var sp = new StackPanel { Orientation = Orientation.Horizontal }; foreach (var g in groups) if (g != null) sp.Children.Add(g); return sp; }

        // ================== Вкладки ленты ==================
        UIElement BuildHome() => Strip(
            Ui.Group("Файл",
                Ui.Big("", "Создать", "Новая презентация", "Создать пустую презентацию 16:9 с титульным слайдом.", () => NewPresentation(12192000, 6858000), "Ctrl+N"),
                Ui.Big("", "Открыть", "Открыть", "Открыть PPTX, PPT, PPSX, PPS, POTX, POT, PPTM. Макросы и активное содержимое блокируются.", OpenDialog, "Ctrl+O"),
                Ui.Big("", "Сохранить", "Сохранить", "Сохранить изменения в текущий файл (PPT конвертируется в PPTX).", () => Save(false), "Ctrl+S"),
                Ui.Big("", "Сохранить как", "Сохранить как", "Сохранить копию: PPTX, демонстрация PPSX или шаблон POTX.", () => Save(true), "Ctrl+Shift+S"),
                Ui.Big("", "Печать", "Печать", "Печать в любом режиме: слайды, выдачи (2–9 на листе), заметки, структура; цвет, оттенки серого, Ч/Б.", PrintNow, "Ctrl+P"),
                Ui.Big("", "PDF", "Экспорт в PDF", "Сохранить все слайды в PDF-файл (без внешних программ).", ExportPdf),
                Ui.Big("", "PNG", "Экспорт изображений", "Сохранить текущий слайд или все слайды как изображения PNG высокого качества.", ExportPng)),
            Ui.Group("Буфер обмена",
                Ui.Big("", "Вставить", "Вставить", "Вставить объекты, изображение или текст из буфера обмена.", Paste, "Ctrl+V"),
                Ui.Column(
                    Ui.Small("", "Вырезать", "Вырезать", "Удалить выделенные объекты и поместить их в буфер.", Cut, "Ctrl+X"),
                    Ui.Small("", "Копировать", "Копировать", "Скопировать выделенные объекты в буфер.", Copy, "Ctrl+C"),
                    Ui.Small("", "Дублировать", "Дублировать", "Создать копию выделенных объектов со смещением.", Duplicate, "Ctrl+D"))),
            Ui.Group("История",
                Ui.Big("", "Отменить", "Отменить", "Отменить последнее действие" + (_ed.Undo.CanUndo ? ": «" + _ed.Undo.UndoLabel + "»" : "") + ". История хранится только в памяти.", DoUndo, "Ctrl+Z"),
                Ui.Big("", "Вернуть", "Вернуть", "Повторить отменённое действие.", DoRedo, "Ctrl+Y")),
            Ui.Group("Слайды",
                Ui.Big("", "Новый слайд", "Новый слайд", "Добавить слайд после текущего. Откроется список макетов презентации.", () => NewSlideMenu(null), "Ctrl+M"),
                Ui.Column(
                    Ui.Small("", "Дублировать", "Дублировать слайд", "Создать точную копию текущего слайда.", DuplicateSlide),
                    Ui.Small("", "Удалить", "Удалить слайд", "Удалить текущий слайд (можно отменить).", DeleteSlide),
                    Ui.Small("", "Скрыть", "Скрыть / показать слайд", "Скрытые слайды пропускаются при показе, но остаются в файле.", ToggleHidden)),
                Ui.Column(
                    Ui.Small("", "Выше", "Переместить выше", "Переместить слайд на одну позицию вверх.", () => MoveSlide(-1), "Ctrl+↑"),
                    Ui.Small("", "Ниже", "Переместить ниже", "Переместить слайд на одну позицию вниз.", () => MoveSlide(1), "Ctrl+↓"))),
            Ui.Group("Правка",
                Ui.Big("", "Найти", "Найти и заменить", "Поиск текста на всех слайдах, в таблицах и заметках, замена по одному или всё сразу.", () => ShowFind(false), "Ctrl+F"),
                Ui.Big("", "Выделить всё", "Выделить всё", "Выделить все объекты текущего слайда.", () => _ed.SelectAll(), "Ctrl+A")));

        UIElement BuildInsert()
        {
            var shapes = new WrapPanel { MaxWidth = 300 };
            foreach (var id in new[] { "rect", "roundRect", "ellipse", "triangle", "diamond", "star5", "rightArrow", "chevron", "wedgeRectCallout", "line", "arrowLine" })
            {
                var info = PresetGeometry.Gallery.First(g => g.Id == id);
                var b = new FancyButton { Content = ShapeIcon(id, 20), Padding = new Thickness(4), Margin = new Thickness(1), Flat = true, IsToggled = _ed.Tool == id };
                b.Click += (s, e) => StartTool(id);
                Ui.Tip(b, info.Title, info.Hint + " Нажмите, затем протяните мышью на слайде (или щёлкните для стандартного размера).");
                shapes.Children.Add(b);
            }
            FancyButton gallery = null;
            gallery = Ui.Big("", "Все фигуры", "Галерея фигур", "Полный набор из " + PresetGeometry.Gallery.Length + " фигур: стрелки, звёзды, выноски, блок-схемы.", () => ShapeGallery(gallery));
            return Strip(
                Ui.Group("Текст", Ui.Big("", "Надпись", "Надпись", "Нарисуйте область для текста на слайде. Текст можно сразу вводить.", () => StartTool("textbox"))),
                Ui.Group("Фигуры", shapes, gallery),
                Ui.Group("Изображения",
                    Ui.Big("", "Рисунок", "Рисунок из файла", "Вставить изображение (PNG, JPEG, GIF, BMP, TIFF, ICO, EMF, WMF). Файл проверяется перед вставкой.", InsertPicture),
                    Ui.Big("", "Из буфера", "Изображение из буфера", "Вставить картинку, скопированную в другой программе.", PasteImage)),
                Ui.Group("Таблица", Ui.Big("", "Таблица", "Таблица", "Вставить таблицу заданного размера в стиле темы.", InsertTable)),
                Ui.Group("Колонтитулы",
                    Ui.Big("", "Дата", "Дата", "Вставить надпись с текущей датой.", () => InsertTextBox(DateTime.Now.ToString("d MMMM yyyy", new CultureInfo("ru-RU")))),
                    Ui.Big("", "Номер", "Номер слайда", "Вставить надпись с номером текущего слайда.", () => InsertTextBox((_ed.SlideIndex + 1).ToString()))));
        }

        UIElement BuildFormat()
        {
            var styles = new WrapPanel { MaxWidth = 230 };
            var th = _pres?.Theme;
            if (th != null)
                for (int i = 1; i <= 6; i++)
                {
                    var key = "accent" + i;
                    if (!th.Colors.TryGetValue(key, out var ac)) continue;
                    var col = ac;
                    var b = new FancyButton { Padding = new Thickness(3), Margin = new Thickness(1), Flat = true, Content = new Border { Width = 28, Height = 20, CornerRadius = new CornerRadius(4), Background = new LinearGradientBrush(Px.C(col), Px.Shade(Px.C(col), 0.7), 90), BorderBrush = new SolidColorBrush(Px.Shade(Px.C(col), 0.6)), BorderThickness = new Thickness(1), Child = new TextBlock { Text = "Аа", FontSize = 10, Foreground = Brushes.White, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center } } };
                    b.Click += (s, e) => _ed.Modify("Стиль фигуры", sh => { sh.Fill = FillDef.Gradient(col, Px.R(Px.Shade(Px.C(col), 0.72)), 90); sh.Line = new LineDef { Visible = true, Color = Px.R(Px.Shade(Px.C(col), 0.6)), WidthEmu = 12700 }; sh.DirtyFill = sh.DirtyLine = true; SetTextColor(sh, Rgba.White); }, sh => sh.Kind == ShapeKind.Shape);
                    Ui.Tip(b, "Стиль: акцент " + i, "Градиентная заливка цвета темы, тёмный контур и белый текст.");
                    styles.Children.Add(b);
                    var b2 = new FancyButton { Padding = new Thickness(3), Margin = new Thickness(1), Flat = true, Content = new Border { Width = 28, Height = 20, CornerRadius = new CornerRadius(4), Background = Brushes.White, BorderBrush = new SolidColorBrush(Px.C(col)), BorderThickness = new Thickness(2), Child = new TextBlock { Text = "Аа", FontSize = 10, Foreground = new SolidColorBrush(Px.C(col)), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center } } };
                    b2.Click += (s, e) => _ed.Modify("Стиль фигуры", sh => { sh.Fill = FillDef.Solid(Rgba.White); sh.Line = new LineDef { Visible = true, Color = col, WidthEmu = 25400 }; sh.DirtyFill = sh.DirtyLine = true; SetTextColor(sh, col); }, sh => sh.Kind == ShapeKind.Shape);
                    Ui.Tip(b2, "Стиль: контур " + i, "Белая заливка, толстый контур и текст цвета темы.");
                    styles.Children.Add(b2);
                }
            FancyButton fillBtn = null, lineBtn = null, widthBtn = null, dashBtn = null, arrowBtn = null;
            fillBtn = Ui.Big("", "Заливка", "Цвет заливки", "Сплошная заливка выделенных фигур: цвета темы, палитра, HEX и прозрачность.", () => PickFill(fillBtn));
            lineBtn = Ui.Small("", "Цвет контура", "Цвет контура", "Цвет линии или обводки фигуры.", () => PickLineColor(lineBtn));
            widthBtn = Ui.Small("", "Толщина", "Толщина контура", "Толщина линии в пунктах.", () => PickLineWidth(widthBtn));
            dashBtn = Ui.Small("", "Штрих", "Тип штриха", "Сплошная, пунктир, точки, штрихпунктир.", () => PickDash(dashBtn));
            arrowBtn = Ui.Small("", "Стрелки", "Концы линии", "Стрелки, круги и ромбы на концах линии.", () => PickArrows(arrowBtn));
            return Strip(
                Ui.Group("Экспресс-стили", styles),
                Ui.Group("Заливка",
                    fillBtn,
                    Ui.Column(
                        Ui.Small("", "Градиент", "Градиентная заливка", "Линейный или радиальный градиент из нескольких цветов с выбором угла.", PickGradient),
                        Ui.Small("", "Рисунок", "Заливка рисунком", "Заполнить фигуру изображением из файла.", PickImageFill),
                        Ui.Small("", "Нет", "Без заливки", "Сделать фигуру прозрачной.", () => _ed.Modify("Без заливки", s => { s.Fill = FillDef.NoFill(); s.DirtyFill = true; })))),
                Ui.Group("Контур",
                    Ui.Column(lineBtn, widthBtn),
                    Ui.Column(dashBtn, arrowBtn, Ui.Small("", "Нет", "Без контура", "Убрать обводку фигуры.", () => _ed.Modify("Без контура", s => { s.Line = LineDef.None(); s.DirtyLine = true; }, s => s.Kind != ShapeKind.Connector)))),
                Ui.Group("Упорядочить",
                    Ui.Column(
                        Ui.Small("", "На передний план", "На передний план", "Поместить объект поверх всех остальных.", () => Arrange(2), "Ctrl+Shift+]"),
                        Ui.Small("", "На задний план", "На задний план", "Поместить объект под всеми остальными.", () => Arrange(-2), "Ctrl+Shift+[")),
                    Ui.Column(
                        Ui.Small("", "Вперёд", "Переместить вперёд", "Поднять объект на один уровень.", () => Arrange(1), "Ctrl+]"),
                        Ui.Small("", "Назад", "Переместить назад", "Опустить объект на один уровень.", () => Arrange(-1), "Ctrl+["))),
                Ui.Group("Выровнять",
                    Ui.Column(
                        Ui.Row(Ui.Small("", null, "По левому краю", "Выровнять объекты по левому краю (один объект — по слайду).", () => Align("l")),
                               Ui.Small("", null, "По центру", "Выровнять по горизонтальному центру.", () => Align("c")),
                               Ui.Small("", null, "По правому краю", "Выровнять по правому краю.", () => Align("r"))),
                        Ui.Row(Ui.Small("⤒", null, "По верхнему краю", "Выровнять по верхнему краю.", () => Align("t")),
                               Ui.Small("↕", null, "По середине", "Выровнять по вертикальному центру.", () => Align("m")),
                               Ui.Small("⤓", null, "По нижнему краю", "Выровнять по нижнему краю.", () => Align("b")))),
                    Ui.Column(
                        Ui.Small("↔", "Распределить ↔", "Распределить по горизонтали", "Равные промежутки между объектами по горизонтали (от 3 объектов).", () => Distribute(true)),
                        Ui.Small("↕", "Распределить ↕", "Распределить по вертикали", "Равные промежутки между объектами по вертикали.", () => Distribute(false)))),
                Ui.Group("Поворот",
                    Ui.Column(
                        Ui.Small("", "Вправо 90°", "Повернуть вправо", "Повернуть на 90° по часовой стрелке.", () => RotateBy(90)),
                        Ui.Small("", "Влево 90°", "Повернуть влево", "Повернуть на 90° против часовой стрелки.", () => RotateBy(-90))),
                    Ui.Column(
                        Ui.Small("⇄", "Отразить ↔", "Отразить по горизонтали", "Зеркальное отражение слева направо.", () => _ed.Modify("Отражение", s => { s.FlipH = !s.FlipH; s.DirtyXfrm = true; })),
                        Ui.Small("⇅", "Отразить ↕", "Отразить по вертикали", "Зеркальное отражение сверху вниз.", () => _ed.Modify("Отражение", s => { s.FlipV = !s.FlipV; s.DirtyXfrm = true; })))),
                Ui.Group("Группа",
                    Ui.Column(
                        Ui.Small("", "Группировать", "Группировать", "Объединить выделенные объекты в группу — они будут перемещаться вместе.", GroupSel, "Ctrl+G"),
                        Ui.Small("", "Разгруппировать", "Разгруппировать", "Разделить группу на отдельные объекты.", UngroupSel, "Ctrl+Shift+G"))));
        }

        UIElement BuildTextTab()
        {
            FancyButton fontBtn = null, sizeBtn = null, colorBtn = null, spacingBtn = null;
            fontBtn = Ui.Small("", CurrentFontName() ?? "Шрифт", "Шрифт", "Выбор гарнитуры с предпросмотром и поиском по установленным шрифтам.", () => PickFont(fontBtn));
            fontBtn.MinWidth = 150; fontBtn.HorizontalContentAlignment = HorizontalAlignment.Left;
            sizeBtn = Ui.Small("", CurrentFontSize() ?? "Размер", "Размер шрифта", "Размер текста в пунктах (8–96 или своё значение).", () => PickSize(sizeBtn));
            colorBtn = Ui.Small("", "Цвет текста", "Цвет текста", "Цвет символов: цвета темы, палитра, HEX.", () => PickTextColor(colorBtn));
            spacingBtn = Ui.Small("", "Интервал", "Междустрочный интервал", "Расстояние между строками абзаца (1,0–3,0).", () => PickSpacing(spacingBtn));
            return Strip(
                Ui.Group("Шрифт",
                    Ui.Column(fontBtn, Ui.Row(sizeBtn,
                        Ui.Small("", null, "Увеличить шрифт", "Увеличить размер выделенного текста на шаг.", () => GrowFont(1), "Ctrl+]"),
                        Ui.Small("", null, "Уменьшить шрифт", "Уменьшить размер выделенного текста на шаг.", () => GrowFont(-1), "Ctrl+["))),
                    Ui.Column(
                        Ui.Row(
                            Ui.Small("", null, "Полужирный", "Сделать текст полужирным.", () => ToggleStyle("b"), "Ctrl+B"),
                            Ui.Small("", null, "Курсив", "Наклонное начертание.", () => ToggleStyle("i"), "Ctrl+I"),
                            Ui.Small("", null, "Подчёркнутый", "Подчеркнуть текст.", () => ToggleStyle("u"), "Ctrl+U"),
                            Ui.Small("", "S̶", "Зачёркнутый", "Перечеркнуть текст.", () => ToggleStyle("s"))),
                        Ui.Row(colorBtn,
                            Ui.Small(null, "АБВ", "ВСЕ ПРОПИСНЫЕ", "Преобразовать выделенный текст в заглавные буквы.", () => ChangeCase(true)),
                            Ui.Small(null, "абв", "все строчные", "Преобразовать выделенный текст в строчные буквы.", () => ChangeCase(false))))),
                Ui.Group("Абзац",
                    Ui.Column(
                        Ui.Row(
                            Ui.Small("", null, "По левому краю", "Выровнять абзац по левому краю.", () => ParaAlign("l"), "Ctrl+L"),
                            Ui.Small("", null, "По центру", "Выровнять абзац по центру.", () => ParaAlign("ctr"), "Ctrl+E"),
                            Ui.Small("", null, "По правому краю", "Выровнять абзац по правому краю.", () => ParaAlign("r"), "Ctrl+R"),
                            Ui.Small("", null, "По ширине", "Растянуть строки по ширине области.", () => ParaAlign("just"), "Ctrl+J")),
                        Ui.Row(
                            Ui.Small("•", "Маркеры", "Маркированный список", "Включить или выключить маркеры (•) для абзацев.", () => Bullets("•")),
                            Ui.Small("1.", "Нумерация", "Нумерованный список", "Автоматическая нумерация абзацев 1., 2., 3.", () => Bullets("\u0001arabicPeriod")),
                            spacingBtn)),
                    Ui.Column(
                        Ui.Small("", "Уровень +", "Увеличить уровень", "Сделать пункт вложенным (сдвиг вправо).", () => Level(1), "Tab"),
                        Ui.Small("", "Уровень −", "Уменьшить уровень", "Поднять пункт на уровень выше.", () => Level(-1), "Shift+Tab"))),
                Ui.Group("Положение текста",
                    Ui.Column(
                        Ui.Small("⤒", "Сверху", "Привязать к верху", "Текст прижимается к верхнему краю фигуры.", () => Anchor("t")),
                        Ui.Small("↕", "По центру", "По центру по вертикали", "Текст располагается посередине фигуры.", () => Anchor("ctr")),
                        Ui.Small("⤓", "Снизу", "Привязать к низу", "Текст прижимается к нижнему краю фигуры.", () => Anchor("b")))),
                Ui.Group("Правка текста",
                    Ui.Big("", "Изменить", "Редактировать текст", "Начать ввод текста в выделенной фигуре (или двойной щелчок по ней).", () => { if (_ed.Selection.Count == 1) _ed.BeginTextEdit(_ed.Selection[0]); }, "F2 / Enter"),
                    Ui.Big("", "Заменить", "Найти и заменить", "Найти фразу во всей презентации и заменить её.", () => ShowFind(true), "Ctrl+H")));
        }

        UIElement BuildSlideTab()
        {
            FancyButton bgBtn = null;
            bgBtn = Ui.Big("", "Цвет фона", "Цвет фона", "Сплошной фон текущего слайда.", () => PickBackground(bgBtn));
            return Strip(
                Ui.Group("Фон",
                    bgBtn,
                    Ui.Big("", "Градиент", "Градиентный фон", "Плавный переход цветов на фоне слайда.", PickBackgroundGradient),
                    Ui.Big("", "Рисунок", "Фоновый рисунок", "Использовать изображение как фон слайда.", PickBackgroundImage),
                    Ui.Big("", "Ко всем", "Применить ко всем", "Скопировать фон текущего слайда на все слайды.", ApplyBgToAll)),
                Ui.Group("Размер слайда",
                    Ui.Column(
                        Ui.Small(null, "16:9", "Широкоэкранный 16:9", "33,87 × 19,05 см. Содержимое масштабируется.", () => SetSlideSize(12192000, 6858000)),
                        Ui.Small(null, "4:3", "Стандартный 4:3", "25,4 × 19,05 см.", () => SetSlideSize(9144000, 6858000))),
                    Ui.Column(
                        Ui.Small(null, "16:10", "16:10", "25,4 × 15,88 см.", () => SetSlideSize(9144000, 5715000)),
                        Ui.Small(null, "A4", "Лист A4", "27,51 × 19,05 см — для печати.", () => SetSlideSize(9906000, 6858000)))),
                Ui.Group("Слайд",
                    Ui.Big("", "Новый", "Новый слайд", "Добавить слайд с выбором макета.", () => NewSlideMenu(null), "Ctrl+M"),
                    Ui.Big("", "Скрыть", "Скрыть слайд", "Не показывать слайд при демонстрации.", ToggleHidden),
                    Ui.Big("", "Удалить", "Удалить слайд", "Удалить текущий слайд.", DeleteSlide)));
        }

        UIElement BuildView()
        {
            var themes = new WrapPanel { MaxWidth = 380 };
            foreach (var t in ThemeManager.All())
            {
                var th = t;
                var sw = new Border { Width = 42, Height = 26, CornerRadius = new CornerRadius(6), Background = new LinearGradientBrush(t.Bg1, t.Bg2, 45), BorderThickness = new Thickness(2), BorderBrush = new LinearGradientBrush(t.Accent1, t.Accent2, 0) };
                var b = new FancyButton { Content = sw, Padding = new Thickness(2), Margin = new Thickness(1), Flat = true, IsToggled = ThemeManager.Current.Name == t.Name };
                b.Click += (s, e) => { S.ThemeName = th.Description == "Пользовательская тема" ? "@custom" : th.Name; S.Save(); ThemeManager.Apply(th); };
                Ui.Tip(b, "Тема «" + t.Name + "»", t.Description);
                themes.Children.Add(b);
            }
            return Strip(
                Ui.Group("Масштаб",
                    Ui.Big("", "Крупнее", "Увеличить", "Увеличить масштаб слайда.", () => _ed.SetZoom(_ed.Zoom * 1.15), "Ctrl++ / Ctrl+колесо"),
                    Ui.Big("", "Мельче", "Уменьшить", "Уменьшить масштаб слайда.", () => _ed.SetZoom(_ed.Zoom / 1.15), "Ctrl+−"),
                    Ui.Big("", "По окну", "По размеру окна", "Вписать слайд целиком.", () => _ed.Fit(), "Ctrl+0"),
                    Ui.Big(null, "100%", "Реальный размер", "Масштаб 100%.", () => _ed.SetZoom(1))),
                Ui.Group("Панели",
                    Ui.Column(
                        Ui.Check("Миниатюры", S.ShowThumbs, v => { S.ShowThumbs = v; _colThumbs.Width = new GridLength(v ? 212 : 0); S.Save(); }, "Панель миниатюр", "Список слайдов слева."),
                        Ui.Check("Заметки", S.ShowNotes, v => { S.ShowNotes = v; _rowNotes.Height = new GridLength(v ? 110 : 0); S.Save(); }, "Заметки докладчика", "Поле заметок под слайдом."),
                        Ui.Check("Инспектор", S.ShowInspector, v => { S.ShowInspector = v; _colInspector.Width = new GridLength(v ? 270 : 0); S.Save(); }, "Инспектор", "Панель точной настройки положения, размера и оформления справа."))),
                Ui.Group("Помощники",
                    Ui.Column(
                        Ui.Check("Сетка (1 см)", S.ShowGrid, v => { S.ShowGrid = v; _ed.ShowGrid = v; _ed.Rebuild(); S.Save(); }, "Сетка", "Сантиметровая сетка и оси центра слайда."),
                        Ui.Check("Привязка и направляющие", S.Snap, v => { S.Snap = v; _ed.Snap = v; S.Save(); }, "Умная привязка", "При перемещении объекты притягиваются к краям и центрам слайда и других объектов. Удерживайте Alt, чтобы временно отключить."))),
                Ui.Group("Тема оформления", themes, Ui.Big("", "Настроить", "Настройка темы", "Создайте собственную тему: цвета, градиенты, скругления, масштаб интерфейса.", ShowSettings)));
        }

        UIElement BuildShow() => Strip(
            Ui.Group("Демонстрация",
                Ui.Big("", "С начала", "Показ с начала", "Полноэкранная демонстрация с первого слайда. Стрелки/пробел — листать, Esc — выход, P — перо, B/W — чёрный/белый экран.", () => StartShow(0), "F5"),
                Ui.Big("", "С текущего", "Показ с текущего слайда", "Начать демонстрацию с выбранного слайда.", () => StartShow(_ed.SlideIndex), "Shift+F5")),
            Ui.Group("Параметры",
                Ui.Column(
                    Ui.Check("Плавные переходы", S.ShowTransitions, v => { S.ShowTransitions = v; S.Save(); }, "Переходы", "Мягкое появление слайдов при показе."),
                    Ui.Check("Подтверждать ссылки", S.ConfirmLinks, v => { S.ConfirmLinks = v; S.Save(); }, "Безопасные ссылки", "Перед переходом по гиперссылке показывается её адрес."))));

        static FrameworkElement ShapeIcon(string id, double size)
        {
            double w = size, h = size * 0.75;
            var g = id == "line" || id == "arrowLine" ? PresetGeometry.Build("line", w, h, null) : PresetGeometry.Build(id, w, h, null);
            var geo = SlideRenderer.BuildGeometry(g, 1, 1, false, false);
            var p = new System.Windows.Shapes.Path { Data = geo, StrokeThickness = 1.4, Width = w, Height = h, Stretch = Stretch.None };
            p.SetResourceReference(System.Windows.Shapes.Shape.StrokeProperty, "B.Text");
            if (id != "line" && id != "arrowLine") p.SetResourceReference(System.Windows.Shapes.Shape.FillProperty, "B.AccentSoft");
            var c = new Grid { Width = w, Height = h };
            c.Children.Add(p);
            if (id == "arrowLine") c.Children.Add(new System.Windows.Shapes.Polygon { Points = new PointCollection { new Point(w, h), new Point(w - 7, h - 2), new Point(w - 3, h - 6) }, Fill = ThemeManager.Brush("B.Text") });
            return c;
        }

        void ShapeGallery(UIElement anchor)
        {
            Ui.Pick(anchor, PresetGeometry.Gallery, g =>
            {
                var r = Ui.Row(ShapeIcon(g.Id, 22), Ui.Spacer(10), Ui.Text(g.Title, 13));
                r.ToolTip = g.Hint;
                return r;
            }, g => StartTool(g.Id), 460, 280, "Поиск фигуры", g => g.Title);
        }

        void StartTool(string id)
        {
            if (!EnsureEditable()) return;
            _ed.SetTool(id);
            _stHint.Text = id == "textbox" ? "Протяните мышью область надписи на слайде (Esc — отмена)" : "Протяните мышью на слайде, чтобы нарисовать фигуру (Shift — пропорционально, Esc — отмена)";
            RebuildRibbon();
        }
    }
}
