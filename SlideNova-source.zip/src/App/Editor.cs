// Редактор слайда: выделение, перемещение, изменение размеров, поворот, создание фигур, правка текста.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using SlideNova.Core;

namespace SlideNova
{
    public sealed class UndoStack
    {
        sealed class Snap { public List<SlideModel> Slides; public int Index; public double W, H; public string Label; }
        readonly List<Snap> _undo = new List<Snap>(), _redo = new List<Snap>();
        const int Max = 120;
        public bool CanUndo => _undo.Count > 0;
        public bool CanRedo => _redo.Count > 0;
        public string UndoLabel => _undo.Count > 0 ? _undo[_undo.Count - 1].Label : "";
        public string RedoLabel => _redo.Count > 0 ? _redo[_redo.Count - 1].Label : "";

        static Snap Take(PresentationModel p, int idx, string label) => new Snap { Slides = p.Slides.Select(s => s.Clone()).ToList(), Index = idx, W = p.SlideW, H = p.SlideH, Label = label };

        public void Push(PresentationModel p, int idx, string label)
        {
            _undo.Add(Take(p, idx, label));
            if (_undo.Count > Max) _undo.RemoveAt(0);
            _redo.Clear();
        }

        public int Undo(PresentationModel p, int curIdx)
        {
            if (!CanUndo) return curIdx;
            var s = _undo[_undo.Count - 1]; _undo.RemoveAt(_undo.Count - 1);
            _redo.Add(Take(p, curIdx, s.Label));
            return Restore(p, s);
        }

        public int Redo(PresentationModel p, int curIdx)
        {
            if (!CanRedo) return curIdx;
            var s = _redo[_redo.Count - 1]; _redo.RemoveAt(_redo.Count - 1);
            _undo.Add(Take(p, curIdx, s.Label));
            return Restore(p, s);
        }

        static int Restore(PresentationModel p, Snap s)
        {
            p.Slides = s.Slides.Select(x => x.Clone()).ToList();
            if (p.SlideW != s.W || p.SlideH != s.H) { p.SlideW = s.W; p.SlideH = s.H; p.SizeDirty = true; }
            return Math.Max(0, Math.Min(s.Index, p.Slides.Count - 1));
        }

        public void Clear() { _undo.Clear(); _redo.Clear(); }
    }

    public static class ShapeClipboard
    {
        public static List<ShapeModel> Items = new List<ShapeModel>();
        public static PresentationModel Source;
        public static SlideModel SourceSlide;
    }

    public sealed class SlideEditor : Grid
    {
        public PresentationModel Pres { get; private set; }
        public SlideModel Slide { get; private set; }
        public int SlideIndex { get; private set; }
        public SlideRenderer Renderer { get; private set; }
        public ImageCache Images { get; private set; }
        public UndoStack Undo = new UndoStack();
        public readonly List<ShapeModel> Selection = new List<ShapeModel>();
        public bool ReadOnly { get; set; }
        public bool ShowGrid { get; set; }
        public bool Snap { get; set; } = true;
        public string Tool { get; private set; }          // null = выбор; иначе геометрия для вставки ("textbox", "line", "rect"...)
        public double Zoom { get; private set; } = 1;
        public bool FitMode { get; private set; } = true;

        public event Action SelectionChanged;
        public event Action<string> Changed;          // модель изменена (подпись действия)
        public event Action ZoomChanged;
        public event Action ToolFinished;
        public event Action<ShapeModel> TableEditRequested;

        readonly ScrollViewer _scroll;
        readonly Border _page;
        readonly Grid _host;
        readonly Canvas _overlay, _editLayer;
        Canvas _slideVisual;
        Dictionary<ShapeModel, FrameworkElement> _map = new Dictionary<ShapeModel, FrameworkElement>();
        RichTextBox _rtb; ShapeModel _editing;
        readonly TextBlock _empty;

        public SlideEditor()
        {
            ClipToBounds = true;
            SetResourceReference(BackgroundProperty, "B.Canvas");
            _host = new Grid { Background = Brushes.Transparent, ClipToBounds = true };
            _overlay = new Canvas { IsHitTestVisible = false };
            _editLayer = new Canvas();
            _page = new Border { Child = _host, Margin = new Thickness(40), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            _page.Effect = new DropShadowEffect { BlurRadius = 28, ShadowDepth = 4, Opacity = 0.45, Color = Colors.Black };
            var outer = new Grid();
            outer.Children.Add(_page);
            _scroll = new ScrollViewer { HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = outer, Focusable = false };
            Children.Add(_scroll);
            _empty = Ui.Text("", 14, false, "B.SubText"); _empty.HorizontalAlignment = HorizontalAlignment.Center; _empty.VerticalAlignment = VerticalAlignment.Center;
            Children.Add(_empty);
            Focusable = true;
            FocusVisualStyle = null;
            _host.MouseLeftButtonDown += OnDown;
            _host.MouseMove += OnMove;
            _host.MouseLeftButtonUp += OnUp;
            _host.MouseRightButtonDown += (s, e) => { var p = e.GetPosition(_host); var hit = HitTest(p); if (hit != null && !Selection.Contains(hit)) { Select(hit); } Focus(); };
            SizeChanged += (s, e) => { if (FitMode) Fit(); };
            PreviewMouseWheel += (s, e) =>
            {
                if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) { SetZoom(Zoom * (e.Delta > 0 ? 1.1 : 1 / 1.1)); e.Handled = true; }
            };
            AllowDrop = false;
        }

        public void Load(PresentationModel p, ImageCache img)
        {
            EndTextEdit(false);
            Pres = p; Images = img; Renderer = new SlideRenderer(p, img);
            Undo.Clear(); Selection.Clear();
            ShowSlide(0);
        }

        public void ShowSlide(int idx)
        {
            EndTextEdit(true);
            if (Pres == null || Pres.Slides.Count == 0) { Slide = null; _host.Children.Clear(); _empty.Text = "Нет слайдов"; return; }
            _empty.Text = "";
            SlideIndex = Math.Max(0, Math.Min(idx, Pres.Slides.Count - 1));
            Slide = Pres.Slides[SlideIndex];
            Selection.Clear();
            Rebuild();
            if (FitMode) Fit();
            SelectionChanged?.Invoke();
        }

        public void Rebuild()
        {
            if (Slide == null) return;
            _host.Children.Clear();
            _map = new Dictionary<ShapeModel, FrameworkElement>();
            _slideVisual = Renderer.RenderSlide(Slide, SlideIndex + 1, new SlideRenderOptions { PlaceholderHints = true, HideTextOf = _editing }, _map);
            _host.Width = _slideVisual.Width; _host.Height = _slideVisual.Height;
            _host.Children.Add(_slideVisual);
            if (ShowGrid) _host.Children.Add(GridLines(_slideVisual.Width, _slideVisual.Height));
            _host.Children.Add(_editLayer);
            _host.Children.Add(_overlay);
            Selection.RemoveAll(s => !Slide.Shapes.Contains(s));
            DrawSelection();
        }

        UIElement GridLines(double w, double h)
        {
            var c = new Canvas { IsHitTestVisible = false };
            double step = Px.D(Units.EmuPerCm);
            var br = new SolidColorBrush(Color.FromArgb(40, 120, 120, 160)); br.Freeze();
            for (double x = step; x < w; x += step) c.Children.Add(new Line { X1 = x, X2 = x, Y1 = 0, Y2 = h, Stroke = br, StrokeThickness = 0.5 });
            for (double y = step; y < h; y += step) c.Children.Add(new Line { X1 = 0, X2 = w, Y1 = y, Y2 = y, Stroke = br, StrokeThickness = 0.5 });
            var mid = new SolidColorBrush(Color.FromArgb(70, 255, 80, 160)); mid.Freeze();
            c.Children.Add(new Line { X1 = w / 2, X2 = w / 2, Y1 = 0, Y2 = h, Stroke = mid, StrokeThickness = 0.7 });
            c.Children.Add(new Line { X1 = 0, X2 = w, Y1 = h / 2, Y2 = h / 2, Stroke = mid, StrokeThickness = 0.7 });
            return c;
        }

        // ---------------- Масштаб ----------------
        public void SetZoom(double z, bool fit = false)
        {
            Zoom = Units.Clamp(z, 0.1, 6);
            FitMode = fit;
            _page.LayoutTransform = new ScaleTransform(Zoom, Zoom);
            DrawSelection();
            ZoomChanged?.Invoke();
        }

        public void Fit()
        {
            if (Pres == null || ActualWidth < 50 || ActualHeight < 50) return;
            double w = Px.D(Pres.SlideW), h = Px.D(Pres.SlideH);
            double z = Math.Min((ActualWidth - 90) / w, (ActualHeight - 90) / h);
            SetZoom(Math.Max(0.1, z), true);
        }

        // ---------------- Выделение ----------------
        public void Select(ShapeModel s, bool add = false)
        {
            if (!add) Selection.Clear();
            if (s != null && !Selection.Contains(s)) Selection.Add(s);
            DrawSelection();
            SelectionChanged?.Invoke();
        }

        public void SelectAll()
        {
            if (Slide == null) return;
            Selection.Clear(); Selection.AddRange(Slide.Shapes.Where(s => !s.Locked));
            DrawSelection(); SelectionChanged?.Invoke();
        }

        public void ClearSelection() { if (Selection.Count == 0) return; Selection.Clear(); DrawSelection(); SelectionChanged?.Invoke(); }

        static Point Rot(Point p, double deg)
        {
            double a = deg * Math.PI / 180, c = Math.Cos(a), s = Math.Sin(a);
            return new Point(p.X * c - p.Y * s, p.X * s + p.Y * c);
        }

        static Point[] Corners(ShapeModel s)
        {
            double x = Px.D(s.X), y = Px.D(s.Y), w = Px.D(s.W), h = Px.D(s.H);
            var c = new Point(x + w / 2, y + h / 2);
            var pts = new[] { new Point(-w / 2, -h / 2), new Point(w / 2, -h / 2), new Point(w / 2, h / 2), new Point(-w / 2, h / 2) };
            return pts.Select(p => { var r = Rot(p, s.Rot); return new Point(c.X + r.X, c.Y + r.Y); }).ToArray();
        }

        Point[] HandlePoints(ShapeModel s)
        {
            double x = Px.D(s.X), y = Px.D(s.Y), w = Px.D(s.W), h = Px.D(s.H);
            var c = new Point(x + w / 2, y + h / 2);
            var loc = new[]
            {
                new Point(-w/2,-h/2), new Point(0,-h/2), new Point(w/2,-h/2), new Point(w/2,0),
                new Point(w/2,h/2), new Point(0,h/2), new Point(-w/2,h/2), new Point(-w/2,0),
                new Point(0,-h/2 - 26 / Zoom)
            };
            return loc.Select(p => { var r = Rot(p, s.Rot); return new Point(c.X + r.X, c.Y + r.Y); }).ToArray();
        }

        public void DrawSelection()
        {
            _overlay.Children.Clear();
            if (Slide == null) return;
            var accent = ThemeManager.Brush("B.AccentSolid");
            double k = 1 / Math.Max(0.1, Zoom);
            foreach (var s in Selection)
            {
                var cs = Corners(s);
                _overlay.Children.Add(new Polygon { Points = new PointCollection(cs), Stroke = accent, StrokeThickness = 1.5 * k, StrokeDashArray = Selection.Count > 1 ? new DoubleCollection { 3, 2 } : null });
                if (Selection.Count == 1 && !ReadOnly && !s.Locked)
                {
                    var hp = HandlePoints(s);
                    _overlay.Children.Add(new Line { X1 = (hp[1].X), Y1 = hp[1].Y, X2 = hp[8].X, Y2 = hp[8].Y, Stroke = accent, StrokeThickness = 1 * k });
                    for (int i = 0; i < 9; i++)
                    {
                        double size = (i == 8 ? 12 : 9) * k;
                        FrameworkElement h = i == 8 ? (FrameworkElement)new Ellipse() : new Rectangle { RadiusX = 2 * k, RadiusY = 2 * k };
                        ((Shape)h).Fill = i == 8 ? ThemeManager.Brush("B.Accent2Solid") : Brushes.White;
                        ((Shape)h).Stroke = accent; ((Shape)h).StrokeThickness = 1.5 * k;
                        h.Width = size; h.Height = size;
                        Canvas.SetLeft(h, hp[i].X - size / 2); Canvas.SetTop(h, hp[i].Y - size / 2);
                        _overlay.Children.Add(h);
                    }
                }
            }
            if (_rubber != null) _overlay.Children.Add(_rubber);
            foreach (var g in _guides) _overlay.Children.Add(g);
        }

        public ShapeModel HitTest(Point p)
        {
            if (Slide == null) return null;
            double tol = 4 / Math.Max(0.1, Zoom);
            for (int i = Slide.Shapes.Count - 1; i >= 0; i--)
            {
                var s = Slide.Shapes[i];
                if (s.Locked) continue;
                double x = Px.D(s.X), y = Px.D(s.Y), w = Px.D(s.W), h = Px.D(s.H);
                var c = new Point(x + w / 2, y + h / 2);
                var l = Rot(new Point(p.X - c.X, p.Y - c.Y), -s.Rot);
                if (Math.Abs(l.X) <= w / 2 + tol && Math.Abs(l.Y) <= h / 2 + tol)
                {
                    // прозрачные фигуры без текста и заливки выбираются только по контуру
                    bool hollow = (s.Fill == null || s.Fill.Kind == FillKind.None) && (s.Text == null || s.Text.IsEmpty) && s.Kind == ShapeKind.Shape && s.PlaceholderType == null;
                    if (hollow && w > 20 && h > 20 && Math.Abs(l.X) < w / 2 - 6 / Zoom && Math.Abs(l.Y) < h / 2 - 6 / Zoom) continue;
                    return s;
                }
            }
            return null;
        }

        int HitHandle(Point p)
        {
            if (Selection.Count != 1 || ReadOnly || Selection[0].Locked) return -1;
            var hp = HandlePoints(Selection[0]);
            double tol = 7 / Math.Max(0.1, Zoom);
            for (int i = 8; i >= 0; i--) if ((hp[i] - p).Length <= tol) return i;
            return -1;
        }

        // ---------------- Мышь ----------------
        enum Mode { None, Move, Resize, Rotate, Rubber, Create }
        Mode _mode; Point _start; int _handle; bool _moved;
        List<ShapeModel> _origState; ShapeModel _origSingle;
        Rectangle _rubber; readonly List<UIElement> _guides = new List<UIElement>();
        ShapeModel _creating;

        public void SetTool(string tool)
        {
            EndTextEdit(true);
            Tool = tool;
            _host.Cursor = tool == null ? null : Cursors.Cross;
        }

        void OnDown(object sender, MouseButtonEventArgs e)
        {
            Focus();
            if (Slide == null) return;
            var p = e.GetPosition(_host);
            _start = p; _moved = false;
            if (_editing != null)
            {
                var hitEdit = HitTest(p);
                if (hitEdit == _editing) return;
                EndTextEdit(true);
            }
            if (Tool != null && !ReadOnly)
            {
                _mode = Mode.Create;
                _creating = NewShapeForTool(Tool, p);
                _host.CaptureMouse();
                e.Handled = true;
                return;
            }
            int h = HitHandle(p);
            if (h >= 0)
            {
                _mode = h == 8 ? Mode.Rotate : Mode.Resize; _handle = h;
                _origSingle = Selection[0].Clone();
                _host.CaptureMouse(); e.Handled = true; return;
            }
            var hit = HitTest(p);
            if (e.ClickCount == 2 && hit != null && !ReadOnly)
            {
                if (hit.Kind == ShapeKind.Shape) { Select(hit); BeginTextEdit(hit); e.Handled = true; return; }
                if (hit.Kind == ShapeKind.Table) { Select(hit); TableEditRequested?.Invoke(hit); e.Handled = true; return; }
            }
            bool add = Keyboard.Modifiers.HasFlag(ModifierKeys.Control) || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
            if (hit != null)
            {
                if (add) { if (Selection.Contains(hit)) Selection.Remove(hit); else Selection.Add(hit); DrawSelection(); SelectionChanged?.Invoke(); }
                else if (!Selection.Contains(hit)) Select(hit);
                if (!ReadOnly && Selection.Count > 0)
                {
                    _mode = Mode.Move;
                    _origState = Selection.Select(x => x.Clone()).ToList();
                    _host.CaptureMouse();
                }
            }
            else
            {
                if (!add) ClearSelection();
                _mode = Mode.Rubber;
                _rubber = new Rectangle { StrokeThickness = 1 / Zoom, Stroke = ThemeManager.Brush("B.AccentSolid"), Fill = ThemeManager.Brush("B.AccentSoft") };
                _host.CaptureMouse();
            }
            e.Handled = true;
        }

        void OnMove(object sender, MouseEventArgs e)
        {
            if (_mode == Mode.None) { UpdateCursor(e.GetPosition(_host)); return; }
            var p = e.GetPosition(_host);
            if (!_moved && (p - _start).Length < 2.5 / Zoom) return;
            _moved = true;
            bool shift = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
            switch (_mode)
            {
                case Mode.Move:
                    {
                        double dx = p.X - _start.X, dy = p.Y - _start.Y;
                        if (shift) { if (Math.Abs(dx) > Math.Abs(dy)) dy = 0; else dx = 0; }
                        // привязка по первому объекту
                        _guides.Clear();
                        if (Snap && !Keyboard.Modifiers.HasFlag(ModifierKeys.Alt) && _origState.Count > 0)
                        {
                            var o = _origState[0];
                            SnapDelta(Px.D(o.X) + dx, Px.D(o.Y) + dy, Px.D(o.W), Px.D(o.H), Selection, out double ax, out double ay);
                            dx += ax; dy += ay;
                        }
                        for (int i = 0; i < Selection.Count; i++)
                        {
                            Selection[i].X = _origState[i].X + Px.E(dx); Selection[i].Y = _origState[i].Y + Px.E(dy);
                            if (_map.TryGetValue(Selection[i], out var el)) { Canvas.SetLeft(el, Px.D(Selection[i].X)); Canvas.SetTop(el, Px.D(Selection[i].Y)); }
                        }
                        DrawSelection();
                        break;
                    }
                case Mode.Resize: ResizeTo(Selection[0], _origSingle, _handle, p, shift); RefreshShape(Selection[0]); DrawSelection(); break;
                case Mode.Rotate:
                    {
                        var s = Selection[0];
                        double cx = Px.D(s.X + s.W / 2), cy = Px.D(s.Y + s.H / 2);
                        double ang = Math.Atan2(p.Y - cy, p.X - cx) * 180 / Math.PI + 90;
                        if (shift) ang = Math.Round(ang / 15) * 15;
                        ang = ((ang % 360) + 360) % 360;
                        if (Math.Abs(ang) < 1.5 || Math.Abs(ang - 360) < 1.5) ang = 0;
                        s.Rot = ang;
                        if (_map.TryGetValue(s, out var el)) el.RenderTransform = new RotateTransform(ang, Px.D(s.W) / 2, Px.D(s.H) / 2);
                        DrawSelection();
                        break;
                    }
                case Mode.Rubber:
                    {
                        var r = new Rect(_start, p);
                        Canvas.SetLeft(_rubber, r.X); Canvas.SetTop(_rubber, r.Y); _rubber.Width = r.Width; _rubber.Height = r.Height;
                        DrawSelection();
                        break;
                    }
                case Mode.Create:
                    {
                        var s = _creating;
                        double x1 = _start.X, y1 = _start.Y, x2 = p.X, y2 = p.Y;
                        bool line = PresetGeometry.IsLineLike(s.Geometry);
                        if (shift)
                        {
                            if (line)
                            {
                                double ang = Math.Atan2(y2 - y1, x2 - x1); double len = (p - _start).Length;
                                ang = Math.Round(ang / (Math.PI / 4)) * (Math.PI / 4);
                                x2 = x1 + Math.Cos(ang) * len; y2 = y1 + Math.Sin(ang) * len;
                            }
                            else { double d = Math.Max(Math.Abs(x2 - x1), Math.Abs(y2 - y1)); x2 = x1 + Math.Sign(x2 - x1) * d; y2 = y1 + Math.Sign(y2 - y1) * d; }
                        }
                        s.X = Px.E(Math.Min(x1, x2)); s.Y = Px.E(Math.Min(y1, y2)); s.W = Px.E(Math.Abs(x2 - x1)); s.H = Px.E(Math.Abs(y2 - y1));
                        if (line) { s.FlipH = x2 < x1; s.FlipV = y2 < y1; }
                        if (!Slide.Shapes.Contains(s)) { Undo.Push(Pres, SlideIndex, "Вставка объекта"); Slide.Shapes.Add(s); Selection.Clear(); Selection.Add(s); }
                        RefreshShape(s); DrawSelection();
                        break;
                    }
            }
        }

        void SnapDelta(double x, double y, double w, double h, List<ShapeModel> exclude, out double ax, out double ay)
        {
            ax = 0; ay = 0;
            double tol = 6 / Zoom;
            double W = Px.D(Pres.SlideW), H = Px.D(Pres.SlideH);
            var xs = new List<double> { 0, W / 2, W }; var ys = new List<double> { 0, H / 2, H };
            foreach (var s in Slide.Shapes) { if (exclude.Contains(s) || s.Locked) continue; xs.Add(Px.D(s.X)); xs.Add(Px.D(s.X + s.W / 2)); xs.Add(Px.D(s.X + s.W)); ys.Add(Px.D(s.Y)); ys.Add(Px.D(s.Y + s.H / 2)); ys.Add(Px.D(s.Y + s.H)); }
            double best = tol; double gx = double.NaN;
            foreach (var cand in new[] { x, x + w / 2, x + w })
                foreach (var t in xs) if (Math.Abs(t - cand) < best) { best = Math.Abs(t - cand); ax = t - cand; gx = t; }
            best = tol; double gy = double.NaN;
            foreach (var cand in new[] { y, y + h / 2, y + h })
                foreach (var t in ys) if (Math.Abs(t - cand) < best) { best = Math.Abs(t - cand); ay = t - cand; gy = t; }
            var br = ThemeManager.Brush("B.Accent2Solid");
            if (!double.IsNaN(gx)) _guides.Add(new Line { X1 = gx, X2 = gx, Y1 = 0, Y2 = H, Stroke = br, StrokeThickness = 1 / Zoom, StrokeDashArray = new DoubleCollection { 4, 3 } });
            if (!double.IsNaN(gy)) _guides.Add(new Line { X1 = 0, X2 = W, Y1 = gy, Y2 = gy, Stroke = br, StrokeThickness = 1 / Zoom, StrokeDashArray = new DoubleCollection { 4, 3 } });
        }

        static void ResizeTo(ShapeModel s, ShapeModel o, int handle, Point p, bool keepAspect)
        {
            double ox = Px.D(o.X), oy = Px.D(o.Y), ow = Px.D(o.W), oh = Px.D(o.H);
            var c = new Point(ox + ow / 2, oy + oh / 2);
            var l = Rot(new Point(p.X - c.X, p.Y - c.Y), -o.Rot);
            double left = -ow / 2, right = ow / 2, top = -oh / 2, bottom = oh / 2;
            bool L = handle == 0 || handle == 6 || handle == 7, R = handle == 2 || handle == 3 || handle == 4;
            bool T = handle == 0 || handle == 1 || handle == 2, B = handle == 4 || handle == 5 || handle == 6;
            if (L) left = l.X; if (R) right = l.X; if (T) top = l.Y; if (B) bottom = l.Y;
            bool corner = (L || R) && (T || B);
            if ((keepAspect || o.Kind == ShapeKind.Picture && !Keyboard.Modifiers.HasFlag(ModifierKeys.Alt) && corner) && corner && ow > 0 && oh > 0)
            {
                double nw = Math.Abs(right - left), nh = Math.Abs(bottom - top), ratio = ow / oh;
                if (nw / nh > ratio) nh = nw / ratio; else nw = nh * ratio;
                if (L) left = right - nw * Math.Sign(right - left == 0 ? 1 : right - left); else right = left + nw * Math.Sign(right - left == 0 ? 1 : right - left);
                if (T) top = bottom - nh * Math.Sign(bottom - top == 0 ? 1 : bottom - top); else bottom = top + nh * Math.Sign(bottom - top == 0 ? 1 : bottom - top);
            }
            bool line = PresetGeometry.IsLineLike(o.Geometry) || o.Kind == ShapeKind.Connector;
            s.FlipH = o.FlipH; s.FlipV = o.FlipV;
            if (right < left) { var t = left; left = right; right = t; if (line || o.Kind == ShapeKind.Shape) s.FlipH = !o.FlipH; }
            if (bottom < top) { var t = top; top = bottom; bottom = t; if (line || o.Kind == ShapeKind.Shape) s.FlipV = !o.FlipV; }
            double minSize = line ? 0 : 2;
            double nwid = Math.Max(minSize, right - left), nhei = Math.Max(minSize, bottom - top);
            var lc = new Point((left + right) / 2, (top + bottom) / 2);
            var wc = Rot(lc, o.Rot);
            double ncx = c.X + wc.X, ncy = c.Y + wc.Y;
            s.W = Px.E(nwid); s.H = Px.E(nhei); s.X = Px.E(ncx - nwid / 2); s.Y = Px.E(ncy - nhei / 2);
            if (s.Kind == ShapeKind.Table && s.Table != null && o.Table != null)
            {
                double kx = o.W > 0 ? s.W / o.W : 1, ky = o.H > 0 ? s.H / o.H : 1;
                for (int i = 0; i < s.Table.ColWidths.Count; i++) s.Table.ColWidths[i] = o.Table.ColWidths[i] * kx;
                for (int i = 0; i < s.Table.RowHeights.Count; i++) s.Table.RowHeights[i] = o.Table.RowHeights[i] * ky;
                s.DirtyTable = true;
            }
        }

        void OnUp(object sender, MouseButtonEventArgs e)
        {
            var mode = _mode; _mode = Mode.None;
            _host.ReleaseMouseCapture();
            _guides.Clear();
            var p = e.GetPosition(_host);
            switch (mode)
            {
                case Mode.Move:
                    if (_moved)
                    {
                        var now = Selection.Select(s => new { s, s.X, s.Y }).ToList();
                        for (int i = 0; i < Selection.Count; i++) { Selection[i].X = _origState[i].X; Selection[i].Y = _origState[i].Y; }
                        Undo.Push(Pres, SlideIndex, "Перемещение");
                        foreach (var n in now) { n.s.X = n.X; n.s.Y = n.Y; n.s.DirtyXfrm = true; }
                        Changed?.Invoke("Перемещение");
                    }
                    break;
                case Mode.Resize:
                case Mode.Rotate:
                    if (_moved)
                    {
                        var s = Selection[0]; var cur = s.Clone();
                        CopyGeom(_origSingle, s);
                        Undo.Push(Pres, SlideIndex, mode == Mode.Rotate ? "Поворот" : "Изменение размера");
                        CopyGeom(cur, s);
                        s.DirtyXfrm = true;
                        Changed?.Invoke(mode == Mode.Rotate ? "Поворот" : "Изменение размера");
                        RefreshShape(s);
                    }
                    break;
                case Mode.Rubber:
                    {
                        var r = new Rect(_start, p);
                        _rubber = null;
                        if (r.Width > 2 && r.Height > 2)
                        {
                            foreach (var s in Slide.Shapes)
                            {
                                if (s.Locked) continue;
                                var b = new Rect(Px.D(s.X), Px.D(s.Y), Px.D(s.W), Px.D(s.H));
                                if (r.Contains(b) && !Selection.Contains(s)) Selection.Add(s);
                            }
                        }
                        DrawSelection(); SelectionChanged?.Invoke();
                        break;
                    }
                case Mode.Create:
                    {
                        var s = _creating; _creating = null;
                        if (!Slide.Shapes.Contains(s))
                        {
                            // щелчок без перетаскивания: объект стандартного размера
                            bool line = PresetGeometry.IsLineLike(s.Geometry);
                            s.W = Px.E(Tool == "textbox" ? 260 : line ? 180 : 150); s.H = Px.E(Tool == "textbox" ? 40 : line ? 0 : 110);
                            if (Tool == "textbox") s.W = Px.E(260);
                            s.X = Px.E(_start.X); s.Y = Px.E(_start.Y);
                            Undo.Push(Pres, SlideIndex, "Вставка объекта");
                            Slide.Shapes.Add(s);
                        }
                        if (s.W < Px.E(4) && !PresetGeometry.IsLineLike(s.Geometry)) s.W = Px.E(150);
                        if (s.H < Px.E(4) && !PresetGeometry.IsLineLike(s.Geometry)) s.H = Px.E(Tool == "textbox" ? 40 : 110);
                        var wasText = Tool == "textbox";
                        SetTool(null);
                        Rebuild();
                        Select(s);
                        Changed?.Invoke("Вставка объекта");
                        ToolFinished?.Invoke();
                        if (wasText) BeginTextEdit(s);
                        break;
                    }
            }
            DrawSelection();
        }

        static void CopyGeom(ShapeModel from, ShapeModel to)
        {
            to.X = from.X; to.Y = from.Y; to.W = from.W; to.H = from.H; to.Rot = from.Rot; to.FlipH = from.FlipH; to.FlipV = from.FlipV;
            if (from.Table != null && to.Table != null) { to.Table.ColWidths = from.Table.ColWidths.ToList(); to.Table.RowHeights = from.Table.RowHeights.ToList(); }
        }

        void UpdateCursor(Point p)
        {
            if (Tool != null) { _host.Cursor = Cursors.Cross; return; }
            int h = HitHandle(p);
            if (h == 8) _host.Cursor = Cursors.Hand;
            else if (h >= 0)
            {
                double ang = (Selection[0].Rot + new[] { 135, 90, 45, 0, 135, 90, 45, 0 }[h]) % 180;
                _host.Cursor = ang < 22.5 || ang >= 157.5 ? Cursors.SizeWE : ang < 67.5 ? Cursors.SizeNESW : ang < 112.5 ? Cursors.SizeNS : Cursors.SizeNWSE;
            }
            else _host.Cursor = HitTest(p) != null ? (ReadOnly ? Cursors.Arrow : Cursors.SizeAll) : null;
        }

        public void RefreshShape(ShapeModel s)
        {
            if (!_map.TryGetValue(s, out var old)) { Rebuild(); return; }
            var nw = Renderer.RenderShape(s, new SlideRenderOptions { PlaceholderHints = true, HideTextOf = _editing }, SlideIndex + 1, Slide);
            int idx = _slideVisual.Children.IndexOf(old);
            if (idx < 0 || nw == null) { Rebuild(); return; }
            _slideVisual.Children.RemoveAt(idx);
            _slideVisual.Children.Insert(idx, nw);
            _map[s] = nw;
        }

        // ---------------- Новые фигуры ----------------
        ShapeModel NewShapeForTool(string tool, Point p)
        {
            var theme = Pres.Theme;
            Rgba accent = theme.Colors.TryGetValue("accent1", out var a) ? a : Rgba.FromRgb(0x4472C4);
            var s = new ShapeModel { Id = Slide.NextShapeId(), X = Px.E(p.X), Y = Px.E(p.Y) };
            if (tool == "textbox")
            {
                s.IsTextBox = true; s.Name = "Надпись " + s.Id;
                s.Fill = FillDef.NoFill(); s.Line = LineDef.None();
                s.Text = TextBodyModel.FromPlain("", new LevelStyle { SizePt = 20, Font = theme.MinorFont, Color = theme.Colors.TryGetValue("dk1", out var dk) ? dk : Rgba.Black });
                s.Text.AutoFitShape = true;
                return s;
            }
            s.Geometry = tool;
            s.Name = (PresetGeometry.Gallery.FirstOrDefault(g => g.Id == tool)?.Title ?? "Фигура") + " " + s.Id;
            if (PresetGeometry.IsLineLike(tool))
            {
                s.Kind = ShapeKind.Connector;
                s.Fill = FillDef.NoFill();
                s.Line = new LineDef { Visible = true, Color = accent, WidthEmu = 28575, TailEnd = tool == "arrowLine" ? "triangle" : "none" };
                if (tool == "arrowLine") s.Geometry = "line";
                return s;
            }
            var darker = Px.R(Px.Shade(Px.C(accent), 0.7));
            s.Fill = FillDef.Solid(accent);
            s.Line = new LineDef { Visible = true, Color = darker, WidthEmu = 12700 };
            s.Text = TextBodyModel.FromPlain("", new LevelStyle { SizePt = 18, Font = theme.MinorFont, Color = Rgba.White, Align = "ctr" });
            s.Text.Anchor = "ctr";
            return s;
        }

        public void AddShapes(IEnumerable<ShapeModel> shapes, string label)
        {
            if (Slide == null) return;
            Undo.Push(Pres, SlideIndex, label);
            Selection.Clear();
            foreach (var s in shapes) { s.Id = Slide.NextShapeId(); Slide.Shapes.Add(s); Selection.Add(s); }
            Rebuild();
            Changed?.Invoke(label);
            SelectionChanged?.Invoke();
        }

        /// <summary>Применить изменение к выделенным объектам с записью в историю.</summary>
        public void Modify(string label, Action<ShapeModel> act, Func<ShapeModel, bool> filter = null)
        {
            if (ReadOnly || Slide == null) return;
            if (_editing != null) EndTextEdit(true);
            var targets = Selection.Where(s => filter == null || filter(s)).ToList();
            if (targets.Count == 0) return;
            Undo.Push(Pres, SlideIndex, label);
            foreach (var s in targets) act(s);
            Rebuild();
            Changed?.Invoke(label);
            SelectionChanged?.Invoke();
        }

        public void ModifySlide(string label, Action<SlideModel> act)
        {
            if (ReadOnly || Slide == null) return;
            EndTextEdit(true);
            Undo.Push(Pres, SlideIndex, label);
            act(Slide);
            Rebuild();
            Changed?.Invoke(label);
        }

        public void DeleteSelection()
        {
            if (ReadOnly || Selection.Count == 0) return;
            Undo.Push(Pres, SlideIndex, "Удаление");
            foreach (var s in Selection) Slide.Shapes.Remove(s);
            Selection.Clear();
            Rebuild();
            Changed?.Invoke("Удаление"); SelectionChanged?.Invoke();
        }

        public void Nudge(double dx, double dy)
        {
            if (ReadOnly || Selection.Count == 0) return;
            Undo.Push(Pres, SlideIndex, "Сдвиг");
            foreach (var s in Selection) { s.X += Px.E(dx); s.Y += Px.E(dy); s.DirtyXfrm = true; }
            Rebuild();
            Changed?.Invoke("Сдвиг");
        }

        public void ReplaceAfterUndo(int idx)
        {
            Selection.Clear();
            SlideIndex = Math.Max(0, Math.Min(idx, Pres.Slides.Count - 1));
            Slide = Pres.Slides.Count > 0 ? Pres.Slides[SlideIndex] : null;
            Rebuild();
            SelectionChanged?.Invoke();
        }

        // ---------------- Редактирование текста ----------------
        public bool IsEditingText => _editing != null;
        public RichTextBox TextEditor => _rtb;

        public void BeginTextEdit(ShapeModel s)
        {
            if (ReadOnly || s == null || s.Kind != ShapeKind.Shape) return;
            EndTextEdit(true);
            Undo.Push(Pres, SlideIndex, "Правка текста");
            if (s.Text == null) s.Text = new TextBodyModel();
            _editing = s;
            var t = s.Text;
            double scale = t.FontScale > 0.05 ? t.FontScale : 1;
            var doc = new FlowDocument { PagePadding = new Thickness(0) };
            foreach (var p in t.Paras)
            {
                var para = new Paragraph { Margin = new Thickness(Px.D(t.Lvl(p.Level).MarLEmu), Px.PtToDip(t.EffSpaceBefore(p)), 0, Px.PtToDip(t.EffSpaceAfter(p))), Tag = p };
                var al = t.EffAlign(p);
                para.TextAlignment = al == "ctr" ? TextAlignment.Center : al == "r" ? TextAlignment.Right : al == "just" ? TextAlignment.Justify : TextAlignment.Left;
                var lv = t.Lvl(p.Level);
                para.FontSize = Px.PtToDip((p.EndSizePt ?? lv.SizePt) * scale); para.FontFamily = SlideRenderer.Font(lv.Font); para.Foreground = new SolidColorBrush(Px.C(lv.Color));
                foreach (var r in p.Runs)
                {
                    if (r.IsBreak) { para.Inlines.Add(new LineBreak()); continue; }
                    if (string.IsNullOrEmpty(r.Text)) continue;
                    var run = new Run(r.Text)
                    {
                        Tag = r,
                        FontFamily = SlideRenderer.Font(t.EffFont(p, r)),
                        FontSize = Px.PtToDip(t.EffSize(p, r) * scale),
                        FontWeight = t.EffBold(p, r) ? FontWeights.Bold : FontWeights.Normal,
                        FontStyle = t.EffItalic(p, r) ? FontStyles.Italic : FontStyles.Normal,
                        Foreground = new SolidColorBrush(Px.C(t.EffColor(p, r)))
                    };
                    var deco = new TextDecorationCollection();
                    if (t.EffUnderline(p, r)) deco.Add(TextDecorations.Underline[0]);
                    if (t.EffStrike(p, r)) deco.Add(TextDecorations.Strikethrough[0]);
                    if (deco.Count > 0) run.TextDecorations = deco;
                    para.Inlines.Add(run);
                }
                doc.Blocks.Add(para);
            }
            if (doc.Blocks.Count == 0) doc.Blocks.Add(new Paragraph { Tag = new ParaModel() });
            _rtb = new RichTextBox
            {
                Document = doc, Background = Brushes.Transparent, BorderThickness = new Thickness(0), AcceptsReturn = true, AcceptsTab = true,
                Padding = new Thickness(Px.D(t.LIns), Px.D(t.TIns), Px.D(t.RIns), Px.D(t.BIns)), Width = Math.Max(40, Px.D(s.W)), MinHeight = Math.Max(20, Px.D(s.H)),
                VerticalScrollBarVisibility = ScrollBarVisibility.Disabled, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, AllowDrop = false,
                CaretBrush = ThemeManager.Brush("B.Accent2Solid"), SelectionBrush = ThemeManager.Brush("B.AccentSolid")
            };
            SpellCheck.SetIsEnabled(_rtb, false);
            DataObject.AddPastingHandler(_rtb, OnRtbPaste);
            _rtb.PreviewKeyDown += (o, e) => { if (e.Key == Key.Escape) { EndTextEdit(true); Focus(); e.Handled = true; } };
            Canvas.SetLeft(_rtb, Px.D(s.X)); Canvas.SetTop(_rtb, Px.D(s.Y));
            if (Math.Abs(s.Rot) > 0.01) _rtb.RenderTransform = new RotateTransform(s.Rot, Px.D(s.W) / 2, Px.D(s.H) / 2);
            if (t.Anchor == "ctr" || t.Anchor == "b") { _rtb.Loaded += (o, e) => AlignEditor(s); _rtb.TextChanged += (o, e) => AlignEditor(s); }
            _editLayer.Children.Add(_rtb);
            RefreshShape(s);
            _rtb.Focus();
            _rtb.CaretPosition = doc.ContentEnd;
            SelectionChanged?.Invoke();
        }

        void AlignEditor(ShapeModel s)
        {
            if (_rtb == null) return;
            _rtb.UpdateLayout();
            double h = Px.D(s.H);
            double contentH = _rtb.Document.ContentEnd.GetCharacterRect(LogicalDirection.Backward).Bottom - _rtb.Document.ContentStart.GetCharacterRect(LogicalDirection.Forward).Top + _rtb.Padding.Top + _rtb.Padding.Bottom;
            if (double.IsNaN(contentH) || double.IsInfinity(contentH)) return;
            double off = s.Text.Anchor == "ctr" ? (h - contentH) / 2 : h - contentH;
            Canvas.SetTop(_rtb, Px.D(s.Y) + Math.Max(0, off));
        }

        static void OnRtbPaste(object sender, DataObjectPastingEventArgs e)
        {
            // вставляется только простой текст: никаких объектов, изображений и разметки
            var text = e.DataObject.GetDataPresent(DataFormats.UnicodeText) ? e.DataObject.GetData(DataFormats.UnicodeText) as string : null;
            if (text == null) { e.CancelCommand(); return; }
            var d = new DataObject(); d.SetData(DataFormats.UnicodeText, text);
            e.DataObject = d;
        }

        public void EndTextEdit(bool commit)
        {
            if (_editing == null || _rtb == null) { _editing = null; return; }
            var s = _editing; var rtb = _rtb;
            _editing = null; _rtb = null;
            _editLayer.Children.Clear();
            if (commit)
            {
                var t = s.Text;
                double scale = t.FontScale > 0.05 ? t.FontScale : 1;
                var paras = new List<ParaModel>();
                foreach (var block in rtb.Document.Blocks)
                {
                    if (!(block is Paragraph para)) continue;
                    var orig = para.Tag as ParaModel;
                    var pm = orig != null ? orig.Clone() : new ParaModel { Level = paras.Count > 0 ? paras[paras.Count - 1].Level : 0 };
                    pm.Runs = new List<RunModel>();
                    var lv = t.Lvl(pm.Level);
                    string al = para.TextAlignment == TextAlignment.Center ? "ctr" : para.TextAlignment == TextAlignment.Right ? "r" : para.TextAlignment == TextAlignment.Justify ? "just" : "l";
                    pm.Align = al == lv.Align && orig?.Align == null ? null : al;
                    if (orig == null && paras.Count > 0) { var prev = paras[paras.Count - 1]; pm.Bullet = prev.Bullet; pm.Level = prev.Level; }
                    Flatten(para.Inlines, pm, t, lv, scale);
                    pm.EndSizePt = Math.Round(para.FontSize * 72 / 96 / scale * 2) / 2;
                    if (Math.Abs(pm.EndSizePt.Value - lv.SizePt) < 0.3) pm.EndSizePt = null;
                    paras.Add(pm);
                }
                if (paras.Count == 0) paras.Add(new ParaModel());
                t.Paras = paras;
                s.DirtyText = true;
                Changed?.Invoke("Правка текста");
            }
            if (Slide != null && Slide.Shapes.Contains(s)) RefreshShape(s);
            SelectionChanged?.Invoke();
        }

        static void Flatten(InlineCollection inlines, ParaModel pm, TextBodyModel t, LevelStyle lv, double scale)
        {
            foreach (var inl in inlines)
            {
                if (inl is Run r)
                {
                    if (string.IsNullOrEmpty(r.Text)) continue;
                    var rm = (r.Tag as RunModel)?.Clone() ?? new RunModel();
                    rm.IsBreak = false;
                    rm.Text = r.Text.Replace("​", "");
                    double size = Math.Round(r.FontSize * 72 / 96 / scale * 2) / 2;
                    rm.SizePt = Math.Abs(size - lv.SizePt) < 0.3 ? (double?)null : size;
                    bool b = r.FontWeight.ToOpenTypeWeight() >= 600; rm.Bold = b == lv.Bold ? (bool?)null : b;
                    bool i = r.FontStyle == FontStyles.Italic || r.FontStyle == FontStyles.Oblique; rm.Italic = i == lv.Italic ? (bool?)null : i;
                    var decos = r.TextDecorations ?? new TextDecorationCollection();
                    bool u = decos.Any(d => d.Location == TextDecorationLocation.Underline); rm.Underline = u == lv.Underline ? (bool?)null : u;
                    bool st = decos.Any(d => d.Location == TextDecorationLocation.Strikethrough); rm.Strike = st == lv.Strike ? (bool?)null : st;
                    if (r.Foreground is SolidColorBrush sb) { var c = Px.R(sb.Color); rm.Color = c.Equals(lv.Color) ? (Rgba?)null : c; }
                    var fam = r.FontFamily?.Source?.Split(',')[0].Trim();
                    rm.Font = string.IsNullOrEmpty(fam) || string.Equals(fam, lv.Font, StringComparison.OrdinalIgnoreCase) ? null : fam;
                    var last = pm.Runs.LastOrDefault();
                    if (last != null && !last.IsBreak && SameProps(last, rm)) last.Text += rm.Text; else pm.Runs.Add(rm);
                }
                else if (inl is LineBreak) pm.Runs.Add(new RunModel { IsBreak = true });
                else if (inl is Span sp) Flatten(sp.Inlines, pm, t, lv, scale);
            }
        }

        static bool SameProps(RunModel a, RunModel b) => a.SizePt == b.SizePt && a.Bold == b.Bold && a.Italic == b.Italic && a.Underline == b.Underline && a.Strike == b.Strike && Nullable.Equals(a.Color, b.Color) && a.Font == b.Font && a.Hyperlink == b.Hyperlink && a.OrigRPr == b.OrigRPr;

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.Handled || _editing != null) return;
            double step = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) ? 10 : 1;
            switch (e.Key)
            {
                case Key.Left: Nudge(-step, 0); e.Handled = true; break;
                case Key.Right: Nudge(step, 0); e.Handled = true; break;
                case Key.Up: Nudge(0, -step); e.Handled = true; break;
                case Key.Down: Nudge(0, step); e.Handled = true; break;
                case Key.Delete: DeleteSelection(); e.Handled = true; break;
                case Key.Escape: if (Tool != null) { SetTool(null); ToolFinished?.Invoke(); } else ClearSelection(); e.Handled = true; break;
                case Key.F2:
                case Key.Enter:
                    if (Selection.Count == 1 && Selection[0].Kind == ShapeKind.Shape) { BeginTextEdit(Selection[0]); e.Handled = true; }
                    break;
            }
        }
    }
}
