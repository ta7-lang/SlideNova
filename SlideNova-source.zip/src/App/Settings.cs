// Настройки приложения: маленький JSON-файл в %AppData%\SlideNova (без кэша).
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace SlideNova
{
    public sealed class CustomThemeData
    {
        public string Name { get; set; } = "Моя тема";
        public bool Dark { get; set; } = true;
        public string Bg1 { get; set; } = "#14122B";
        public string Bg2 { get; set; } = "#2A1F52";
        public string Panel { get; set; } = "#1E1B3A";
        public string Panel2 { get; set; } = "#2B2752";
        public string Text { get; set; } = "#F2F0FF";
        public string Accent1 { get; set; } = "#00E5FF";
        public string Accent2 { get; set; } = "#FF3DCB";
        public string Canvas { get; set; } = "#0E0C20";
        public double Radius { get; set; } = 10;
    }

    public sealed class AppSettings
    {
        public string ThemeName { get; set; } = "Неоновая ночь";
        public CustomThemeData Custom { get; set; } = new CustomThemeData();
        public double UiScale { get; set; } = 1.0;
        public bool GlassPanels { get; set; } = true;
        public bool StrictMode { get; set; } = true;
        public bool ProtectedView { get; set; } = true;
        public bool ConfirmLinks { get; set; } = true;
        public bool KeepRecent { get; set; } = true;
        public List<string> Recent { get; set; } = new List<string>();
        public bool ShowNotes { get; set; } = true;
        public bool ShowInspector { get; set; } = true;
        public bool ShowThumbs { get; set; } = true;
        public bool ShowGrid { get; set; } = false;
        public bool Snap { get; set; } = true;
        public bool ShowTransitions { get; set; } = true;
        public bool SaveThumbnail { get; set; } = true;
        public int MaxFileMb { get; set; } = 1024;
        public string UserName { get; set; } = "";
        public string PrintMode { get; set; } = "full";
        public int PrintPerPage { get; set; } = 6;

        static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SlideNova");
        static string FilePath => Path.Combine(Dir, "settings.json");
        public static AppSettings Current { get; private set; } = new AppSettings();

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath) && new FileInfo(FilePath).Length < 256 * 1024)
                {
                    var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath));
                    if (s != null) { s.Recent = (s.Recent ?? new List<string>()).Where(r => !string.IsNullOrWhiteSpace(r)).Take(12).ToList(); s.Custom ??= new CustomThemeData(); Current = s; }
                }
            }
            catch { Current = new AppSettings(); }
            if (string.IsNullOrWhiteSpace(Current.UserName)) Current.UserName = Environment.UserName;
            return Current;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                var tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
                File.Move(tmp, FilePath, true);
            }
            catch { }
        }

        public void AddRecent(string path)
        {
            if (!KeepRecent) return;
            Recent.RemoveAll(r => string.Equals(r, path, StringComparison.OrdinalIgnoreCase));
            Recent.Insert(0, path);
            while (Recent.Count > 10) Recent.RemoveAt(Recent.Count - 1);
            Save();
        }

        /// <summary>Полная очистка следов работы программы.</summary>
        public static void WipeAll()
        {
            try { if (Directory.Exists(Dir)) Directory.Delete(Dir, true); } catch { }
            Current.Recent.Clear();
        }
    }
}
