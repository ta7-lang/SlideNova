// Упрощённая отрисовка слайда средствами GDI+ для эскизов Проводника.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using SlideNova.Core;

namespace SlideNova.Thumbnails
{
    static class GdiRenderer
    {
        sealed class Ctx { public PresentationModel P; public double K; public Dictionary<string, Image> Images = new Dictionary<string, Image>(); }

        public static Bitmap Render(PresentationModel p, SlideModel s, int maxSize)
        {
            double k = maxSize / Math.Max(p.SlideW, p.SlideH);
            int w = Math.Max(1, (int)Math.Round(p.SlideW * k)), h = Math.Max(1, (int)Math.Round(p.SlideH * k));
            var bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            var c = new Ctx { P = p, K = k };
            try
            {
                using (var g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                    g.Clear(Color.White);
                    var full = new RectangleF(0, 0, w, h);
                    using (var path = new GraphicsPath()) { path.AddRectangle(full); Fill(g, c, s.Background ?? FillDef.Solid(Rgba.White), path, full, 1); }
                    foreach (var m in s.MasterShapes) Draw(g, c, m, 0);
                    foreach (var sh in s.Shapes) Draw(g, c, sh, 0);
                }
            }
            finally { foreach (var i in c.Images.Values) i?.Dispose(); }
            return bmp;
        }

        static Color C(Rgba r) => Color.FromArgb(r.A, r.R, r.G, r.B);
        static Color Shade(Color c, double f)
        {
            if (Math.Abs(f - 1) < 0.001) return c;
            if (f < 1) return Color.FromArgb(c.A, (int)(c.R * f), (int)(c.G * f), (int)(c.B * f));
            double t = Math.Min(1, f - 1);
            return Color.FromArgb(c.A, (int)(c.R + (255 - c.R) * t), (int)(c.G + (255 - c.G) * t), (int)(c.B + (255 - c.B) * t));
        }

        static Image Img(Ctx c, string key)
        {
            if (key == null) return null;
            if (c.Images.TryGetValue(key, out var i)) return i;
            i = null;
            try
            {
                if (c.P.Media.TryGetValue(key, out var m) && m.Data != null && m.Data.Length < 64 * 1024 * 1024)
                {
                    var data = m.Data;
                    var img = Image.FromStream(new MemoryStream(data, false), false, true);
                    if ((long)img.Width * img.Height > 100_000_000L) { img.Dispose(); img = null; }
                    i = img;
                }
            }
            catch { i = null; }
            c.Images[key] = i;
            return i;
        }

        static void Fill(Graphics g, Ctx c, FillDef f, GraphicsPath path, RectangleF r, double shade)
        {
            if (f == null || r.Width <= 0 || r.Height <= 0) return;
            switch (f.Kind)
            {
                case FillKind.Solid:
                    using (var b = new SolidBrush(Shade(C(f.Color), shade))) g.FillPath(b, path);
                    break;
                case FillKind.Gradient:
                    if (f.Stops.Count < 2) break;
                    if (f.Radial)
                    {
                        using (var b = new SolidBrush(Shade(C(f.Stops[f.Stops.Count / 2].Color), shade))) g.FillPath(b, path);
                        break;
                    }
                    using (var b = new LinearGradientBrush(new RectangleF(r.X - 1, r.Y - 1, r.Width + 2, r.Height + 2), Color.Black, Color.White, (float)f.Angle))
                    {
                        var stops = f.Stops.OrderBy(s => s.Pos).ToList();
                        var cols = new List<Color>(); var pos = new List<float>();
                        if (stops[0].Pos > 0) { cols.Add(Shade(C(stops[0].Color), shade)); pos.Add(0); }
                        foreach (var s in stops) { cols.Add(Shade(C(s.Color), shade)); pos.Add((float)Units.Clamp(s.Pos, 0, 1)); }
                        if (pos[pos.Count - 1] < 1) { cols.Add(cols[cols.Count - 1]); pos.Add(1); }
                        for (int i = 1; i < pos.Count; i++) if (pos[i] < pos[i - 1]) pos[i] = pos[i - 1];
                        b.InterpolationColors = new ColorBlend { Colors = cols.ToArray(), Positions = pos.ToArray() };
                        g.FillPath(b, path);
                    }
                    break;
                case FillKind.Image:
                    {
                        var img = Img(c, f.ImageKey);
                        if (img == null) break;
                        var st = g.Save();
                        g.SetClip(path, CombineMode.Intersect);
                        g.DrawImage(img, r);
                        g.Restore(st);
                        break;
                    }
            }
        }

        static GraphicsPath BuildPath(List<GeoPath> paths, double sx, double sy, float ox, float oy)
        {
            var gp = new GraphicsPath(FillMode.Winding);
            foreach (var p in paths)
            {
                if (p.EvenOdd) gp.FillMode = FillMode.Alternate;
                PointF cur = PointF.Empty; bool started = false; PointF start = PointF.Empty;
                foreach (var cmd in p.Cmds)
                {
                    switch (cmd.Type)
                    {
                        case 'M': gp.StartFigure(); cur = new PointF(ox + (float)(cmd.P[0] * sx), oy + (float)(cmd.P[1] * sy)); start = cur; started = true; break;
                        case 'L': { var n = new PointF(ox + (float)(cmd.P[0] * sx), oy + (float)(cmd.P[1] * sy)); if (started) gp.AddLine(cur, n); cur = n; started = true; break; }
                        case 'C':
                            {
                                var a = new PointF(ox + (float)(cmd.P[0] * sx), oy + (float)(cmd.P[1] * sy));
                                var b = new PointF(ox + (float)(cmd.P[2] * sx), oy + (float)(cmd.P[3] * sy));
                                var e = new PointF(ox + (float)(cmd.P[4] * sx), oy + (float)(cmd.P[5] * sy));
                                gp.AddBezier(cur, a, b, e); cur = e; started = true; break;
                            }
                        case 'Z': gp.CloseFigure(); cur = start; break;
                    }
                }
            }
            return gp;
        }

        static void Draw(Graphics g, Ctx c, ShapeModel s, int depth)
        {
            if (depth > 32) return;
            try
            {
                float x = (float)(s.X * c.K), y = (float)(s.Y * c.K), w = (float)(s.W * c.K), h = (float)(s.H * c.K);
                var state = g.Save();
                if (Math.Abs(s.Rot) > 0.01)
                {
                    g.TranslateTransform(x + w / 2, y + h / 2);
                    g.RotateTransform((float)s.Rot);
                    g.TranslateTransform(-(x + w / 2), -(y + h / 2));
                }
                var rect = new RectangleF(x, y, w, h);
                switch (s.Kind)
                {
                    case ShapeKind.Group:
                    case ShapeKind.Graphic when s.Children != null && s.Children.Count > 0:
                        {
                            double chX = s.ChX, chY = s.ChY, chW = s.ChW, chH = s.ChH;
                            if (s.Kind == ShapeKind.Graphic) { double mx = s.Children.Min(k => k.X), my = s.Children.Min(k => k.Y); bool abs = mx >= s.X - 2 && my >= s.Y - 2 && s.X > 0; chX = abs ? s.X : 0; chY = abs ? s.Y : 0; chW = s.W; chH = s.H; }
                            double sx = chW > 0 ? s.W / chW : 1, sy = chH > 0 ? s.H / chH : 1;
                            foreach (var k in s.Children ?? new List<ShapeModel>())
                            {
                                var t = k.Clone();
                                t.X = s.X + (k.X - chX) * sx; t.Y = s.Y + (k.Y - chY) * sy; t.W = k.W * sx; t.H = k.H * sy;
                                Draw(g, c, t, depth + 1);
                            }
                            break;
                        }
                    case ShapeKind.Picture:
                    case ShapeKind.Graphic:
                        {
                            var img = Img(c, s.ImageKey);
                            if (img != null)
                            {
                                float sxp = (float)(img.Width * Math.Max(0, s.CropL)), syp = (float)(img.Height * Math.Max(0, s.CropT));
                                float swp = (float)(img.Width * Math.Max(0.01, 1 - Math.Max(0, s.CropL) - Math.Max(0, s.CropR))), shp = (float)(img.Height * Math.Max(0.01, 1 - Math.Max(0, s.CropT) - Math.Max(0, s.CropB)));
                                if (s.Geometry == "ellipse" || s.Geometry == "roundRect")
                                {
                                    using (var gp = BuildPath(PresetGeometry.Build(s.Geometry, s.W, s.H, s.Adj), c.K, c.K, x, y)) g.SetClip(gp, CombineMode.Intersect);
                                }
                                g.DrawImage(img, rect, new RectangleF(sxp, syp, swp, shp), GraphicsUnit.Pixel);
                            }
                            else using (var b = new SolidBrush(Color.FromArgb(40, 120, 120, 140))) g.FillRectangle(b, rect);
                            break;
                        }
                    case ShapeKind.Table:
                        DrawTable(g, c, s, rect);
                        break;
                    default:
                        DrawShape(g, c, s, rect);
                        break;
                }
                g.Restore(state);
            }
            catch { }
        }

        static void DrawShape(Graphics g, Ctx c, ShapeModel s, RectangleF r)
        {
            List<GeoPath> paths; double sx, sy;
            if (s.Geometry == "custom" && s.CustomPaths != null && s.CustomPaths.Count > 0) { paths = s.CustomPaths; sx = s.W / Math.Max(1, s.CustW) * c.K; sy = s.H / Math.Max(1, s.CustH) * c.K; }
            else { paths = PresetGeometry.Build(s.Geometry, s.W, s.H, s.Adj); sx = sy = c.K; }
            var st = g.Save();
            if (s.FlipH || s.FlipV)
            {
                g.TranslateTransform(r.X + r.Width / 2, r.Y + r.Height / 2);
                g.ScaleTransform(s.FlipH ? -1 : 1, s.FlipV ? -1 : 1);
                g.TranslateTransform(-(r.X + r.Width / 2), -(r.Y + r.Height / 2));
            }
            foreach (var p in paths)
            {
                using (var gp = BuildPath(new List<GeoPath> { p }, sx, sy, r.X, r.Y))
                {
                    if (p.Filled && s.Fill != null && s.Fill.Kind != FillKind.None) Fill(g, c, s.Fill, gp, r, p.ShadeFactor);
                    if (p.Stroked && s.Line != null && s.Line.Visible)
                        using (var pen = new Pen(C(s.Line.Color), (float)Math.Max(0.6, s.Line.WidthEmu * c.K)))
                        {
                            if (s.Line.Dash != "solid" && s.Line.Dash != null) pen.DashStyle = s.Line.Dash.Contains("Dot") || s.Line.Dash.EndsWith("ot") ? DashStyle.Dot : DashStyle.Dash;
                            if (s.Line.TailEnd != null && s.Line.TailEnd != "none") pen.CustomEndCap = new AdjustableArrowCap(3, 3);
                            if (s.Line.HeadEnd != null && s.Line.HeadEnd != "none") pen.CustomStartCap = new AdjustableArrowCap(3, 3);
                            g.DrawPath(pen, gp);
                        }
                }
            }
            g.Restore(st);
            if (s.Text != null && !s.Text.IsEmpty && s.Kind != ShapeKind.Connector) DrawText(g, c, s.Text, r);
        }

        static void DrawTable(Graphics g, Ctx c, ShapeModel s, RectangleF r)
        {
            var t = s.Table; if (t == null) return;
            var accent = C(t.StyleAccent);
            float y = r.Y;
            for (int ri = 0; ri < t.Rows.Count; ri++)
            {
                float rh = (float)((ri < t.RowHeights.Count ? t.RowHeights[ri] : 370840) * c.K);
                float x = r.X;
                for (int ci = 0; ci < t.ColWidths.Count && ci < t.Rows[ri].Count; ci++)
                {
                    float cw = (float)(t.ColWidths[ci] * c.K);
                    var cell = t.Rows[ri][ci];
                    var cr = new RectangleF(x, y, cw, rh);
                    bool header = t.FirstRow && ri == 0;
                    Color? bg = cell.Fill != null && cell.Fill.Kind == FillKind.Solid ? C(cell.Fill.Color) : header ? accent : t.BandRow ? Color.FromArgb(255, (accent.R + 255 * 2) / 3, (accent.G + 255 * 2) / 3, (accent.B + 255 * 2) / 3) : (Color?)null;
                    if (bg.HasValue) using (var b = new SolidBrush(bg.Value)) g.FillRectangle(b, cr);
                    using (var pen = new Pen(t.FirstRow || t.BandRow ? Color.White : Color.Gray, 0.6f)) g.DrawRectangle(pen, cr.X, cr.Y, cr.Width, cr.Height);
                    if (!cell.Text.IsEmpty)
                    {
                        var txt = cell.Text;
                        if (header && cell.Fill == null) { txt = txt.Clone(); foreach (var l in txt.Levels) { l.Color = Rgba.White; l.Bold = true; } }
                        DrawText(g, c, txt, cr);
                    }
                    x += cw;
                }
                y += rh;
            }
        }

        static FontFamily Family(string name)
        {
            try { return new FontFamily(string.IsNullOrEmpty(name) ? "Calibri" : name); }
            catch { try { return new FontFamily("Segoe UI"); } catch { return FontFamily.GenericSansSerif; } }
        }

        static void DrawText(Graphics g, Ctx c, TextBodyModel t, RectangleF r)
        {
            var inner = new RectangleF(r.X + (float)(t.LIns * c.K), r.Y + (float)(t.TIns * c.K), Math.Max(1, r.Width - (float)((t.LIns + t.RIns) * c.K)), Math.Max(1, r.Height - (float)((t.TIns + t.BIns) * c.K)));
            double scale = t.FontScale > 0.05 ? t.FontScale : 1;
            var items = new List<Tuple<string, Font, Color, StringAlignment, SizeF, float>>();
            float total = 0;
            int num = 0;
            foreach (var p in t.Paras)
            {
                var first = p.Runs.FirstOrDefault(x => !x.IsBreak && !string.IsNullOrEmpty(x.Text));
                string text = string.Concat(p.Runs.Select(x => x.IsBreak ? "\n" : x.Text));
                double sizePt = first != null ? t.EffSize(p, first) : (p.EndSizePt ?? t.Lvl(p.Level).SizePt);
                float px = (float)Math.Max(1, sizePt * Units.EmuPerPt * c.K * scale);
                var style = FontStyle.Regular;
                if (first != null && t.EffBold(p, first)) style |= FontStyle.Bold;
                if (first != null && t.EffItalic(p, first)) style |= FontStyle.Italic;
                if (first != null && t.EffUnderline(p, first)) style |= FontStyle.Underline;
                var fam = Family(first != null ? t.EffFont(p, first) : t.Lvl(p.Level).Font);
                Font font;
                try { font = new Font(fam, px, fam.IsStyleAvailable(style) ? style : FontStyle.Regular, GraphicsUnit.Pixel); }
                catch { font = new Font(FontFamily.GenericSansSerif, px, GraphicsUnit.Pixel); }
                var bullet = !string.IsNullOrEmpty(text) ? t.EffBullet(p) : null;
                if (bullet != null) { num++; text = (bullet[0] == '\u0001' ? Dml.AutoNumber(bullet.Substring(1), num) : bullet) + " " + text; }
                float indent = (float)(t.Lvl(p.Level).MarLEmu * c.K);
                var al = t.EffAlign(p);
                var sa = al == "ctr" ? StringAlignment.Center : al == "r" ? StringAlignment.Far : StringAlignment.Near;
                var color = first != null ? C(t.EffColor(p, first)) : C(t.Lvl(p.Level).Color);
                using (var sf = new StringFormat { Alignment = sa })
                {
                    if (!t.Wrap) sf.FormatFlags |= StringFormatFlags.NoWrap;
                    var size = string.IsNullOrEmpty(text) ? new SizeF(0, font.GetHeight(g)) : g.MeasureString(text, font, (int)Math.Max(1, inner.Width - indent), sf);
                    float before = (float)(t.EffSpaceBefore(p) * Units.EmuPerPt * c.K);
                    items.Add(Tuple.Create(text, font, color, sa, size, indent));
                    total += size.Height * (float)(t.EffLineSpacing(p) / 100.0) + before;
                }
            }
            float y = t.Anchor == "ctr" ? inner.Y + (inner.Height - total) / 2 : t.Anchor == "b" ? inner.Bottom - total : inner.Y;
            int idx = 0;
            foreach (var it in items)
            {
                var p = t.Paras[idx++];
                y += (float)(t.EffSpaceBefore(p) * Units.EmuPerPt * c.K);
                if (!string.IsNullOrEmpty(it.Item1))
                    using (var b = new SolidBrush(it.Item3))
                    using (var sf = new StringFormat { Alignment = it.Item4 })
                    {
                        if (!t.Wrap) sf.FormatFlags |= StringFormatFlags.NoWrap;
                        g.DrawString(it.Item1, it.Item2, b, new RectangleF(inner.X + it.Item6, y, Math.Max(1, inner.Width - it.Item6), it.Item5.Height + 4), sf);
                    }
                y += it.Item5.Height * (float)(t.EffLineSpacing(p) / 100.0);
                it.Item2.Dispose();
            }
        }
    }
}
