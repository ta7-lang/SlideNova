// Обработчик эскизов Проводника для презентаций. Работает в изолированном процессе-суррогате Windows,
// читает файл только из переданного потока (в память, с лимитом), ничего не кэширует и не обращается к сети.
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using SlideNova.Core;

namespace SlideNova.Thumbnails
{
    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("e357fccd-a995-4576-b01f-234630154e96")]
    public interface IThumbnailProvider
    {
        void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha);
    }

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("b824b49d-22ac-4161-ac8a-9916e8fa3f7f")]
    public interface IInitializeWithStream
    {
        void Initialize(IStream pstream, uint grfMode);
    }

    [ComVisible(true)]
    [Guid("6B3E1C2A-4F7D-4E21-9C5B-8A1D2E3F4A5B")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("SlideNova.ThumbnailProvider")]
    public sealed class ThumbnailProvider : IInitializeWithStream, IThumbnailProvider
    {
        const long MaxInput = 256L * 1024 * 1024;
        byte[] _data;

        public void Initialize(IStream pstream, uint grfMode)
        {
            if (_data != null) throw new COMException("Already initialized", unchecked((int)0x8007139F));
            try
            {
                System.Runtime.InteropServices.ComTypes.STATSTG st;
                pstream.Stat(out st, 1);
                if (st.cbSize > MaxInput) throw new COMException("Too large", unchecked((int)0x800700DF));
                var ms = new MemoryStream(st.cbSize > 0 ? (int)st.cbSize : 0);
                var buf = new byte[1 << 16];
                IntPtr pRead = Marshal.AllocCoTaskMem(4);
                try
                {
                    while (true)
                    {
                        pstream.Read(buf, buf.Length, pRead);
                        int n = Marshal.ReadInt32(pRead);
                        if (n <= 0) break;
                        ms.Write(buf, 0, n);
                        if (ms.Length > MaxInput) throw new COMException("Too large", unchecked((int)0x800700DF));
                    }
                }
                finally { Marshal.FreeCoTaskMem(pRead); }
                _data = ms.ToArray();
            }
            finally
            {
                try { Marshal.ReleaseComObject(pstream); } catch { }
            }
        }

        public void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha)
        {
            phbmp = IntPtr.Zero; pdwAlpha = 0;
            if (_data == null) throw new COMException("Not initialized", unchecked((int)0x8000FFFF));
            int size = (int)Math.Max(16, Math.Min(cx, 2048));
            Bitmap bmp = null;
            try
            {
                Limits.MaxFileBytes = MaxInput;
                var fmt = FormatDetect.Detect(_data);
                Bitmap embedded = fmt == FileFormat.Ooxml ? EmbeddedThumb(_data) : null;
                if (embedded != null && embedded.Width >= size * 0.9) bmp = Fit(embedded, size);
                if (bmp == null)
                {
                    try
                    {
                        var pres = PresentationLoader.Load(_data, 1);
                        if (pres.Slides.Count > 0) bmp = GdiRenderer.Render(pres, pres.Slides[0], size);
                    }
                    catch { bmp = null; }
                }
                if (bmp == null && embedded != null) bmp = Fit(embedded, size);
                embedded?.Dispose();
                if (bmp == null) throw new COMException("No thumbnail", unchecked((int)0x80004005));
                phbmp = bmp.GetHbitmap(Color.White);
                pdwAlpha = 1; // WTSAT_RGB
            }
            finally
            {
                bmp?.Dispose();
                _data = null;
            }
        }

        static Bitmap EmbeddedThumb(byte[] data)
        {
            try
            {
                using (var ms = new MemoryStream(data, false))
                using (var zip = new ZipArchive(ms, ZipArchiveMode.Read))
                {
                    var e = zip.Entries.FirstOrDefault(x => x.FullName.Equals("docProps/thumbnail.jpeg", StringComparison.OrdinalIgnoreCase) || x.FullName.Equals("docProps/thumbnail.jpg", StringComparison.OrdinalIgnoreCase) || x.FullName.Equals("docProps/thumbnail.png", StringComparison.OrdinalIgnoreCase));
                    if (e == null || e.Length <= 0 || e.Length > 8 * 1024 * 1024) return null;
                    var buf = new MemoryStream();
                    using (var s = e.Open())
                    {
                        var b = new byte[65536]; int n; long total = 0;
                        while ((n = s.Read(b, 0, b.Length)) > 0) { total += n; if (total > 8 * 1024 * 1024) return null; buf.Write(b, 0, n); }
                    }
                    buf.Position = 0;
                    using (var img = Image.FromStream(buf, false, true))
                    {
                        if ((long)img.Width * img.Height > 40_000_000L) return null;
                        return new Bitmap(img);
                    }
                }
            }
            catch { return null; }
        }

        static Bitmap Fit(Bitmap src, int size)
        {
            double k = Math.Min((double)size / src.Width, (double)size / src.Height);
            int w = Math.Max(1, (int)Math.Round(src.Width * k)), h = Math.Max(1, (int)Math.Round(src.Height * k));
            var b = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(b))
            {
                g.Clear(Color.White);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                g.DrawImage(src, 0, 0, w, h);
            }
            return b;
        }
    }
}
