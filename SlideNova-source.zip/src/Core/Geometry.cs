// Построение контуров стандартных фигур (preset geometry) в локальных координатах фигуры.
using System;
using System.Collections.Generic;

namespace SlideNova.Core
{
    public static class PresetGeometry
    {
        public sealed class PresetInfo
        {
            public string Id, Title, Hint;
            public PresetInfo(string id, string title, string hint) { Id = id; Title = title; Hint = hint; }
        }

        /// <summary>Фигуры, доступные в галерее «Вставка → Фигуры».</summary>
        public static readonly PresetInfo[] Gallery =
        {
            new PresetInfo("rect", "Прямоугольник", "Базовый прямоугольник — для плашек, рамок и фона блоков."),
            new PresetInfo("roundRect", "Скруглённый прямоугольник", "Прямоугольник с мягкими углами — для кнопок и карточек."),
            new PresetInfo("ellipse", "Овал", "Круг или эллипс (удерживайте Shift для ровного круга)."),
            new PresetInfo("triangle", "Треугольник", "Равнобедренный треугольник."),
            new PresetInfo("rtTriangle", "Прямоугольный треугольник", "Треугольник с прямым углом."),
            new PresetInfo("diamond", "Ромб", "Ромб — также символ «решение» в блок-схемах."),
            new PresetInfo("parallelogram", "Параллелограмм", "Наклонный четырёхугольник — «ввод/вывод» в блок-схемах."),
            new PresetInfo("trapezoid", "Трапеция", "Четырёхугольник с параллельными основаниями."),
            new PresetInfo("pentagon", "Пятиугольник", "Правильный пятиугольник."),
            new PresetInfo("hexagon", "Шестиугольник", "Шестиугольник — популярен для сот и схем."),
            new PresetInfo("octagon", "Восьмиугольник", "Восьмиугольник (знак «стоп»)."),
            new PresetInfo("star5", "Звезда (5)", "Пятиконечная звезда — для выделения и наград."),
            new PresetInfo("star4", "Звезда (4)", "Четырёхконечная звезда — «искра»."),
            new PresetInfo("star8", "Звезда (8)", "Восьмиконечная звезда — «бейдж»."),
            new PresetInfo("heart", "Сердце", "Сердце."),
            new PresetInfo("plus", "Плюс", "Крест / знак плюс."),
            new PresetInfo("donut", "Кольцо", "Кольцо с отверстием."),
            new PresetInfo("can", "Цилиндр", "Цилиндр — «база данных» на схемах."),
            new PresetInfo("cube", "Куб", "Объёмный куб."),
            new PresetInfo("rightArrow", "Стрелка вправо", "Блочная стрелка вправо."),
            new PresetInfo("leftArrow", "Стрелка влево", "Блочная стрелка влево."),
            new PresetInfo("upArrow", "Стрелка вверх", "Блочная стрелка вверх."),
            new PresetInfo("downArrow", "Стрелка вниз", "Блочная стрелка вниз."),
            new PresetInfo("leftRightArrow", "Двусторонняя стрелка", "Стрелка в обе стороны."),
            new PresetInfo("chevron", "Шеврон", "Шеврон — для этапов процесса."),
            new PresetInfo("homePlate", "Пятиугольник-стрелка", "Указатель этапа (homePlate)."),
            new PresetInfo("snip1Rect", "Срезанный угол", "Прямоугольник со срезанным углом."),
            new PresetInfo("frame", "Рамка", "Рамка с прозрачной серединой."),
            new PresetInfo("wedgeRectCallout", "Выноска", "Прямоугольная выноска с хвостиком — для реплик и комментариев."),
            new PresetInfo("wedgeEllipseCallout", "Овальная выноска", "Овальная выноска «облачко речи»."),
            new PresetInfo("flowChartTerminator", "Знак завершения", "Блок «начало/конец» блок-схемы."),
            new PresetInfo("flowChartDocument", "Документ", "Блок «документ» с волнистым краем."),
            new PresetInfo("pie", "Сектор", "Сектор круга (как в круговой диаграмме)."),
            new PresetInfo("line", "Линия", "Прямая линия. Shift — строго по горизонтали/вертикали/45°."),
            new PresetInfo("arrowLine", "Линия-стрелка", "Линия со стрелкой на конце."),
        };

        public static double A(Dictionary<string, double> adj, string name, double def)
        {
            if (adj != null && adj.TryGetValue(name, out var v)) return v;
            return def;
        }

        public static bool IsLineLike(string prst) =>
            prst == "line" || prst == "straightConnector1" || prst == "bentConnector2" || prst == "bentConnector3" || prst == "bentConnector4" ||
            prst == "curvedConnector2" || prst == "curvedConnector3" || prst == "curvedConnector4" || prst == "arc" || prst == "arrowLine";

        public static List<GeoPath> Build(string prst, double w, double h, Dictionary<string, double> adj)
        {
            var res = new List<GeoPath>();
            double ss = Math.Min(w, h);
            double a1 = A(adj, "adj", double.NaN);
            switch (prst)
            {
                case "roundRect":
                case "flowChartAlternateProcess":
                    {
                        double r = ss * A(adj, "adj", 16667) / 100000.0;
                        res.Add(RoundRect(w, h, r, r, r, r)); break;
                    }
                case "round2SameRect":
                    { double r = ss * A(adj, "adj1", 16667) / 100000.0; res.Add(RoundRect(w, h, r, r, 0, 0)); break; }
                case "round1Rect":
                    { double r = ss * A(adj, "adj", 16667) / 100000.0; res.Add(RoundRect(w, h, 0, r, 0, 0)); break; }
                case "flowChartTerminator":
                    { double r = Math.Min(h / 2, w / 2); res.Add(RoundRect(w, h, r, r, r, r)); break; }
                case "ellipse":
                case "flowChartConnector":
                case "cloud":
                case "teardrop":
                case "noSmoking":
                case "flowChartOffpageConnector":
                case "smileyFace":
                case "sun":
                    res.Add(Ellipse(w / 2, h / 2, w / 2, h / 2)); break;
                case "triangle":
                case "flowChartExtract":
                    { double x = w * A(adj, "adj", 50000) / 100000.0; res.Add(Poly(x, 0, w, h, 0, h)); break; }
                case "flowChartMerge":
                    res.Add(Poly(0, 0, w, 0, w / 2, h)); break;
                case "rtTriangle":
                    res.Add(Poly(0, 0, w, h, 0, h)); break;
                case "diamond":
                case "flowChartDecision":
                    res.Add(Poly(w / 2, 0, w, h / 2, w / 2, h, 0, h / 2)); break;
                case "parallelogram":
                    { double x = ss * A(adj, "adj", 25000) / 100000.0; res.Add(Poly(x, 0, w, 0, w - x, h, 0, h)); break; }
                case "flowChartInputOutput":
                    { double x = w * 0.2; res.Add(Poly(x, 0, w, 0, w - x, h, 0, h)); break; }
                case "trapezoid":
                    { double x = ss * A(adj, "adj", 25000) / 100000.0; res.Add(Poly(x, 0, w - x, 0, w, h, 0, h)); break; }
                case "flowChartManualOperation":
                    { double x = w * 0.2; res.Add(Poly(0, 0, w, 0, w - x, h, x, h)); break; }
                case "flowChartManualInput":
                    res.Add(Poly(0, h * 0.2, w, 0, w, h, 0, h)); break;
                case "pentagon":
                    res.Add(Poly(w / 2, 0, w, h * 0.382, w * 0.809, h, w * 0.191, h, 0, h * 0.382)); break;
                case "hexagon":
                case "flowChartPreparation":
                    { double x = ss * A(adj, "adj", 25000) / 100000.0; if (prst == "flowChartPreparation") x = w * 0.2; res.Add(Poly(x, 0, w - x, 0, w, h / 2, w - x, h, x, h, 0, h / 2)); break; }
                case "heptagon": res.Add(Regular(w, h, 7)); break;
                case "decagon": res.Add(Regular(w, h, 10)); break;
                case "dodecagon": res.Add(Regular(w, h, 12)); break;
                case "octagon":
                    { double x = ss * A(adj, "adj", 29289) / 100000.0; res.Add(Poly(x, 0, w - x, 0, w, x, w, h - x, w - x, h, x, h, 0, h - x, 0, x)); break; }
                case "star4": res.Add(Star(w, h, 4, A(adj, "adj", 12500) / 50000.0)); break;
                case "star5": res.Add(Star(w, h, 5, A(adj, "adj", 19098) / 50000.0)); break;
                case "star6": res.Add(Star(w, h, 6, A(adj, "adj", 28868) / 50000.0)); break;
                case "star7": res.Add(Star(w, h, 7, A(adj, "adj", 34601) / 50000.0)); break;
                case "star8": res.Add(Star(w, h, 8, A(adj, "adj", 37500) / 50000.0)); break;
                case "star10": res.Add(Star(w, h, 10, A(adj, "adj", 42533) / 50000.0)); break;
                case "star12": res.Add(Star(w, h, 12, A(adj, "adj", 37500) / 50000.0)); break;
                case "star16": res.Add(Star(w, h, 16, A(adj, "adj", 37500) / 50000.0)); break;
                case "star24": res.Add(Star(w, h, 24, A(adj, "adj", 37500) / 50000.0)); break;
                case "star32": res.Add(Star(w, h, 32, A(adj, "adj", 37500) / 50000.0)); break;
                case "irregularSeal1":
                case "irregularSeal2": res.Add(Star(w, h, 12, 0.65)); break;
                case "rightArrow":
                case "notchedRightArrow":
                case "stripedRightArrow":
                    {
                        double t = h * A(adj, "adj1", 50000) / 200000.0, x1 = w - ss * A(adj, "adj2", 50000) / 100000.0;
                        res.Add(Poly(0, h / 2 - t, x1, h / 2 - t, x1, 0, w, h / 2, x1, h, x1, h / 2 + t, 0, h / 2 + t)); break;
                    }
                case "leftArrow":
                    {
                        double t = h * A(adj, "adj1", 50000) / 200000.0, x1 = ss * A(adj, "adj2", 50000) / 100000.0;
                        res.Add(Poly(w, h / 2 - t, x1, h / 2 - t, x1, 0, 0, h / 2, x1, h, x1, h / 2 + t, w, h / 2 + t)); break;
                    }
                case "upArrow":
                    {
                        double t = w * A(adj, "adj1", 50000) / 200000.0, y1 = ss * A(adj, "adj2", 50000) / 100000.0;
                        res.Add(Poly(w / 2 - t, h, w / 2 - t, y1, 0, y1, w / 2, 0, w, y1, w / 2 + t, y1, w / 2 + t, h)); break;
                    }
                case "downArrow":
                    {
                        double t = w * A(adj, "adj1", 50000) / 200000.0, y1 = h - ss * A(adj, "adj2", 50000) / 100000.0;
                        res.Add(Poly(w / 2 - t, 0, w / 2 - t, y1, 0, y1, w / 2, h, w, y1, w / 2 + t, y1, w / 2 + t, 0)); break;
                    }
                case "leftRightArrow":
                    {
                        double t = h * A(adj, "adj1", 50000) / 200000.0, x1 = ss * A(adj, "adj2", 50000) / 100000.0, x2 = w - x1;
                        res.Add(Poly(0, h / 2, x1, 0, x1, h / 2 - t, x2, h / 2 - t, x2, 0, w, h / 2, x2, h, x2, h / 2 + t, x1, h / 2 + t, x1, h)); break;
                    }
                case "upDownArrow":
                    {
                        double t = w * A(adj, "adj1", 50000) / 200000.0, y1 = ss * A(adj, "adj2", 50000) / 100000.0, y2 = h - y1;
                        res.Add(Poly(w / 2, 0, w, y1, w / 2 + t, y1, w / 2 + t, y2, w, y2, w / 2, h, 0, y2, w / 2 - t, y2, w / 2 - t, y1, 0, y1)); break;
                    }
                case "chevron":
                    { double x = ss * A(adj, "adj", 50000) / 100000.0; res.Add(Poly(0, 0, w - x, 0, w, h / 2, w - x, h, 0, h, x, h / 2)); break; }
                case "homePlate":
                    { double x = ss * A(adj, "adj", 50000) / 100000.0; res.Add(Poly(0, 0, w - x, 0, w, h / 2, w - x, h, 0, h)); break; }
                case "plus":
                case "mathPlus":
                    { double x = ss * A(adj, "adj", 25000) / 100000.0; res.Add(Poly(0, x, x, x, x, 0, w - x, 0, w - x, x, w, x, w, h - x, w - x, h - x, w - x, h, x, h, x, h - x, 0, h - x)); break; }
                case "snip1Rect":
                    { double x = ss * A(adj, "adj", 16667) / 100000.0; res.Add(Poly(0, 0, w - x, 0, w, x, w, h, 0, h)); break; }
                case "snip2SameRect":
                    { double x = ss * A(adj, "adj1", 16667) / 100000.0; res.Add(Poly(x, 0, w - x, 0, w, x, w, h, 0, h, 0, x)); break; }
                case "heart":
                    {
                        var p = new GeoPath();
                        p.Cmds.Add(new PathCmd('M', w / 2, h * 0.3));
                        p.Cmds.Add(new PathCmd('C', w / 2, h * 0.02, w * 0.02, -h * 0.02, 0, h * 0.3));
                        p.Cmds.Add(new PathCmd('C', 0, h * 0.62, w * 0.45, h * 0.78, w / 2, h));
                        p.Cmds.Add(new PathCmd('C', w * 0.55, h * 0.78, w, h * 0.62, w, h * 0.3));
                        p.Cmds.Add(new PathCmd('C', w * 0.98, -h * 0.02, w / 2, h * 0.02, w / 2, h * 0.3));
                        p.Cmds.Add(new PathCmd('Z'));
                        res.Add(p); break;
                    }
                case "donut":
                    {
                        double t = ss * A(adj, "adj", 25000) / 100000.0;
                        var p = Ellipse(w / 2, h / 2, w / 2, h / 2);
                        var inner = Ellipse(w / 2, h / 2, Math.Max(1, w / 2 - t), Math.Max(1, h / 2 - t));
                        p.Cmds.AddRange(inner.Cmds); p.EvenOdd = true;
                        res.Add(p); break;
                    }
                case "frame":
                    {
                        double t = ss * A(adj, "adj1", 12500) / 100000.0;
                        var p = Poly(0, 0, w, 0, w, h, 0, h);
                        p.Cmds.AddRange(Poly(t, t, w - t, t, w - t, h - t, t, h - t).Cmds); p.EvenOdd = true;
                        res.Add(p); break;
                    }
                case "can":
                case "flowChartMagneticDisk":
                    {
                        double ry = Math.Min(h / 3, ss * A(adj, "adj", 25000) / 200000.0);
                        var body = new GeoPath();
                        body.Cmds.Add(new PathCmd('M', 0, ry));
                        body.Cmds.Add(new PathCmd('L', 0, h - ry));
                        AddHalfEllipse(body, w / 2, h - ry, w / 2, ry, true);
                        body.Cmds.Add(new PathCmd('L', w, ry));
                        AddHalfEllipse(body, w / 2, ry, w / 2, ry, false);
                        body.Cmds.Add(new PathCmd('Z'));
                        res.Add(body);
                        var top = Ellipse(w / 2, ry, w / 2, ry); top.ShadeFactor = 1.25; res.Add(top);
                        break;
                    }
                case "cube":
                    {
                        double d = ss * A(adj, "adj", 25000) / 100000.0;
                        res.Add(Poly(0, d, w - d, d, w - d, h, 0, h));
                        var top = Poly(0, d, d, 0, w, 0, w - d, d); top.ShadeFactor = 1.25; res.Add(top);
                        var side = Poly(w - d, d, w, 0, w, h - d, w - d, h); side.ShadeFactor = 0.75; res.Add(side);
                        break;
                    }
                case "wedgeRectCallout":
                case "wedgeRoundRectCallout":
                case "cloudCallout":
                    {
                        double tx = w / 2 + w * A(adj, "adj1", -20833) / 100000.0, ty = h / 2 + h * A(adj, "adj2", 62500) / 100000.0;
                        res.Add(Callout(w, h, tx, ty)); break;
                    }
                case "wedgeEllipseCallout":
                    {
                        double tx = w / 2 + w * A(adj, "adj1", -20833) / 100000.0, ty = h / 2 + h * A(adj, "adj2", 62500) / 100000.0;
                        var el = Ellipse(w / 2, h / 2, w / 2, h / 2);
                        // хвост: треугольник от центра к острию, рисуется отдельной заливкой без контура
                        double ang = Math.Atan2(ty - h / 2, tx - w / 2);
                        double sp = 0.18;
                        double bx1 = w / 2 + w / 2 * 0.92 * Math.Cos(ang - sp), by1 = h / 2 + h / 2 * 0.92 * Math.Sin(ang - sp);
                        double bx2 = w / 2 + w / 2 * 0.92 * Math.Cos(ang + sp), by2 = h / 2 + h / 2 * 0.92 * Math.Sin(ang + sp);
                        var tail = Poly(bx1, by1, tx, ty, bx2, by2);
                        res.Add(tail); res.Add(el);
                        break;
                    }
                case "flowChartDocument":
                    {
                        var p = new GeoPath();
                        p.Cmds.Add(new PathCmd('M', 0, 0)); p.Cmds.Add(new PathCmd('L', w, 0)); p.Cmds.Add(new PathCmd('L', w, h * 0.83));
                        p.Cmds.Add(new PathCmd('C', w * 0.75, h * 0.66, w * 0.25, h * 1.1, 0, h * 0.9));
                        p.Cmds.Add(new PathCmd('Z')); res.Add(p); break;
                    }
                case "flowChartPredefinedProcess":
                    {
                        res.Add(Poly(0, 0, w, 0, w, h, 0, h));
                        var l = new GeoPath { Filled = false };
                        l.Cmds.Add(new PathCmd('M', w * 0.125, 0)); l.Cmds.Add(new PathCmd('L', w * 0.125, h));
                        l.Cmds.Add(new PathCmd('M', w * 0.875, 0)); l.Cmds.Add(new PathCmd('L', w * 0.875, h));
                        res.Add(l); break;
                    }
                case "pie":
                case "chord":
                case "arc":
                case "blockArc":
                    {
                        double st = A(adj, "adj1", prst == "arc" ? 16200000 : 0) / 60000.0;
                        double en = A(adj, "adj2", prst == "arc" ? 0 : 16200000) / 60000.0;
                        if (prst == "chord") { st = A(adj, "adj1", 2700000) / 60000.0; en = A(adj, "adj2", 16200000) / 60000.0; }
                        double sw = en - st; while (sw <= 0) sw += 360;
                        var p = new GeoPath();
                        double sx, sy; EllipsePoint(w / 2, h / 2, w / 2, h / 2, st, out sx, out sy);
                        if (prst == "pie" || prst == "blockArc") { p.Cmds.Add(new PathCmd('M', w / 2, h / 2)); p.Cmds.Add(new PathCmd('L', sx, sy)); }
                        else p.Cmds.Add(new PathCmd('M', sx, sy));
                        ArcTo(p, sx, sy, w / 2, h / 2, st, sw);
                        if (prst != "arc") p.Cmds.Add(new PathCmd('Z')); else p.Filled = false;
                        res.Add(p); break;
                    }
                case "line":
                case "straightConnector1":
                case "arrowLine":
                    {
                        var p = new GeoPath { Filled = false };
                        p.Cmds.Add(new PathCmd('M', 0, 0)); p.Cmds.Add(new PathCmd('L', w, h)); res.Add(p); break;
                    }
                case "bentConnector2":
                    { var p = new GeoPath { Filled = false }; p.Cmds.Add(new PathCmd('M', 0, 0)); p.Cmds.Add(new PathCmd('L', w, 0)); p.Cmds.Add(new PathCmd('L', w, h)); res.Add(p); break; }
                case "bentConnector3":
                case "bentConnector4":
                case "bentConnector5":
                    {
                        double x = w * A(adj, "adj1", 50000) / 100000.0;
                        var p = new GeoPath { Filled = false }; p.Cmds.Add(new PathCmd('M', 0, 0)); p.Cmds.Add(new PathCmd('L', x, 0)); p.Cmds.Add(new PathCmd('L', x, h)); p.Cmds.Add(new PathCmd('L', w, h)); res.Add(p); break;
                    }
                case "curvedConnector2":
                case "curvedConnector3":
                case "curvedConnector4":
                case "curvedConnector5":
                    { var p = new GeoPath { Filled = false }; p.Cmds.Add(new PathCmd('M', 0, 0)); p.Cmds.Add(new PathCmd('C', w / 2, 0, w / 2, h, w, h)); res.Add(p); break; }
                default:
                    res.Add(Poly(0, 0, w, 0, w, h, 0, h)); break;
            }
            return res;
        }

        public static GeoPath Poly(params double[] pts)
        {
            var p = new GeoPath();
            p.Cmds.Add(new PathCmd('M', pts[0], pts[1]));
            for (int i = 2; i + 1 < pts.Length; i += 2) p.Cmds.Add(new PathCmd('L', pts[i], pts[i + 1]));
            p.Cmds.Add(new PathCmd('Z'));
            return p;
        }

        static GeoPath Regular(double w, double h, int n)
        {
            var pts = new double[n * 2];
            for (int i = 0; i < n; i++)
            {
                double a = -Math.PI / 2 + i * 2 * Math.PI / n;
                pts[i * 2] = w / 2 + w / 2 * Math.Cos(a); pts[i * 2 + 1] = h / 2 + h / 2 * Math.Sin(a);
            }
            return Poly(pts);
        }

        static GeoPath Star(double w, double h, int n, double inner)
        {
            inner = Units.Clamp(inner, 0.05, 0.98);
            var pts = new double[n * 4];
            for (int i = 0; i < n * 2; i++)
            {
                double a = -Math.PI / 2 + i * Math.PI / n;
                double r = (i % 2 == 0) ? 1 : inner;
                pts[i * 2] = w / 2 + w / 2 * r * Math.Cos(a); pts[i * 2 + 1] = h / 2 + h / 2 * r * Math.Sin(a);
            }
            return Poly(pts);
        }

        static GeoPath Callout(double w, double h, double tx, double ty)
        {
            if (ty > h) return Poly(0, 0, w, 0, w, h, Pick(tx, w, 0.42, 0.58), h, tx, ty, Pick(tx, w, 0.25, 0.75), h, 0, h);
            if (ty < 0) return Poly(0, 0, Pick(tx, w, 0.25, 0.75), 0, tx, ty, Pick(tx, w, 0.42, 0.58), 0, w, 0, w, h, 0, h);
            if (tx < 0) return Poly(0, 0, w, 0, w, h, 0, h, 0, Pick(ty, h, 0.58, 0.42), tx, ty, 0, Pick(ty, h, 0.75, 0.25));
            if (tx > w) return Poly(0, 0, w, 0, w, Pick(ty, h, 0.25, 0.75), tx, ty, w, Pick(ty, h, 0.42, 0.58), w, h, 0, h);
            return Poly(0, 0, w, 0, w, h, 0, h);
        }
        static double Pick(double t, double size, double lo, double hi) => t < size / 2 ? size * lo : size * hi;

        public static GeoPath Ellipse(double cx, double cy, double rx, double ry)
        {
            const double k = 0.5522847498;
            var p = new GeoPath();
            p.Cmds.Add(new PathCmd('M', cx + rx, cy));
            p.Cmds.Add(new PathCmd('C', cx + rx, cy + ry * k, cx + rx * k, cy + ry, cx, cy + ry));
            p.Cmds.Add(new PathCmd('C', cx - rx * k, cy + ry, cx - rx, cy + ry * k, cx - rx, cy));
            p.Cmds.Add(new PathCmd('C', cx - rx, cy - ry * k, cx - rx * k, cy - ry, cx, cy - ry));
            p.Cmds.Add(new PathCmd('C', cx + rx * k, cy - ry, cx + rx, cy - ry * k, cx + rx, cy));
            p.Cmds.Add(new PathCmd('Z'));
            return p;
        }

        static void AddHalfEllipse(GeoPath p, double cx, double cy, double rx, double ry, bool lowerFromLeft)
        {
            const double k = 0.5522847498;
            if (lowerFromLeft)
            {
                p.Cmds.Add(new PathCmd('C', cx - rx, cy + ry * k, cx - rx * k, cy + ry, cx, cy + ry));
                p.Cmds.Add(new PathCmd('C', cx + rx * k, cy + ry, cx + rx, cy + ry * k, cx + rx, cy));
            }
            else
            {
                p.Cmds.Add(new PathCmd('C', cx + rx, cy + ry * k, cx + rx * k, cy + ry, cx, cy + ry));
                p.Cmds.Add(new PathCmd('C', cx - rx * k, cy + ry, cx - rx, cy + ry * k, cx - rx, cy));
            }
        }

        public static GeoPath RoundRect(double w, double h, double rTL, double rTR, double rBR, double rBL)
        {
            double lim = Math.Min(w, h) / 2;
            rTL = Math.Min(rTL, lim); rTR = Math.Min(rTR, lim); rBR = Math.Min(rBR, lim); rBL = Math.Min(rBL, lim);
            const double k = 0.5522847498;
            var p = new GeoPath();
            p.Cmds.Add(new PathCmd('M', rTL, 0));
            p.Cmds.Add(new PathCmd('L', w - rTR, 0));
            if (rTR > 0) p.Cmds.Add(new PathCmd('C', w - rTR + rTR * k, 0, w, rTR - rTR * k, w, rTR));
            p.Cmds.Add(new PathCmd('L', w, h - rBR));
            if (rBR > 0) p.Cmds.Add(new PathCmd('C', w, h - rBR + rBR * k, w - rBR + rBR * k, h, w - rBR, h));
            p.Cmds.Add(new PathCmd('L', rBL, h));
            if (rBL > 0) p.Cmds.Add(new PathCmd('C', rBL - rBL * k, h, 0, h - rBL + rBL * k, 0, h - rBL));
            p.Cmds.Add(new PathCmd('L', 0, rTL));
            if (rTL > 0) p.Cmds.Add(new PathCmd('C', 0, rTL - rTL * k, rTL - rTL * k, 0, rTL, 0));
            p.Cmds.Add(new PathCmd('Z'));
            return p;
        }

        static void EllipsePoint(double cx, double cy, double rx, double ry, double deg, out double x, out double y)
        {
            double a = deg * Math.PI / 180;
            double t = Math.Atan2(rx * Math.Sin(a), ry * Math.Cos(a));
            x = cx + rx * Math.Cos(t); y = cy + ry * Math.Sin(t);
        }

        /// <summary>Дуга DrawingML (arcTo) из текущей точки; возвращает конечную точку.</summary>
        public static void ArcTo(GeoPath p, double curX, double curY, double wR, double hR, double stDeg, double swDeg)
        {
            if (wR <= 0 || hR <= 0) return;
            double a0 = stDeg * Math.PI / 180;
            double t0 = Math.Atan2(wR * Math.Sin(a0), hR * Math.Cos(a0));
            double a1 = (stDeg + swDeg) * Math.PI / 180;
            double t1 = Math.Atan2(wR * Math.Sin(a1), hR * Math.Cos(a1));
            // корректируем направление/полные обороты
            double dt = t1 - t0;
            if (swDeg > 0) { while (dt <= 0) dt += 2 * Math.PI; if (swDeg >= 360) dt = 2 * Math.PI; }
            else if (swDeg < 0) { while (dt >= 0) dt -= 2 * Math.PI; if (swDeg <= -360) dt = -2 * Math.PI; }
            else return;
            double cx = curX - wR * Math.Cos(t0), cy = curY - hR * Math.Sin(t0);
            int segs = (int)Math.Ceiling(Math.Abs(dt) / (Math.PI / 2));
            double step = dt / segs;
            double t = t0;
            for (int i = 0; i < segs; i++)
            {
                double k = 4.0 / 3.0 * Math.Tan(step / 4);
                double x0 = cx + wR * Math.Cos(t), y0 = cy + hR * Math.Sin(t);
                double tn = t + step;
                double x3 = cx + wR * Math.Cos(tn), y3 = cy + hR * Math.Sin(tn);
                double x1 = x0 - k * wR * Math.Sin(t), y1 = y0 + k * hR * Math.Cos(t);
                double x2 = x3 + k * wR * Math.Sin(tn), y2 = y3 - k * hR * Math.Cos(tn);
                p.Cmds.Add(new PathCmd('C', x1, y1, x2, y2, x3, y3));
                t = tn;
            }
        }
    }
}
