// Шаблон новой пустой презентации (валидный минимальный PPTX), создаётся в памяти.
using System.Collections.Generic;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public static class Template
    {
        const string NsDecl = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"";

        static XDocument X(string s) => SafeXml.Parse(System.Text.Encoding.UTF8.GetBytes(s));

        public static XDocument ThemeDoc(string name)
        {
            return X(@"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<a:theme xmlns:a=""http://schemas.openxmlformats.org/drawingml/2006/main"" name=""" + System.Security.SecurityElement.Escape(name) + @""">
<a:themeElements>
<a:clrScheme name=""SlideNova"">
<a:dk1><a:sysClr val=""windowText"" lastClr=""000000""/></a:dk1><a:lt1><a:sysClr val=""window"" lastClr=""FFFFFF""/></a:lt1>
<a:dk2><a:srgbClr val=""1F2A44""/></a:dk2><a:lt2><a:srgbClr val=""EEF1F7""/></a:lt2>
<a:accent1><a:srgbClr val=""4F6BED""/></a:accent1><a:accent2><a:srgbClr val=""F2709C""/></a:accent2>
<a:accent3><a:srgbClr val=""23C1A6""/></a:accent3><a:accent4><a:srgbClr val=""FFB547""/></a:accent4>
<a:accent5><a:srgbClr val=""8E5CF6""/></a:accent5><a:accent6><a:srgbClr val=""3BB4F2""/></a:accent6>
<a:hlink><a:srgbClr val=""0563C1""/></a:hlink><a:folHlink><a:srgbClr val=""954F72""/></a:folHlink>
</a:clrScheme>
<a:fontScheme name=""SlideNova""><a:majorFont><a:latin typeface=""Calibri Light""/><a:ea typeface=""""/><a:cs typeface=""""/></a:majorFont><a:minorFont><a:latin typeface=""Calibri""/><a:ea typeface=""""/><a:cs typeface=""""/></a:minorFont></a:fontScheme>
<a:fmtScheme name=""SlideNova"">
<a:fillStyleLst><a:solidFill><a:schemeClr val=""phClr""/></a:solidFill>
<a:gradFill rotWithShape=""1""><a:gsLst><a:gs pos=""0""><a:schemeClr val=""phClr""><a:lumMod val=""110000""/></a:schemeClr></a:gs><a:gs pos=""100000""><a:schemeClr val=""phClr""><a:shade val=""90000""/></a:schemeClr></a:gs></a:gsLst><a:lin ang=""5400000"" scaled=""0""/></a:gradFill>
<a:gradFill rotWithShape=""1""><a:gsLst><a:gs pos=""0""><a:schemeClr val=""phClr""><a:tint val=""90000""/></a:schemeClr></a:gs><a:gs pos=""100000""><a:schemeClr val=""phClr""><a:shade val=""80000""/></a:schemeClr></a:gs></a:gsLst><a:lin ang=""5400000"" scaled=""0""/></a:gradFill></a:fillStyleLst>
<a:lnStyleLst><a:ln w=""6350""><a:solidFill><a:schemeClr val=""phClr""/></a:solidFill><a:prstDash val=""solid""/></a:ln><a:ln w=""12700""><a:solidFill><a:schemeClr val=""phClr""/></a:solidFill><a:prstDash val=""solid""/></a:ln><a:ln w=""19050""><a:solidFill><a:schemeClr val=""phClr""/></a:solidFill><a:prstDash val=""solid""/></a:ln></a:lnStyleLst>
<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>
<a:bgFillStyleLst><a:solidFill><a:schemeClr val=""phClr""/></a:solidFill><a:solidFill><a:schemeClr val=""phClr""><a:tint val=""95000""/></a:schemeClr></a:solidFill><a:solidFill><a:schemeClr val=""phClr""><a:shade val=""90000""/></a:schemeClr></a:solidFill></a:bgFillStyleLst>
</a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>");
        }

        static string Lvl(int i, int sz, bool bullet, long marL)
        {
            string b = bullet ? "<a:buFont typeface=\"Arial\"/><a:buChar char=\"•\"/>" : "<a:buNone/>";
            return "<a:lvl" + i + "pPr marL=\"" + marL + "\" indent=\"" + (bullet ? -228600 : 0) + "\" algn=\"l\" rtl=\"0\"><a:lnSpc><a:spcPct val=\"90000\"/></a:lnSpc><a:spcBef><a:spcPts val=\"" + (bullet ? 1000 : 0) + "\"/></a:spcBef>" + b +
                   "<a:defRPr sz=\"" + sz + "\" kern=\"1200\"><a:solidFill><a:schemeClr val=\"tx1\"/></a:solidFill><a:latin typeface=\"+mn-lt\"/><a:ea typeface=\"+mn-ea\"/><a:cs typeface=\"+mn-cs\"/></a:defRPr></a:lvl" + i + "pPr>";
        }

        static string Ph(int id, string name, string type, string idx, long x, long y, long cx, long cy, string body = "")
        {
            string ph = "<p:ph" + (type != null ? " type=\"" + type + "\"" : "") + (idx != null ? " idx=\"" + idx + "\"" : "") + "/>";
            return "<p:sp><p:nvSpPr><p:cNvPr id=\"" + id + "\" name=\"" + name + "\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr>" + ph + "</p:nvPr></p:nvSpPr>" +
                   "<p:spPr><a:xfrm><a:off x=\"" + x + "\" y=\"" + y + "\"/><a:ext cx=\"" + cx + "\" cy=\"" + cy + "\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
                   "<p:txBody><a:bodyPr" + body + "/><a:lstStyle/><a:p><a:endParaRPr lang=\"ru-RU\"/></a:p></p:txBody></p:sp>";
        }

        const string TreeHead = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>";

        static XDocument MasterDoc(long w, long h)
        {
            long m = w / 16, tw = w - 2 * m;
            var sb = new System.Text.StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:sldMaster " + NsDecl + "><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>" + TreeHead);
            sb.Append(Ph(2, "Заголовок 1", "title", null, m, h / 20, tw, h * 29 / 200, " vert=\"horz\" anchor=\"ctr\""));
            sb.Append(Ph(3, "Текст 2", "body", "1", m, h * 53 / 200, tw, h * 6 / 10, " vert=\"horz\""));
            sb.Append(Ph(4, "Дата 3", "dt", "2", m, h * 93 / 100 - h / 40, tw / 4, h / 20, " anchor=\"ctr\""));
            sb.Append(Ph(5, "Нижний колонтитул 4", "ftr", "3", w * 3 / 8, h * 93 / 100 - h / 40, w / 4, h / 20, " anchor=\"ctr\""));
            sb.Append(Ph(6, "Номер слайда 5", "sldNum", "4", w - m - tw / 4, h * 93 / 100 - h / 40, tw / 4, h / 20, " anchor=\"ctr\""));
            sb.Append("</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>");
            sb.Append("<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/><p:sldLayoutId id=\"2147483650\" r:id=\"rId2\"/><p:sldLayoutId id=\"2147483651\" r:id=\"rId3\"/><p:sldLayoutId id=\"2147483652\" r:id=\"rId4\"/></p:sldLayoutIdLst>");
            sb.Append("<p:txStyles><p:titleStyle><a:lvl1pPr algn=\"l\" rtl=\"0\"><a:lnSpc><a:spcPct val=\"90000\"/></a:lnSpc><a:spcBef><a:spcPct val=\"0\"/></a:spcBef><a:buNone/><a:defRPr sz=\"4400\" kern=\"1200\"><a:solidFill><a:schemeClr val=\"tx1\"/></a:solidFill><a:latin typeface=\"+mj-lt\"/><a:ea typeface=\"+mj-ea\"/><a:cs typeface=\"+mj-cs\"/></a:defRPr></a:lvl1pPr></p:titleStyle><p:bodyStyle>");
            sb.Append(Lvl(1, 2800, true, 228600)).Append(Lvl(2, 2400, true, 685800)).Append(Lvl(3, 2000, true, 1143000)).Append(Lvl(4, 1800, true, 1600200)).Append(Lvl(5, 1800, true, 2057400));
            sb.Append("</p:bodyStyle><p:otherStyle>").Append(Lvl(1, 1800, false, 0)).Append("</p:otherStyle></p:txStyles></p:sldMaster>");
            return X(sb.ToString());
        }

        static XDocument LayoutDoc(string type, string name, long w, long h)
        {
            long m = w / 16, tw = w - 2 * m;
            var sb = new System.Text.StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:sldLayout " + NsDecl + " type=\"" + type + "\" preserve=\"1\"><p:cSld name=\"" + name + "\"><p:spTree>" + TreeHead);
            switch (type)
            {
                case "title":
                    sb.Append(Ph(2, "Заголовок 1", "ctrTitle", null, w / 8, h * 3 / 16, w * 3 / 4, h * 4 / 10, " anchor=\"b\""));
                    sb.Append(Ph(3, "Подзаголовок 2", "subTitle", "1", w / 8, h * 6 / 10, w * 3 / 4, h / 4, ""));
                    break;
                case "obj":
                    sb.Append(Ph(2, "Заголовок 1", "title", null, m, h / 20, tw, h * 29 / 200, ""));
                    sb.Append(Ph(3, "Объект 2", null, "1", m, h * 53 / 200, tw, h * 6 / 10, ""));
                    break;
                case "titleOnly":
                    sb.Append(Ph(2, "Заголовок 1", "title", null, m, h / 20, tw, h * 29 / 200, ""));
                    break;
            }
            sb.Append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>");
            var d = X(sb.ToString());
            if (type == "title")
            {
                // центрирование и крупный шрифт для титульного слайда
                foreach (var sp in d.Root.Descendants(Ns.P + "sp"))
                {
                    var ph = sp.Descendants(Ns.P + "ph").FirstOrDefaultSafe();
                    var t = (string)ph?.Attribute("type");
                    var lst = sp.Element(Ns.P + "txBody")?.Element(Ns.A + "lstStyle");
                    if (lst == null) continue;
                    if (t == "ctrTitle") lst.Add(XElement.Parse("<a:lvl1pPr xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" algn=\"ctr\"><a:defRPr sz=\"5400\"/></a:lvl1pPr>"));
                    else lst.Add(XElement.Parse("<a:lvl1pPr xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" marL=\"0\" indent=\"0\" algn=\"ctr\"><a:buNone/><a:defRPr sz=\"2400\"/></a:lvl1pPr>"));
                }
            }
            return d;
        }

        static XElement FirstOrDefaultSafe(this IEnumerable<XElement> e) { foreach (var x in e) return x; return null; }

        public static XDocument NotesMasterDoc()
        {
            return X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:notesMaster " + NsDecl + "><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>" + TreeHead +
                Ph(2, "Образ слайда 1", "sldImg", "2", 685800, 1143000, 5486400, 3086100, "") +
                Ph(3, "Заметки 2", "body", "3", 685800, 4400550, 5486400, 3600450, "") +
                "</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
                "<p:notesStyle>" + Lvl(1, 1200, false, 0).Replace("lvl1pPr", "lvl1pPr") + "</p:notesStyle></p:notesMaster>");
        }

        /// <summary>Создать пакет новой презентации заданного размера (EMU).</summary>
        public static OpcPackage Create(long w = 12192000, long h = 6858000)
        {
            var pkg = new OpcPackage();
            pkg.Defaults["rels"] = ContentTypes.Rels;
            pkg.Defaults["xml"] = "application/xml";
            pkg.Defaults["jpeg"] = "image/jpeg";
            pkg.Defaults["png"] = "image/png";

            pkg.SetRels("/", new List<Rel>
            {
                new Rel { Id = "rId1", Type = Rt.OfficeDoc, Target = "ppt/presentation.xml" },
                new Rel { Id = "rId2", Type = Rt.CoreProps, Target = "docProps/core.xml" },
                new Rel { Id = "rId3", Type = Rt.ExtProps, Target = "docProps/app.xml" },
            });
            pkg.SetXml("/docProps/core.xml", X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><dc:title></dc:title><dc:creator></dc:creator><cp:revision>0</cp:revision></cp:coreProperties>"), ContentTypes.Core);
            pkg.SetXml("/docProps/app.xml", X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\"><Application>SlideNova</Application><AppVersion>1.0000</AppVersion></Properties>"), "application/vnd.openxmlformats-officedocument.extended-properties+xml");

            var pres = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:presentation " + NsDecl + " saveSubsetFonts=\"1\">" +
                "<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst>" +
                "<p:sldSz cx=\"" + w + "\" cy=\"" + h + "\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/>" +
                "<p:defaultTextStyle><a:defPPr><a:defRPr lang=\"ru-RU\"/></a:defPPr>" + Lvl(1, 1800, false, 0) + "</p:defaultTextStyle></p:presentation>";
            pkg.SetXml("/ppt/presentation.xml", X(pres), ContentTypes.MainPptx);
            pkg.SetRels("/ppt/presentation.xml", new List<Rel>
            {
                new Rel { Id = "rId1", Type = Rt.SlideMaster, Target = "slideMasters/slideMaster1.xml" },
                new Rel { Id = "rId2", Type = Rt.Theme, Target = "theme/theme1.xml" },
                new Rel { Id = "rId3", Type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps", Target = "presProps.xml" },
                new Rel { Id = "rId4", Type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps", Target = "viewProps.xml" },
                new Rel { Id = "rId5", Type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles", Target = "tableStyles.xml" },
            });
            pkg.SetXml("/ppt/presProps.xml", X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:presentationPr " + NsDecl + "/>"), "application/vnd.openxmlformats-officedocument.presentationml.presProps+xml");
            pkg.SetXml("/ppt/viewProps.xml", X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><p:viewPr " + NsDecl + "><p:gridSpacing cx=\"72008\" cy=\"72008\"/></p:viewPr>"), "application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml");
            pkg.SetXml("/ppt/tableStyles.xml", X("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><a:tblStyleLst xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" def=\"{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}\"/>"), "application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml");
            pkg.SetXml("/ppt/theme/theme1.xml", ThemeDoc("SlideNova"), ContentTypes.Theme);
            pkg.SetXml("/ppt/slideMasters/slideMaster1.xml", MasterDoc(w, h), "application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml");
            var mrels = new List<Rel>();
            string[] types = { "title", "obj", "titleOnly", "blank" };
            string[] names = { "Титульный слайд", "Заголовок и объект", "Только заголовок", "Пустой слайд" };
            for (int i = 0; i < 4; i++)
            {
                var lp = "/ppt/slideLayouts/slideLayout" + (i + 1) + ".xml";
                pkg.SetXml(lp, LayoutDoc(types[i], names[i], w, h), "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml");
                pkg.SetRels(lp, new List<Rel> { new Rel { Id = "rId1", Type = Rt.SlideMaster, Target = "../slideMasters/slideMaster1.xml" } });
                mrels.Add(new Rel { Id = "rId" + (i + 1), Type = Rt.SlideLayout, Target = "../slideLayouts/slideLayout" + (i + 1) + ".xml" });
            }
            mrels.Add(new Rel { Id = "rId5", Type = Rt.Theme, Target = "../theme/theme1.xml" });
            pkg.SetRels("/ppt/slideMasters/slideMaster1.xml", mrels);
            return pkg;
        }

        /// <summary>Новая презентация с титульным слайдом.</summary>
        public static PresentationModel NewPresentation(long w = 12192000, long h = 6858000)
        {
            var pres = new PptxReader(Create(w, h)).Read();
            pres.SourceFormat = "new";
            var proto = pres.Layouts.Find(l => l.Type == "title") ?? pres.Layouts[0];
            pres.Slides.Add(NewSlide(pres, proto));
            return pres;
        }

        public static SlideModel NewSlide(PresentationModel pres, LayoutProto proto)
        {
            var s = new SlideModel
            {
                LayoutPart = proto?.Part ?? pres.DefaultLayoutPart,
                LayoutName = proto?.Name ?? "",
                MasterShapes = proto?.Decor ?? new List<ShapeModel>(),
                Background = proto?.Background?.Clone() ?? FillDef.Solid(Rgba.White),
                HyperlinkColor = proto?.Hlink ?? Rgba.FromRgb(0x0563C1),
            };
            int id = 2;
            if (proto != null)
                foreach (var ph in proto.Placeholders)
                {
                    var c = ph.Clone();
                    c.Id = id++; c.Original = null;
                    s.Shapes.Add(c);
                }
            return s;
        }
    }
}
