// Минимальный безопасный читатель составных файлов OLE2 (Compound File Binary) для .ppt
using System;
using System.Collections.Generic;
using System.Text;

namespace SlideNova.Core
{
    public sealed class CfbReader
    {
        const uint ENDOFCHAIN = 0xFFFFFFFE, FREESECT = 0xFFFFFFFF;
        readonly byte[] _d;
        readonly int _sectorSize, _miniSectorSize;
        readonly uint _miniCutoff;
        readonly List<uint> _fat = new List<uint>();
        readonly List<uint> _miniFat = new List<uint>();
        byte[] _miniStream = new byte[0];

        public sealed class Entry
        {
            public string Name, Path;
            public int Type;
            public uint Start;
            public long Size;
            public int Left, Right, Child;
        }
        public readonly List<Entry> Entries = new List<Entry>();
        readonly Dictionary<string, Entry> _byPath = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);

        public CfbReader(byte[] data)
        {
            _d = data;
            if (data.Length < 512) throw new UnsafeFileException("Файл OLE2 повреждён (слишком короткий).");
            int shift = U16(0x1E);
            if (shift != 9 && shift != 12) throw new UnsafeFileException("Неверный размер сектора OLE2.");
            _sectorSize = 1 << shift;
            int miniShift = U16(0x20);
            if (miniShift != 6) throw new UnsafeFileException("Неверный размер мини-сектора OLE2.");
            _miniSectorSize = 1 << miniShift;
            _miniCutoff = U32(0x38);
            uint numFat = U32(0x2C);
            uint dirStart = U32(0x30);
            uint miniFatStart = U32(0x3C);
            uint numMiniFat = U32(0x40);
            uint difatStart = U32(0x44);
            uint numDifat = U32(0x48);

            long maxSectors = (data.Length / _sectorSize) + 1;
            if (numFat > maxSectors) throw new UnsafeFileException("Повреждённая таблица FAT.");

            // DIFAT
            var fatSectors = new List<uint>();
            for (int i = 0; i < 109 && fatSectors.Count < numFat; i++)
            {
                uint s = U32(0x4C + i * 4);
                if (s == FREESECT) break;
                fatSectors.Add(s);
            }
            uint dif = difatStart; int guard = 0;
            while (dif != ENDOFCHAIN && dif != FREESECT && fatSectors.Count < numFat && guard++ < numDifat + 2)
            {
                long off = SectorOffset(dif);
                int per = _sectorSize / 4 - 1;
                for (int i = 0; i < per && fatSectors.Count < numFat; i++)
                {
                    uint s = U32At(off + i * 4);
                    if (s != FREESECT) fatSectors.Add(s);
                }
                dif = U32At(off + per * 4);
            }
            foreach (var fs in fatSectors)
            {
                long off = SectorOffset(fs);
                for (int i = 0; i < _sectorSize / 4; i++) _fat.Add(U32At(off + i * 4));
            }

            // Каталог
            var dirData = ReadChain(dirStart, -1, false);
            for (int i = 0; i + 128 <= dirData.Length; i += 128)
            {
                int nameLen = BitConverter.ToUInt16(dirData, i + 64);
                string name = nameLen >= 2 && nameLen <= 64 ? Encoding.Unicode.GetString(dirData, i, nameLen - 2) : "";
                var e = new Entry
                {
                    Name = name,
                    Type = dirData[i + 66],
                    Left = BitConverter.ToInt32(dirData, i + 68),
                    Right = BitConverter.ToInt32(dirData, i + 72),
                    Child = BitConverter.ToInt32(dirData, i + 76),
                    Start = BitConverter.ToUInt32(dirData, i + 116),
                    Size = (long)BitConverter.ToUInt64(dirData, i + 120)
                };
                if (_sectorSize == 512) e.Size &= 0xFFFFFFFF;
                Entries.Add(e);
            }
            if (Entries.Count == 0 || Entries[0].Type != 5) throw new UnsafeFileException("Повреждён корневой каталог OLE2.");

            // Мини-поток
            var root = Entries[0];
            if (root.Size > 0 && root.Size < Limits.MaxPartBytes)
                _miniStream = ReadChain(root.Start, root.Size, false);
            var mf = ReadChain(miniFatStart, (long)numMiniFat * _sectorSize, false);
            for (int i = 0; i + 4 <= mf.Length; i += 4) _miniFat.Add(BitConverter.ToUInt32(mf, i));

            // Пути
            var visited = new HashSet<int>();
            Walk(root.Child, "", visited, 0);
        }

        void Walk(int idx, string prefix, HashSet<int> visited, int depth)
        {
            if (idx < 0 || idx >= Entries.Count || depth > 64 || !visited.Add(idx)) return;
            var e = Entries[idx];
            e.Path = prefix + e.Name;
            if (!_byPath.ContainsKey(e.Path)) _byPath[e.Path] = e;
            Walk(e.Left, prefix, visited, depth + 1);
            Walk(e.Right, prefix, visited, depth + 1);
            if (e.Type == 1) Walk(e.Child, e.Path + "/", visited, depth + 1);
        }

        public bool Exists(string path) => _byPath.TryGetValue(path, out var e) && e.Type == 2;

        public IEnumerable<Entry> Streams()
        {
            foreach (var e in _byPath.Values) if (e.Type == 2) yield return e;
        }

        public byte[] Read(string path)
        {
            if (!_byPath.TryGetValue(path, out var e) || e.Type != 2) return null;
            if (e.Size > Limits.MaxPartBytes) throw new UnsafeFileException("Поток OLE2 слишком велик: " + path);
            if (e.Size < _miniCutoff) return ReadChain(e.Start, e.Size, true);
            return ReadChain(e.Start, e.Size, false);
        }

        byte[] ReadChain(uint start, long size, bool mini)
        {
            var table = mini ? _miniFat : _fat;
            int ss = mini ? _miniSectorSize : _sectorSize;
            long cap = size >= 0 ? size : Limits.MaxPartBytes;
            var result = new System.IO.MemoryStream(size > 0 && size < int.MaxValue ? (int)size : 0);
            uint s = start; long count = 0; long maxCount = table.Count + 1;
            while (s != ENDOFCHAIN && s != FREESECT && result.Length < cap)
            {
                if (count++ > maxCount) throw new UnsafeFileException("Зацикленная цепочка секторов OLE2.");
                if (mini)
                {
                    long off = (long)s * ss;
                    if (off + ss > _miniStream.Length) break;
                    int len = (int)Math.Min(ss, cap - result.Length);
                    result.Write(_miniStream, (int)off, len);
                }
                else
                {
                    long off = SectorOffset(s);
                    if (off + ss > _d.Length) { int len0 = (int)Math.Max(0, Math.Min(_d.Length - off, cap - result.Length)); if (len0 > 0) result.Write(_d, (int)off, len0); break; }
                    int len = (int)Math.Min(ss, cap - result.Length);
                    result.Write(_d, (int)off, len);
                }
                if (s >= table.Count) break;
                s = table[(int)s];
            }
            return result.ToArray();
        }

        long SectorOffset(uint s) => ((long)s + 1) * _sectorSize;
        int U16(int o) => BitConverter.ToUInt16(_d, o);
        uint U32(int o) => BitConverter.ToUInt32(_d, o);
        uint U32At(long o) => o + 4 <= _d.Length ? BitConverter.ToUInt32(_d, (int)o) : FREESECT;
    }
}
