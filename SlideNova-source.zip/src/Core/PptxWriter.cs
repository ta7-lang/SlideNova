// Сохранение модели в PPTX. Неизменённые объекты сохраняются байт-в-байт (исходный XML),
// изменённые — «патчатся», новые — генерируются. Макросы и ActiveX удаляются.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public sealed class SaveOptions
    {
        public string Kind = "pptx"; // pptx | ppsx | potx
        public byte[] ThumbnailJpeg;
        public string UserName = "SlideNova";
    }

    public static class PptxWriter
    {
        static readonly XNamespace A = Ns.A, P = Ns.P, R = Ns.R;
        static readonly string[] SpPrOrder = { "xfrm", "custGeom", "prstGeom", "noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill", "ln", "effectLst", "effectDag", "scene3d", "sp3d", "extLst" };
        static readonly string[] RPrOrder = { "ln", "noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill", "effectLst", "effectDag", "highlight", "uLnTx", "uLn", "uFillTx", "uFill", "latin", "ea", "cs", "sym", "hlinkClick", "hlinkMouseOver", "rtl", "extLst" };
        static readonly string[] PPrOrder = { "lnSpc", "spcBef", "spcAft", "buClrTx", "buClr", "buSzTx", "buSzPct", "buSzPts", "buFontTx", "buFont", "buNone", "buAutoNum", "buChar", "buBlip", "tabLst", "defRPr", "extLst" };
        static readonly string[] FillNames = { "noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill" };

        sealed class Wc
        {
            public PresentationModel Pres; public OpcPackage Pkg; public string Part; public List<Rel> Rels;
            public Dictionary<string, string> MediaRel = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            public HashSet<int> UsedIds = new HashSet<int>(); public int NextId = 2;
            public Dictionary<ShapeModel, XElement> Emitted = new Dictionary<ShapeModel, XElement>();
            public Dictionary<ShapeModel, string> PicRel = new Dictionary<ShapeModel, string>();
        }

        public static byte[] Save(PresentationModel pres, SaveOptions opt)
        {
            var pkg = pres.Package.Clone();
            var presPart = pkg.FindByRelType("/", Rt.OfficeDoc) ?? "/ppt/presentation.xml";
            var presDoc = pkg.GetXml(presPart);
            var presRels = pkg.GetRels(presPart);
            pres.Security.RemovedOnSave.Clear();

            // 1. Удаление макросов и ActiveX
            foreach (var vr in presRels.Where(r => r.Type == Rt.Vba).ToList())
            {
                pkg.Remove(OpcPackage.ResolveTarget(presPart, vr.Target));
                presRels.Remove(vr);
                pres.Security.RemovedOnSave.Add("Проект макросов VBA");
            }
            foreach (var p in pkg.Parts.Keys.Where(k => k.StartsWith("/ppt/activeX", StringComparison.OrdinalIgnoreCase)).ToList())
            { pkg.Parts.Remove(p); pkg.Overrides.Remove(p); if (!pres.Security.RemovedOnSave.Contains("Элементы ActiveX")) pres.Security.RemovedOnSave.Add("Элементы ActiveX"); }
            foreach (var p in pkg.Parts.Keys.Where(k => (pkg.ContentTypeOf(k) ?? "").Contains("vbaProject")).ToList()) { pkg.Parts.Remove(p); pkg.Overrides.Remove(p); }
            string mainCt = opt.Kind == "ppsx" ? ContentTypes.MainPpsx : opt.Kind == "potx" ? ContentTypes.MainPotx : ContentTypes.MainPptx;
            pkg.Overrides[presPart] = mainCt;

            var originalSlideParts = new HashSet<string>(presRels.Where(r => r.Type == Rt.Slide).Select(r => OpcPackage.ResolveTarget(presPart, r.Target)), StringComparer.OrdinalIgnoreCase);
            var usedParts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var results = new List<Tuple<SlideModel, string, string, Wc>>(); // slide, part, notesPart, ctx

            // 2. Слайды
            foreach (var slide in pres.Slides)
            {
                string part = slide.PartName;
                bool existing = part != null && pkg.Has(part) && originalSlideParts.Contains(part) && !usedParts.Contains(part);
                XDocument doc; List<Rel> rels;
                if (existing)
                {
                    doc = pkg.GetXml(part);
                    rels = pkg.GetRels(part);
                }
                else
                {
                    part = pkg.UniquePartName("/ppt/slides/", "slide", "xml");
                    while (usedParts.Contains(part)) part = OpcPackage.Norm("/ppt/slides/slide" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".xml");
                    var src = slide.RelsSource ?? slide.PartName;
                    if (src != null && pkg.Has(src))
                    {
                        doc = pkg.GetXml(src);
                        rels = pkg.GetRels(src).Where(r => r.Type != Rt.NotesSlide).Select(r => r.Clone()).ToList();
                        // относительные цели остаются корректными: тот же каталог /ppt/slides/
                    }
                    else
                    {
                        // исходные связи недоступны (например, слайд восстановлен отменой после сохранения):
                        // объекты пересоздаются из модели, чтобы не ссылаться на несуществующие связи
                        int dropped = slide.Shapes.RemoveAll(sh => sh.Original != null && !sh.CanDetach);
                        foreach (var sh in slide.Shapes) if (sh.Original != null) sh.Detach();
                        if (dropped > 0) pres.Warnings.Add("Слайд " + (pres.Slides.IndexOf(slide) + 1) + ": объектов без возможности восстановления: " + dropped);
                        doc = NewSlideDoc();
                        rels = new List<Rel>();
                        var layout = slide.LayoutPart ?? pres.DefaultLayoutPart;
                        if (layout != null) rels.Add(new Rel { Id = "rId1", Type = Rt.SlideLayout, Target = OpcPackage.RelativeTarget(part, layout) });
                    }
                }
                usedParts.Add(part);
                var wc = new Wc { Pres = pres, Pkg = pkg, Part = part, Rels = rels };
                WriteSlide(slide, doc, wc);
                pkg.SetXml(part, doc, ContentTypes.Slide);

                // заметки
                string notesPart = existing ? pkg.FindByRelType(part, Rt.NotesSlide) : null;
                if (!existing) rels.RemoveAll(r => r.Type == Rt.NotesSlide);
                if (slide.NotesDirty || (!existing && !string.IsNullOrEmpty(slide.Notes)))
                {
                    if (notesPart != null && pkg.Has(notesPart)) PatchNotes(pkg, notesPart, slide.Notes);
                    else if (!string.IsNullOrEmpty(slide.Notes))
                    {
                        var nm = EnsureNotesMaster(pkg, presPart, presDoc, presRels);
                        notesPart = pkg.UniquePartName("/ppt/notesSlides/", "notesSlide", "xml");
                        pkg.SetXml(notesPart, NewNotesDoc(slide.Notes), ContentTypes.Notes);
                        pkg.SetRels(notesPart, new List<Rel>
                        {
                            new Rel { Id = "rId1", Type = Rt.NotesMaster, Target = OpcPackage.RelativeTarget(notesPart, nm) },
                            new Rel { Id = "rId2", Type = Rt.Slide, Target = OpcPackage.RelativeTarget(notesPart, part) },
                        });
                        rels.Add(new Rel { Id = OpcPackage.NewRelId(rels), Type = Rt.NotesSlide, Target = OpcPackage.RelativeTarget(part, notesPart) });
                    }
                }
                pkg.SetRels(part, rels);
                results.Add(Tuple.Create(slide, part, notesPart, wc));
            }

            // 3. Удаление слайдов, которых больше нет
            var removedSlides = originalSlideParts.Where(p => !usedParts.Contains(p)).ToList();
            var keptNotes = new HashSet<string>(results.Where(r => r.Item3 != null).Select(r => r.Item3), StringComparer.OrdinalIgnoreCase);
            foreach (var rp in removedSlides)
            {
                var np = pkg.FindByRelType(rp, Rt.NotesSlide);
                if (np != null && !keptNotes.Contains(np)) pkg.Remove(np);
                pkg.Remove(rp);
            }

            // 4. presentation.xml
            var root = presDoc.Root;
            var oldSlideRels = presRels.Where(r => r.Type == Rt.Slide).ToList();
            var keepRelByPart = new Dictionary<string, Rel>(StringComparer.OrdinalIgnoreCase);
            foreach (var r in oldSlideRels)
            {
                var t = OpcPackage.ResolveTarget(presPart, r.Target);
                if (usedParts.Contains(t) && !keepRelByPart.ContainsKey(t)) keepRelByPart[t] = r;
            }
            presRels.RemoveAll(r => r.Type == Rt.Slide && !keepRelByPart.Values.Contains(r));
            var sldIdLst = root.Element(P + "sldIdLst");
            var oldIds = new Dictionary<uint, XElement>();
            if (sldIdLst == null)
            {
                sldIdLst = new XElement(P + "sldIdLst");
                var before = root.Element(P + "sldSz") ?? root.Element(P + "notesSz");
                if (before != null) before.AddBeforeSelf(sldIdLst); else root.Add(sldIdLst);
            }
            var usedSldIds = new HashSet<uint>();
            uint maxId = 255;
            foreach (var r in results) if (r.Item1.OrigSldId > maxId) maxId = r.Item1.OrigSldId;
            foreach (var e in sldIdLst.Elements(P + "sldId")) { uint v = (uint)Dml.Attr(e, "id", 0); if (v > maxId) maxId = v; }
            sldIdLst.RemoveNodes();
            var finalIds = new List<uint>();
            foreach (var r in results)
            {
                var slide = r.Item1; var part = r.Item2;
                Rel rel;
                if (!keepRelByPart.TryGetValue(part, out rel))
                {
                    rel = new Rel { Id = OpcPackage.NewRelId(presRels), Type = Rt.Slide, Target = OpcPackage.RelativeTarget(presPart, part) };
                    presRels.Add(rel);
                }
                uint id = slide.OrigSldId;
                if (id < 256 || usedSldIds.Contains(id) || !keepRelByPart.ContainsKey(part) || slide.PartName == null || !string.Equals(slide.PartName, part, StringComparison.OrdinalIgnoreCase)) id = ++maxId;
                usedSldIds.Add(id);
                finalIds.Add(id);
                sldIdLst.Add(new XElement(P + "sldId", new XAttribute("id", id), new XAttribute(R + "id", rel.Id)));
                slide.OrigSldId = id; slide.OrigPresRelId = rel.Id;
            }
            if (!sldIdLst.HasElements) sldIdLst.Remove();
            // пользовательские показы и разделы
            var validRelIds = new HashSet<string>(presRels.Select(r => r.Id));
            foreach (var e in root.Element(P + "custShowLst")?.Descendants().Where(x => x.Attribute(R + "id") != null && !validRelIds.Contains((string)x.Attribute(R + "id"))).ToList() ?? new List<XElement>()) e.Remove();
            FixSections(root, results.Select(r => r.Item1).ToList(), finalIds);
            if (pres.SizeDirty)
            {
                var sz = root.Element(P + "sldSz");
                if (sz == null) { sz = new XElement(P + "sldSz"); var ns = root.Element(P + "notesSz"); if (ns != null) ns.AddBeforeSelf(sz); else root.Add(sz); }
                sz.SetAttributeValue("cx", Units.L(pres.SlideW)); sz.SetAttributeValue("cy", Units.L(pres.SlideH)); sz.SetAttributeValue("type", null);
            }
            pkg.SetXml(presPart, presDoc);
            pkg.SetRels(presPart, presRels);

            // 5. Медиа
            foreach (var m in pres.Media.Values) { /* добавлены в WriteSlide */ }

            // 6. Свойства и эскиз
            WriteCore(pkg, pres, opt);
            if (opt.ThumbnailJpeg != null && opt.ThumbnailJpeg.Length > 0)
            {
                var rootRels = pkg.GetRels("/");
                var old = rootRels.FirstOrDefault(r => r.Type == Rt.Thumbnail);
                if (old != null) { pkg.Remove(OpcPackage.ResolveTarget("/", old.Target)); rootRels.Remove(old); }
                pkg.Parts["/docProps/thumbnail.jpeg"] = opt.ThumbnailJpeg;
                pkg.Defaults["jpeg"] = "image/jpeg";
                rootRels.Add(new Rel { Id = OpcPackage.NewRelId(rootRels), Type = Rt.Thumbnail, Target = "docProps/thumbnail.jpeg" });
                pkg.SetRels("/", rootRels);
            }

            var bytes = pkg.ToZip();

            // 7. Синхронизация модели с сохранённым пакетом
            pres.Package = pkg;
            pres.MainContentType = mainCt;
            pres.SourceFormat = "pptx";
            pres.SizeDirty = false;
            pres.Info.Dirty = false;
            pres.Security.HasMacros = false; pres.Security.HasActiveX = false;
            foreach (var r in results)
            {
                var s = r.Item1;
                s.PartName = r.Item2; s.RelsSource = null; s.NotesPartName = r.Item3;
                s.BackgroundDirty = false; s.NotesDirty = false; s.HiddenDirty = false;
                foreach (var sh in s.Shapes) Sync(sh, r.Item4);
            }
            return bytes;
        }

        static void Sync(ShapeModel s, Wc wc)
        {
            if (!wc.Emitted.TryGetValue(s, out var el)) return;
            s.Original = new XElement(el);
            s.DirtyXfrm = s.DirtyGeom = s.DirtyFill = s.DirtyLine = s.DirtyText = s.DirtyImage = s.DirtyTable = false;
            if (wc.PicRel.TryGetValue(s, out var rid)) s.OrigImageRelId = rid;
            if (s.Children != null) foreach (var c in s.Children) Sync(c, wc);
        }

        static void FixSections(XElement root, List<SlideModel> slides, List<uint> ids)
        {
            var secLst = root.Descendants(Ns.P14 + "sectionLst").FirstOrDefault();
            if (secLst == null) return;
            var sections = secLst.Elements(Ns.P14 + "section").ToList();
            if (sections.Count == 0) return;
            var idToSec = new Dictionary<uint, int>();
            for (int i = 0; i < sections.Count; i++)
                foreach (var sid in sections[i].Descendants(Ns.P14 + "sldId")) idToSec[(uint)Dml.Attr(sid, "id", 0)] = i;
            var buckets = sections.Select(_ => new List<uint>()).ToList();
            int cur = 0;
            for (int i = 0; i < ids.Count; i++)
            {
                if (idToSec.TryGetValue(ids[i], out var sec)) cur = Math.Max(cur, sec);
                buckets[cur].Add(ids[i]);
            }
            for (int i = 0; i < sections.Count; i++)
            {
                var lst = sections[i].Element(Ns.P14 + "sldIdLst");
                if (lst == null) { lst = new XElement(Ns.P14 + "sldIdLst"); sections[i].Add(lst); }
                lst.RemoveNodes();
                foreach (var id in buckets[i]) lst.Add(new XElement(Ns.P14 + "sldId", new XAttribute("id", id)));
            }
        }

        // ---------------- Слайд ----------------
        static XDocument NewSlideDoc()
        {
            return new XDocument(new XDeclaration("1.0", "UTF-8", "yes"),
                new XElement(P + "sld",
                    new XAttribute(XNamespace.Xmlns + "a", A.NamespaceName), new XAttribute(XNamespace.Xmlns + "r", R.NamespaceName), new XAttribute(XNamespace.Xmlns + "p", P.NamespaceName),
                    new XElement(P + "cSld", new XElement(P + "spTree", GroupNv(1, ""), new XElement(P + "grpSpPr", ZeroXfrm()))),
                    new XElement(P + "clrMapOvr", new XElement(A + "masterClrMapping"))));
        }

        static XElement GroupNv(int id, string name) => new XElement(P + "nvGrpSpPr", new XElement(P + "cNvPr", new XAttribute("id", id), new XAttribute("name", name)), new XElement(P + "cNvGrpSpPr"), new XElement(P + "nvPr"));
        static XElement ZeroXfrm() => new XElement(A + "xfrm", new XElement(A + "off", new XAttribute("x", 0), new XAttribute("y", 0)), new XElement(A + "ext", new XAttribute("cx", 0), new XAttribute("cy", 0)),
            new XElement(A + "chOff", new XAttribute("x", 0), new XAttribute("y", 0)), new XElement(A + "chExt", new XAttribute("cx", 0), new XAttribute("cy", 0)));

        static void WriteSlide(SlideModel slide, XDocument doc, Wc wc)
        {
            var root = doc.Root;
            if (slide.Hidden) root.SetAttributeValue("show", "0"); else root.SetAttributeValue("show", null);
            var cSld = root.Element(P + "cSld");
            if (cSld == null) { cSld = new XElement(P + "cSld"); root.AddFirst(cSld); }
            if (slide.BackgroundDirty)
            {
                cSld.Element(P + "bg")?.Remove();
                if (slide.Background != null)
                    cSld.AddFirst(new XElement(P + "bg", new XElement(P + "bgPr", FillXml(slide.Background, wc), new XElement(A + "effectLst"))));
            }
            cSld.Element(P + "controls")?.Remove();
            wc.Rels.RemoveAll(r => r.Type == Rt.ActiveX);
            var spTree = cSld.Element(P + "spTree");
            if (spTree == null) { spTree = new XElement(P + "spTree"); var bg = cSld.Element(P + "bg"); if (bg != null) bg.AddAfterSelf(spTree); else cSld.AddFirst(spTree); }
            var nv = spTree.Element(P + "nvGrpSpPr") ?? GroupNv(1, "");
            var gp = spTree.Element(P + "grpSpPr") ?? new XElement(P + "grpSpPr");
            nv = new XElement(nv); gp = new XElement(gp);
            spTree.RemoveNodes();
            spTree.Add(nv, gp);
            wc.UsedIds.Add((int)Dml.Attr(nv.Element(P + "cNvPr"), "id", 1));
            // заранее резервируем идентификаторы исходных объектов
            void Reserve(IEnumerable<ShapeModel> list) { foreach (var s in list) { if (s.Original != null && s.Id > 0) wc.UsedIds.Add(s.Id); if (s.Children != null && s.Original != null) Reserve(s.Children); } }
            Reserve(slide.Shapes);
            foreach (var s in slide.Shapes)
            {
                var el = Emit(s, wc);
                if (el != null) spTree.Add(el);
            }
            // проверка анимаций: удаляем, если ссылаются на отсутствующие объекты
            var timing = root.Element(P + "timing");
            if (timing != null)
            {
                var ids = new HashSet<string>(spTree.Descendants().Where(e => e.Name.LocalName == "cNvPr").Select(e => (string)e.Attribute("id")));
                bool bad = timing.Descendants().Any(e => e.Name.LocalName == "spTgt" && !ids.Contains((string)e.Attribute("spid")));
                if (bad) timing.Remove();
            }
        }

        static int AllocId(ShapeModel s, Wc wc)
        {
            int id = s.Id;
            if (id <= 1 || (s.Original == null && wc.UsedIds.Contains(id)))
            {
                while (wc.UsedIds.Contains(wc.NextId)) wc.NextId++;
                id = wc.NextId;
            }
            wc.UsedIds.Add(id);
            s.Id = id;
            return id;
        }

        static XElement Emit(ShapeModel s, Wc wc)
        {
            XElement el;
            if (s.Original != null && !s.IsDirty && !ChildrenDirty(s)) el = new XElement(s.Original);
            else if (s.Original != null) el = Patch(s, wc);
            else el = Generate(s, wc);
            if (el != null) wc.Emitted[s] = el;
            return el;
        }

        static bool ChildrenDirty(ShapeModel s) => s.Children != null && s.Kind == ShapeKind.Group && s.Children.Any(c => c.IsDirty || c.Original == null || ChildrenDirty(c));

        // ---------------- Патч существующего XML ----------------
        static XElement Patch(ShapeModel s, Wc wc)
        {
            var el = new XElement(s.Original);
            var local = el.Name.LocalName;
            if (local == "grpSp")
            {
                var gsp = el.Element(P + "grpSpPr") ?? new XElement(P + "grpSpPr");
                if (s.DirtyXfrm)
                {
                    var x = gsp.Element(A + "xfrm");
                    if (x == null) { x = new XElement(A + "xfrm"); gsp.AddFirst(x); }
                    SetXfrmCore(x, s);
                    if (x.Element(A + "chOff") == null) x.Add(new XElement(A + "chOff", new XAttribute("x", Units.L(s.ChX)), new XAttribute("y", Units.L(s.ChY))));
                    if (x.Element(A + "chExt") == null) x.Add(new XElement(A + "chExt", new XAttribute("cx", Units.L(s.ChW)), new XAttribute("cy", Units.L(s.ChH))));
                }
                if (ChildrenDirty(s))
                {
                    var kids = el.Elements().Where(e => e.Name != P + "nvGrpSpPr" && e.Name != P + "grpSpPr").ToList();
                    foreach (var k in kids) k.Remove();
                    foreach (var c in s.Children) { var ce = Emit(c, wc); if (ce != null) el.Add(ce); }
                }
                return el;
            }
            if (local == "graphicFrame")
            {
                if (s.DirtyXfrm)
                {
                    var x = el.Element(P + "xfrm");
                    if (x == null) { x = new XElement(P + "xfrm"); var g = el.Element(A + "graphic"); if (g != null) g.AddBeforeSelf(x); else el.Add(x); }
                    SetXfrmCore(x, s);
                }
                if (s.DirtyTable && s.Table != null)
                {
                    var tbl = el.Element(A + "graphic")?.Element(A + "graphicData")?.Element(A + "tbl");
                    if (tbl != null) tbl.ReplaceWith(TableXml(s.Table, tbl.Element(A + "tblPr"), wc));
                }
                return el;
            }
            var spPr = el.Element(P + "spPr");
            if (spPr == null)
            {
                spPr = new XElement(P + "spPr");
                var anchor = el.Element(P + "nvSpPr") ?? el.Element(P + "nvCxnSpPr") ?? el.Element(P + "blipFill") ?? el.Element(P + "nvPicPr");
                if (local == "pic") (el.Element(P + "blipFill") ?? anchor)?.AddAfterSelf(spPr); else anchor?.AddAfterSelf(spPr);
                if (spPr.Parent == null) el.Add(spPr);
            }
            if (s.DirtyXfrm)
            {
                var x = spPr.Element(A + "xfrm");
                if (x == null) { x = new XElement(A + "xfrm"); spPr.AddFirst(x); }
                SetXfrmCore(x, s);
            }
            if (s.DirtyGeom)
            {
                spPr.Element(A + "prstGeom")?.Remove(); spPr.Element(A + "custGeom")?.Remove();
                InsertOrdered(spPr, GeomXml(s), SpPrOrder);
            }
            if (s.DirtyFill)
            {
                foreach (var f in spPr.Elements().Where(e => Array.IndexOf(FillNames, e.Name.LocalName) >= 0).ToList()) f.Remove();
                InsertOrdered(spPr, FillXml(s.Fill, wc), SpPrOrder);
            }
            if (s.DirtyLine)
            {
                spPr.Element(A + "ln")?.Remove();
                InsertOrdered(spPr, LineXml(s.Line), SpPrOrder);
            }
            if (s.DirtyImage && local == "pic" && s.ImageKey != null)
            {
                var blip = el.Element(P + "blipFill")?.Element(A + "blip");
                var rid = MediaRelId(s.ImageKey, wc);
                if (blip != null && rid != null)
                {
                    blip.SetAttributeValue(R + "embed", rid);
                    foreach (var ext in blip.Elements(A + "extLst").ToList()) ext.Remove(); // svg-расширение больше не актуально
                    wc.PicRel[s] = rid;
                }
                var bf = el.Element(P + "blipFill");
                bf?.Element(A + "srcRect")?.Remove();
                if (bf != null && (s.CropL != 0 || s.CropT != 0 || s.CropR != 0 || s.CropB != 0)) bf.Element(A + "blip")?.AddAfterSelf(SrcRect(s));
            }
            if (s.DirtyText && s.Text != null && local != "pic")
            {
                var tx = el.Element(P + "txBody");
                if (tx == null) { tx = new XElement(P + "txBody", new XElement(A + "bodyPr"), new XElement(A + "lstStyle")); el.Add(tx); }
                var bodyPr = tx.Element(A + "bodyPr");
                if (bodyPr == null) { bodyPr = new XElement(A + "bodyPr"); tx.AddFirst(bodyPr); }
                bodyPr.SetAttributeValue("anchor", s.Text.Anchor);
                foreach (var p in tx.Elements(A + "p").ToList()) p.Remove();
                foreach (var p in s.Text.Paras) tx.Add(ParaXml(p, wc));
                if (!tx.Elements(A + "p").Any()) tx.Add(new XElement(A + "p"));
            }
            return el;
        }

        static void SetXfrmCore(XElement x, ShapeModel s)
        {
            x.SetAttributeValue("rot", Math.Abs(s.Rot) > 0.001 ? (object)Units.L(Norm360(s.Rot) * 60000) : null);
            x.SetAttributeValue("flipH", s.FlipH ? "1" : null);
            x.SetAttributeValue("flipV", s.FlipV ? "1" : null);
            var off = x.Element(A + "off"); if (off == null) { off = new XElement(A + "off"); x.AddFirst(off); }
            off.SetAttributeValue("x", Units.L(s.X)); off.SetAttributeValue("y", Units.L(s.Y));
            var ext = x.Element(A + "ext"); if (ext == null) { ext = new XElement(A + "ext"); off.AddAfterSelf(ext); }
            ext.SetAttributeValue("cx", Math.Max(0, Units.L(s.W))); ext.SetAttributeValue("cy", Math.Max(0, Units.L(s.H)));
        }

        static double Norm360(double d) { d %= 360; if (d < 0) d += 360; return d; }

        static void InsertOrdered(XElement parent, XElement child, string[] order)
        {
            if (child == null) return;
            int idx = Array.IndexOf(order, child.Name.LocalName);
            foreach (var e in parent.Elements())
            {
                int j = Array.IndexOf(order, e.Name.LocalName);
                if (j > idx) { e.AddBeforeSelf(child); return; }
            }
            parent.Add(child);
        }

        // ---------------- Генерация нового XML ----------------
        static XElement Generate(ShapeModel s, Wc wc)
        {
            int id = AllocId(s, wc);
            string name = string.IsNullOrEmpty(s.Name) ? s.KindName + " " + id : s.Name;
            var cNvPr = new XElement(P + "cNvPr", new XAttribute("id", id), new XAttribute("name", name));
            if (!string.IsNullOrEmpty(s.AltText)) cNvPr.Add(new XAttribute("descr", s.AltText));
            switch (s.Kind)
            {
                case ShapeKind.Picture:
                    {
                        var rid = s.ImageKey != null ? MediaRelId(s.ImageKey, wc) : null;
                        if (rid == null) return null;
                        wc.PicRel[s] = rid;
                        var bf = new XElement(P + "blipFill", new XElement(A + "blip", new XAttribute(R + "embed", rid)));
                        if (s.CropL != 0 || s.CropT != 0 || s.CropR != 0 || s.CropB != 0) bf.Add(SrcRect(s));
                        bf.Add(new XElement(A + "stretch", new XElement(A + "fillRect")));
                        var spPr = new XElement(P + "spPr", XfrmXml(s), GeomXml(s));
                        if (s.Fill != null && s.Fill.Kind != FillKind.None) spPr.Add(FillXml(s.Fill, wc));
                        if (s.Line != null && s.Line.Visible) spPr.Add(LineXml(s.Line));
                        return new XElement(P + "pic",
                            new XElement(P + "nvPicPr", cNvPr, new XElement(P + "cNvPicPr", new XElement(A + "picLocks", new XAttribute("noChangeAspect", "1"))), new XElement(P + "nvPr")),
                            bf, spPr);
                    }
                case ShapeKind.Table:
                    {
                        if (s.Table == null) return null;
                        return new XElement(P + "graphicFrame",
                            new XElement(P + "nvGraphicFramePr", cNvPr, new XElement(P + "cNvGraphicFramePr", new XElement(A + "graphicFrameLocks", new XAttribute("noGrp", "1"))), new XElement(P + "nvPr")),
                            new XElement(P + "xfrm", new XElement(A + "off", new XAttribute("x", Units.L(s.X)), new XAttribute("y", Units.L(s.Y))), new XElement(A + "ext", new XAttribute("cx", Units.L(s.W)), new XAttribute("cy", Units.L(s.H)))),
                            new XElement(A + "graphic", new XElement(A + "graphicData", new XAttribute("uri", Ns.TableUri), TableXml(s.Table, null, wc))));
                    }
                case ShapeKind.Group:
                    {
                        var g = new XElement(P + "grpSp",
                            new XElement(P + "nvGrpSpPr", cNvPr, new XElement(P + "cNvGrpSpPr"), new XElement(P + "nvPr")),
                            new XElement(P + "grpSpPr", new XElement(A + "xfrm",
                                Math.Abs(s.Rot) > 0.001 ? new XAttribute("rot", Units.L(Norm360(s.Rot) * 60000)) : null,
                                new XElement(A + "off", new XAttribute("x", Units.L(s.X)), new XAttribute("y", Units.L(s.Y))),
                                new XElement(A + "ext", new XAttribute("cx", Units.L(s.W)), new XAttribute("cy", Units.L(s.H))),
                                new XElement(A + "chOff", new XAttribute("x", Units.L(s.ChX)), new XAttribute("y", Units.L(s.ChY))),
                                new XElement(A + "chExt", new XAttribute("cx", Units.L(s.ChW)), new XAttribute("cy", Units.L(s.ChH))))));
                        foreach (var c in s.Children ?? new List<ShapeModel>()) { var ce = Emit(c, wc); if (ce != null) g.Add(ce); }
                        return g;
                    }
                case ShapeKind.Graphic:
                    return null; // неподдерживаемые объекты без исходного XML не создаются
                case ShapeKind.Connector:
                    {
                        var spPr = new XElement(P + "spPr", XfrmXml(s), GeomXml(s), LineXml(s.Line));
                        return new XElement(P + "cxnSp", new XElement(P + "nvCxnSpPr", cNvPr, new XElement(P + "cNvCxnSpPr"), new XElement(P + "nvPr")), spPr);
                    }
                default:
                    {
                        var nvPr = new XElement(P + "nvPr");
                        if (s.PlaceholderType != null)
                        {
                            var ph = new XElement(P + "ph");
                            if (s.PlaceholderType != "obj") ph.Add(new XAttribute("type", s.PlaceholderType));
                            if (s.PlaceholderIdx != null) ph.Add(new XAttribute("idx", s.PlaceholderIdx));
                            nvPr.Add(ph);
                        }
                        var cNvSpPr = new XElement(P + "cNvSpPr");
                        if (s.IsTextBox) cNvSpPr.Add(new XAttribute("txBox", "1"));
                        if (s.PlaceholderType != null) cNvSpPr.Add(new XElement(A + "spLocks", new XAttribute("noGrp", "1")));
                        var spPr = new XElement(P + "spPr", XfrmXml(s), GeomXml(s));
                        if (s.PlaceholderType == null || s.Fill.Kind != FillKind.None) spPr.Add(FillXml(s.Fill, wc));
                        if (s.PlaceholderType == null || s.Line.Visible) spPr.Add(LineXml(s.Line));
                        var sp = new XElement(P + "sp", new XElement(P + "nvSpPr", cNvPr, cNvSpPr, nvPr), spPr);
                        var t = s.Text ?? new TextBodyModel();
                        var bodyPr = new XElement(A + "bodyPr", new XAttribute("rtlCol", "0"), new XAttribute("anchor", t.Anchor ?? "t"));
                        if (!t.Wrap) bodyPr.Add(new XAttribute("wrap", "none")); else bodyPr.Add(new XAttribute("wrap", "square"));
                        if (s.PlaceholderType == null)
                        {
                            bodyPr.Add(new XAttribute("lIns", Units.L(t.LIns)), new XAttribute("tIns", Units.L(t.TIns)), new XAttribute("rIns", Units.L(t.RIns)), new XAttribute("bIns", Units.L(t.BIns)));
                            if (t.AutoFitShape) bodyPr.Add(new XElement(A + "spAutoFit")); else bodyPr.Add(new XElement(A + "noAutofit"));
                        }
                        else bodyPr.Add(new XElement(A + "normAutofit"));
                        var tx = new XElement(P + "txBody", bodyPr, s.PlaceholderType == null ? LstStyleXml(t.Levels) : new XElement(A + "lstStyle"));
                        foreach (var p in t.Paras) tx.Add(ParaXml(p, wc));
                        if (!tx.Elements(A + "p").Any()) tx.Add(new XElement(A + "p", new XElement(A + "endParaRPr", new XAttribute("lang", "ru-RU"))));
                        sp.Add(tx);
                        return sp;
                    }
            }
        }

        static XElement SrcRect(ShapeModel s) => new XElement(A + "srcRect",
            s.CropL != 0 ? new XAttribute("l", Units.L(s.CropL * 100000)) : null, s.CropT != 0 ? new XAttribute("t", Units.L(s.CropT * 100000)) : null,
            s.CropR != 0 ? new XAttribute("r", Units.L(s.CropR * 100000)) : null, s.CropB != 0 ? new XAttribute("b", Units.L(s.CropB * 100000)) : null);

        static XElement XfrmXml(ShapeModel s)
        {
            var x = new XElement(A + "xfrm");
            SetXfrmCore(x, s);
            return x;
        }

        static XElement GeomXml(ShapeModel s)
        {
            if (s.Geometry == "custom" && s.CustomPaths != null && s.CustomPaths.Count > 0)
            {
                var pathLst = new XElement(A + "pathLst");
                foreach (var gp in s.CustomPaths)
                {
                    var path = new XElement(A + "path", new XAttribute("w", Units.L(s.CustW)), new XAttribute("h", Units.L(s.CustH)));
                    if (!gp.Filled) path.Add(new XAttribute("fill", "none"));
                    if (!gp.Stroked) path.Add(new XAttribute("stroke", "0"));
                    foreach (var c in gp.Cmds)
                    {
                        switch (c.Type)
                        {
                            case 'M': path.Add(new XElement(A + "moveTo", Pt(c.P[0], c.P[1]))); break;
                            case 'L': path.Add(new XElement(A + "lnTo", Pt(c.P[0], c.P[1]))); break;
                            case 'C': path.Add(new XElement(A + "cubicBezTo", Pt(c.P[0], c.P[1]), Pt(c.P[2], c.P[3]), Pt(c.P[4], c.P[5]))); break;
                            case 'Z': path.Add(new XElement(A + "close")); break;
                        }
                    }
                    pathLst.Add(path);
                }
                return new XElement(A + "custGeom", new XElement(A + "avLst"), new XElement(A + "gdLst"), new XElement(A + "ahLst"), new XElement(A + "cxnLst"),
                    new XElement(A + "rect", new XAttribute("l", "0"), new XAttribute("t", "0"), new XAttribute("r", "r"), new XAttribute("b", "b")), pathLst);
            }
            string prst = s.Geometry == "arrowLine" ? "line" : (s.Geometry == "custom" ? "rect" : s.Geometry ?? "rect");
            var av = new XElement(A + "avLst");
            foreach (var kv in s.Adj) av.Add(new XElement(A + "gd", new XAttribute("name", kv.Key), new XAttribute("fmla", "val " + Units.L(kv.Value))));
            return new XElement(A + "prstGeom", new XAttribute("prst", prst), av);
        }

        static XElement Pt(double x, double y) => new XElement(A + "pt", new XAttribute("x", Units.L(x)), new XAttribute("y", Units.L(y)));

        static XElement ColorXml(Rgba c)
        {
            var e = new XElement(A + "srgbClr", new XAttribute("val", c.Hex));
            if (c.A < 255) e.Add(new XElement(A + "alpha", new XAttribute("val", Units.L(c.A / 255.0 * 100000))));
            return e;
        }

        static XElement FillXml(FillDef f, Wc wc)
        {
            if (f == null) return new XElement(A + "noFill");
            switch (f.Kind)
            {
                case FillKind.Solid: return new XElement(A + "solidFill", ColorXml(f.Color));
                case FillKind.Gradient:
                    {
                        var gs = new XElement(A + "gsLst");
                        foreach (var s in f.Stops) gs.Add(new XElement(A + "gs", new XAttribute("pos", Units.L(Units.Clamp(s.Pos, 0, 1) * 100000)), ColorXml(s.Color)));
                        var g = new XElement(A + "gradFill", new XAttribute("rotWithShape", "1"), gs);
                        if (f.Radial) g.Add(new XElement(A + "path", new XAttribute("path", "circle"), new XElement(A + "fillToRect", new XAttribute("l", 50000), new XAttribute("t", 50000), new XAttribute("r", 50000), new XAttribute("b", 50000))));
                        else g.Add(new XElement(A + "lin", new XAttribute("ang", Units.L(Norm360(f.Angle) * 60000)), new XAttribute("scaled", "0")));
                        return g;
                    }
                case FillKind.Image:
                    {
                        var rid = f.ImageKey != null ? MediaRelId(f.ImageKey, wc) : null;
                        if (rid == null) return new XElement(A + "noFill");
                        var b = new XElement(A + "blipFill", new XAttribute("dpi", "0"), new XAttribute("rotWithShape", "1"), new XElement(A + "blip", new XAttribute(R + "embed", rid)), new XElement(A + "srcRect"));
                        if (f.Tile) b.Add(new XElement(A + "tile", new XAttribute("tx", 0), new XAttribute("ty", 0), new XAttribute("sx", 100000), new XAttribute("sy", 100000), new XAttribute("flip", "none"), new XAttribute("algn", "tl")));
                        else b.Add(new XElement(A + "stretch", new XElement(A + "fillRect")));
                        return b;
                    }
                default: return new XElement(A + "noFill");
            }
        }

        static XElement LineXml(LineDef l)
        {
            if (l == null || !l.Visible) return new XElement(A + "ln", new XElement(A + "noFill"));
            var e = new XElement(A + "ln", new XAttribute("w", Math.Max(0, Units.L(l.WidthEmu))), new XElement(A + "solidFill", ColorXml(l.Color)));
            if (!string.IsNullOrEmpty(l.Dash) && l.Dash != "solid") e.Add(new XElement(A + "prstDash", new XAttribute("val", l.Dash)));
            if (!string.IsNullOrEmpty(l.HeadEnd) && l.HeadEnd != "none") e.Add(new XElement(A + "headEnd", new XAttribute("type", l.HeadEnd)));
            if (!string.IsNullOrEmpty(l.TailEnd) && l.TailEnd != "none") e.Add(new XElement(A + "tailEnd", new XAttribute("type", l.TailEnd)));
            return e;
        }

        static string MediaRelId(string key, Wc wc)
        {
            if (wc.MediaRel.TryGetValue(key, out var rid)) return rid;
            if (!wc.Pres.Media.TryGetValue(key, out var m) || m.Data == null) return null;
            string part = m.PartName;
            if (part == null || !wc.Pkg.Has(part))
            {
                var ext = string.IsNullOrEmpty(m.Ext) ? "png" : m.Ext;
                part = wc.Pkg.UniquePartName("/ppt/media/", "image", ext);
                wc.Pkg.Parts[part] = m.Data;
                if (!wc.Pkg.Defaults.ContainsKey(ext)) wc.Pkg.Defaults[ext] = m.ContentType ?? ContentTypes.ForImageExt(ext);
                m.PartName = part;
            }
            var existing = wc.Rels.FirstOrDefault(r => r.Type == Rt.Image && !r.External && string.Equals(OpcPackage.ResolveTarget(wc.Part, r.Target), part, StringComparison.OrdinalIgnoreCase));
            if (existing != null) rid = existing.Id;
            else
            {
                rid = OpcPackage.NewRelId(wc.Rels);
                wc.Rels.Add(new Rel { Id = rid, Type = Rt.Image, Target = OpcPackage.RelativeTarget(wc.Part, part) });
            }
            wc.MediaRel[key] = rid;
            return rid;
        }

        // ---------------- Текст ----------------
        static XElement ParaXml(ParaModel p, Wc wc)
        {
            var pe = new XElement(A + "p");
            var pPr = p.OrigPPr != null ? new XElement(p.OrigPPr) : new XElement(A + "pPr");
            pPr.SetAttributeValue("algn", p.Align);
            pPr.SetAttributeValue("lvl", p.Level > 0 ? (object)p.Level : null);
            if (p.Bullet != null)
            {
                foreach (var b in pPr.Elements().Where(e => e.Name.LocalName == "buNone" || e.Name.LocalName == "buAutoNum" || e.Name.LocalName == "buChar" || e.Name.LocalName == "buBlip" || e.Name.LocalName == "buFont").ToList()) b.Remove();
                if (p.Bullet.Length == 0) InsertOrdered(pPr, new XElement(A + "buNone"), PPrOrder);
                else if (p.Bullet[0] == '\u0001') InsertOrdered(pPr, new XElement(A + "buAutoNum", new XAttribute("type", p.Bullet.Substring(1))), PPrOrder);
                else
                {
                    InsertOrdered(pPr, new XElement(A + "buFont", new XAttribute("typeface", "Arial")), PPrOrder);
                    InsertOrdered(pPr, new XElement(A + "buChar", new XAttribute("char", p.Bullet)), PPrOrder);
                }
            }
            if (p.LineSpacingPct.HasValue) { pPr.Element(A + "lnSpc")?.Remove(); InsertOrdered(pPr, new XElement(A + "lnSpc", new XElement(A + "spcPct", new XAttribute("val", Units.L(p.LineSpacingPct.Value * 1000)))), PPrOrder); }
            if (p.SpaceBeforePt.HasValue) { pPr.Element(A + "spcBef")?.Remove(); InsertOrdered(pPr, new XElement(A + "spcBef", new XElement(A + "spcPts", new XAttribute("val", Units.L(p.SpaceBeforePt.Value * 100)))), PPrOrder); }
            if (p.SpaceAfterPt.HasValue) { pPr.Element(A + "spcAft")?.Remove(); InsertOrdered(pPr, new XElement(A + "spcAft", new XElement(A + "spcPts", new XAttribute("val", Units.L(p.SpaceAfterPt.Value * 100)))), PPrOrder); }
            if (pPr.HasAttributes || pPr.HasElements) pe.Add(pPr);
            foreach (var r in p.Runs)
            {
                var rPr = RPrXml(r, wc);
                if (r.IsBreak) pe.Add(new XElement(A + "br", rPr));
                else if (!string.IsNullOrEmpty(r.Text)) pe.Add(new XElement(A + "r", rPr, new XElement(A + "t", SanitizeText(r.Text))));
            }
            var end = new XElement(A + "endParaRPr", new XAttribute("lang", "ru-RU"), new XAttribute("dirty", "0"));
            if (p.EndSizePt.HasValue) end.Add(new XAttribute("sz", Units.L(p.EndSizePt.Value * 100)));
            pe.Add(end);
            return pe;
        }

        /// <summary>Стиль уровней для новых фигур (чтобы PowerPoint показал текст так же, как редактор).</summary>
        static XElement LstStyleXml(LevelStyle[] lv)
        {
            var e = new XElement(A + "lstStyle");
            for (int i = 0; i < 9 && i < lv.Length; i++)
            {
                var l = lv[i];
                var p = new XElement(A + ("lvl" + (i + 1) + "pPr"));
                if (Math.Abs(l.MarLEmu) > 0.5) p.Add(new XAttribute("marL", Units.L(l.MarLEmu)));
                if (Math.Abs(l.IndentEmu) > 0.5) p.Add(new XAttribute("indent", Units.L(l.IndentEmu)));
                p.Add(new XAttribute("algn", string.IsNullOrEmpty(l.Align) ? "l" : l.Align));
                if (Math.Abs(l.LineSpacingPct - 100) > 0.5) p.Add(new XElement(A + "lnSpc", new XElement(A + "spcPct", new XAttribute("val", Units.L(l.LineSpacingPct * 1000)))));
                if (l.Bullet == null) p.Add(new XElement(A + "buNone"));
                else if (l.Bullet.Length > 0 && l.Bullet[0] == '\u0001') p.Add(new XElement(A + "buAutoNum", new XAttribute("type", l.Bullet.Substring(1))));
                else p.Add(new XElement(A + "buFont", new XAttribute("typeface", "Arial")), new XElement(A + "buChar", new XAttribute("char", l.Bullet)));
                var d = new XElement(A + "defRPr", new XAttribute("sz", Units.L(Units.Clamp(l.SizePt, 1, 4000) * 100)), new XAttribute("b", l.Bold ? "1" : "0"), new XAttribute("i", l.Italic ? "1" : "0"));
                if (l.Underline) d.Add(new XAttribute("u", "sng"));
                d.Add(new XElement(A + "solidFill", ColorXml(l.Color)));
                if (!string.IsNullOrEmpty(l.Font)) d.Add(new XElement(A + "latin", new XAttribute("typeface", l.Font)), new XElement(A + "cs", new XAttribute("typeface", l.Font)));
                p.Add(d);
                e.Add(p);
            }
            return e;
        }

        static string SanitizeText(string s)
        {
            var sb = new System.Text.StringBuilder(s.Length);
            foreach (var ch in s)
                if (ch == '\t' || ch >= 0x20 && ch != 0xFFFE && ch != 0xFFFF) sb.Append(ch);
            return sb.ToString();
        }

        static XElement RPrXml(RunModel r, Wc wc)
        {
            XElement e;
            if (r.OrigRPr != null) e = new XElement(r.OrigRPr);
            else e = new XElement(A + "rPr", new XAttribute("lang", "ru-RU"), new XAttribute("dirty", "0"));
            e.SetAttributeValue("sz", r.SizePt.HasValue ? (object)Units.L(Units.Clamp(r.SizePt.Value, 1, 4000) * 100) : null);
            e.SetAttributeValue("b", r.Bold.HasValue ? (r.Bold.Value ? "1" : "0") : null);
            e.SetAttributeValue("i", r.Italic.HasValue ? (r.Italic.Value ? "1" : "0") : null);
            e.SetAttributeValue("u", r.Underline.HasValue ? (r.Underline.Value ? "sng" : "none") : null);
            e.SetAttributeValue("strike", r.Strike.HasValue ? (r.Strike.Value ? "sngStrike" : "noStrike") : null);
            foreach (var f in e.Elements().Where(x => Array.IndexOf(FillNames, x.Name.LocalName) >= 0).ToList()) f.Remove();
            if (r.Color.HasValue) InsertOrdered(e, new XElement(A + "solidFill", ColorXml(r.Color.Value)), RPrOrder);
            var latin = e.Element(A + "latin");
            if (r.Font != null)
            {
                var raw = (string)latin?.Attribute("typeface");
                bool keepRaw = raw != null && raw.StartsWith("+", StringComparison.Ordinal) && Dml.ResolveFont(raw, wc.Pres.Theme) == r.Font;
                if (!keepRaw)
                {
                    if (latin == null) { latin = new XElement(A + "latin"); InsertOrdered(e, latin, RPrOrder); }
                    latin.SetAttributeValue("typeface", r.Font);
                    var cs = e.Element(A + "cs"); if (cs == null) InsertOrdered(e, new XElement(A + "cs", new XAttribute("typeface", r.Font)), RPrOrder); else cs.SetAttributeValue("typeface", r.Font);
                }
            }
            else latin?.Remove();
            // ссылки: проверяем, что идентификатор связи существует в этом слайде
            foreach (var h in e.Elements().Where(x => x.Name.LocalName == "hlinkClick" || x.Name.LocalName == "hlinkMouseOver").ToList())
            {
                var id = (string)h.Attribute(R + "id");
                if (!string.IsNullOrEmpty(id) && !wc.Rels.Any(x => x.Id == id)) h.Remove();
            }
            return e;
        }

        // ---------------- Таблица ----------------
        static XElement TableXml(TableModel t, XElement origTblPr, Wc wc)
        {
            var tblPr = origTblPr != null ? new XElement(origTblPr) : new XElement(A + "tblPr", new XElement(A + "tableStyleId", "{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"));
            tblPr.SetAttributeValue("firstRow", t.FirstRow ? "1" : null);
            tblPr.SetAttributeValue("bandRow", t.BandRow ? "1" : null);
            var tbl = new XElement(A + "tbl", tblPr);
            var grid = new XElement(A + "tblGrid");
            foreach (var w in t.ColWidths) grid.Add(new XElement(A + "gridCol", new XAttribute("w", Units.L(Math.Max(1, w)))));
            tbl.Add(grid);
            for (int ri = 0; ri < t.Rows.Count; ri++)
            {
                var tr = new XElement(A + "tr", new XAttribute("h", Units.L(ri < t.RowHeights.Count ? t.RowHeights[ri] : 370840)));
                for (int ci = 0; ci < t.ColWidths.Count; ci++)
                {
                    var c = ci < t.Rows[ri].Count ? t.Rows[ri][ci] : new TableCell();
                    var tc = new XElement(A + "tc");
                    if (c.GridSpan > 1) tc.Add(new XAttribute("gridSpan", c.GridSpan));
                    if (c.RowSpan > 1) tc.Add(new XAttribute("rowSpan", c.RowSpan));
                    if (c.HMerge) tc.Add(new XAttribute("hMerge", "1"));
                    if (c.VMerge) tc.Add(new XAttribute("vMerge", "1"));
                    var txb = new XElement(A + "txBody", new XElement(A + "bodyPr"), new XElement(A + "lstStyle"));
                    foreach (var p in c.Text.Paras) txb.Add(ParaXml(p, wc));
                    if (!txb.Elements(A + "p").Any()) txb.Add(new XElement(A + "p"));
                    tc.Add(txb);
                    var tcPr = new XElement(A + "tcPr", new XAttribute("marL", Units.L(c.Text.LIns)), new XAttribute("marR", Units.L(c.Text.RIns)),
                        new XAttribute("marT", Units.L(c.Text.TIns)), new XAttribute("marB", Units.L(c.Text.BIns)));
                    if (c.Text.Anchor != "t") tcPr.Add(new XAttribute("anchor", c.Text.Anchor));
                    void B(string n, LineDef l) { if (l != null) { var x = LineXml(l); x.Name = A + n; tcPr.Add(x); } }
                    B("lnL", c.BorderL); B("lnR", c.BorderR); B("lnT", c.BorderT); B("lnB", c.BorderB);
                    if (c.Fill != null) tcPr.Add(FillXml(c.Fill, wc));
                    tc.Add(tcPr);
                    tr.Add(tc);
                }
                tbl.Add(tr);
            }
            return tbl;
        }

        // ---------------- Заметки ----------------
        static void PatchNotes(OpcPackage pkg, string notesPart, string text)
        {
            var doc = pkg.GetXml(notesPart);
            var tree = doc.Root.Element(P + "cSld")?.Element(P + "spTree");
            if (tree == null) return;
            var body = tree.Elements(P + "sp").FirstOrDefault(s => (string)s.Element(P + "nvSpPr")?.Element(P + "nvPr")?.Element(P + "ph")?.Attribute("type") == "body");
            if (body == null)
            {
                body = NotesBodySp(text, 3);
                tree.Add(body);
            }
            else
            {
                var tx = body.Element(P + "txBody");
                if (tx == null) { tx = new XElement(P + "txBody", new XElement(A + "bodyPr"), new XElement(A + "lstStyle")); body.Add(tx); }
                foreach (var p in tx.Elements(A + "p").ToList()) p.Remove();
                foreach (var p in NotesParas(text)) tx.Add(p);
            }
            pkg.SetXml(notesPart, doc);
        }

        static IEnumerable<XElement> NotesParas(string text)
        {
            foreach (var line in (text ?? "").Replace("\r\n", "\n").Split('\n'))
            {
                var p = new XElement(A + "p");
                if (line.Length > 0) p.Add(new XElement(A + "r", new XElement(A + "rPr", new XAttribute("lang", "ru-RU"), new XAttribute("dirty", "0")), new XElement(A + "t", SanitizeText(line))));
                p.Add(new XElement(A + "endParaRPr", new XAttribute("lang", "ru-RU"), new XAttribute("dirty", "0")));
                yield return p;
            }
        }

        static XElement NotesBodySp(string text, int id)
        {
            var tx = new XElement(P + "txBody", new XElement(A + "bodyPr"), new XElement(A + "lstStyle"));
            foreach (var p in NotesParas(text)) tx.Add(p);
            return new XElement(P + "sp",
                new XElement(P + "nvSpPr", new XElement(P + "cNvPr", new XAttribute("id", id), new XAttribute("name", "Заметки " + id)),
                    new XElement(P + "cNvSpPr", new XElement(A + "spLocks", new XAttribute("noGrp", "1"))),
                    new XElement(P + "nvPr", new XElement(P + "ph", new XAttribute("type", "body"), new XAttribute("idx", "1")))),
                new XElement(P + "spPr"), tx);
        }

        static XDocument NewNotesDoc(string text)
        {
            return new XDocument(new XDeclaration("1.0", "UTF-8", "yes"),
                new XElement(P + "notes",
                    new XAttribute(XNamespace.Xmlns + "a", A.NamespaceName), new XAttribute(XNamespace.Xmlns + "r", R.NamespaceName), new XAttribute(XNamespace.Xmlns + "p", P.NamespaceName),
                    new XElement(P + "cSld", new XElement(P + "spTree", GroupNv(1, ""), new XElement(P + "grpSpPr"),
                        new XElement(P + "sp",
                            new XElement(P + "nvSpPr", new XElement(P + "cNvPr", new XAttribute("id", 2), new XAttribute("name", "Образ слайда 1")),
                                new XElement(P + "cNvSpPr", new XElement(A + "spLocks", new XAttribute("noGrp", "1"), new XAttribute("noRot", "1"), new XAttribute("noChangeAspect", "1"))),
                                new XElement(P + "nvPr", new XElement(P + "ph", new XAttribute("type", "sldImg")))),
                            new XElement(P + "spPr")),
                        NotesBodySp(text, 3))),
                    new XElement(P + "clrMapOvr", new XElement(A + "masterClrMapping"))));
        }

        static string EnsureNotesMaster(OpcPackage pkg, string presPart, XDocument presDoc, List<Rel> presRels)
        {
            var existing = presRels.FirstOrDefault(r => r.Type == Rt.NotesMaster);
            if (existing != null)
            {
                var p = OpcPackage.ResolveTarget(presPart, existing.Target);
                if (pkg.Has(p)) return p;
            }
            var nm = pkg.UniquePartName("/ppt/notesMasters/", "notesMaster", "xml");
            var theme = pkg.UniquePartName("/ppt/theme/", "theme", "xml");
            pkg.SetXml(theme, Template.ThemeDoc("Тема заметок"), ContentTypes.Theme);
            pkg.SetXml(nm, Template.NotesMasterDoc(), ContentTypes.NotesMaster);
            pkg.SetRels(nm, new List<Rel> { new Rel { Id = "rId1", Type = Rt.Theme, Target = OpcPackage.RelativeTarget(nm, theme) } });
            var rid = OpcPackage.NewRelId(presRels);
            presRels.Add(new Rel { Id = rid, Type = Rt.NotesMaster, Target = OpcPackage.RelativeTarget(presPart, nm) });
            var root = presDoc.Root;
            root.Element(P + "notesMasterIdLst")?.Remove();
            var lst = new XElement(P + "notesMasterIdLst", new XElement(P + "notesMasterId", new XAttribute(R + "id", rid)));
            var after = root.Element(P + "sldMasterIdLst");
            if (after != null) after.AddAfterSelf(lst); else root.AddFirst(lst);
            return nm;
        }

        // ---------------- Свойства документа ----------------
        static void WriteCore(OpcPackage pkg, PresentationModel pres, SaveOptions opt)
        {
            var rels = pkg.GetRels("/");
            var coreRel = rels.FirstOrDefault(r => r.Type == Rt.CoreProps);
            string part = coreRel != null ? OpcPackage.ResolveTarget("/", coreRel.Target) : "/docProps/core.xml";
            XDocument doc = null;
            try { doc = pkg.GetXml(part); } catch { }
            if (doc == null)
            {
                doc = new XDocument(new XElement(Ns.CP + "coreProperties",
                    new XAttribute(XNamespace.Xmlns + "cp", Ns.CP.NamespaceName), new XAttribute(XNamespace.Xmlns + "dc", Ns.DC.NamespaceName),
                    new XAttribute(XNamespace.Xmlns + "dcterms", Ns.DCT.NamespaceName), new XAttribute(XNamespace.Xmlns + "xsi", Ns.XSI.NamespaceName)));
            }
            var root = doc.Root;
            void Set(XNamespace ns, string n, string v, bool w3cdtf = false)
            {
                var e = root.Element(ns + n);
                if (v == null) return;
                if (e == null) { e = new XElement(ns + n); if (w3cdtf) e.Add(new XAttribute(Ns.XSI + "type", "dcterms:W3CDTF")); root.Add(e); }
                e.Value = v;
            }
            var info = pres.Info;
            Set(Ns.DC, "title", info.Title); Set(Ns.DC, "subject", info.Subject); Set(Ns.DC, "creator", info.Creator);
            Set(Ns.CP, "keywords", info.Keywords); Set(Ns.DC, "description", info.Description); Set(Ns.CP, "category", info.Category);
            Set(Ns.CP, "lastModifiedBy", opt.UserName);
            int rev; int.TryParse(info.Revision, NumberStyles.Integer, CultureInfo.InvariantCulture, out rev);
            info.Revision = (rev + 1).ToString(CultureInfo.InvariantCulture);
            Set(Ns.CP, "revision", info.Revision);
            var now = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
            if (string.IsNullOrEmpty(info.Created)) { info.Created = now; Set(Ns.DCT, "created", now, true); }
            info.Modified = now; Set(Ns.DCT, "modified", now, true);
            info.LastModifiedBy = opt.UserName;
            pkg.SetXml(part, doc, ContentTypes.Core);
            if (coreRel == null) { rels.Add(new Rel { Id = OpcPackage.NewRelId(rels), Type = Rt.CoreProps, Target = "docProps/core.xml" }); pkg.SetRels("/", rels); }
        }
    }
}
