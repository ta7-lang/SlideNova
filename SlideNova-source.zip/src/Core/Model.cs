// SlideNova — общая модель презентации (используется приложением и обработчиком эскизов).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public struct Rgba : IEquatable<Rgba>
    {
        public byte A, R, G, B;
        public Rgba(byte a, byte r, byte g, byte b) { A = a; R = r; G = g; B = b; }
        public static Rgba FromRgb(int rgb) => new Rgba(255, (byte)(rgb >> 16), (byte)(rgb >> 8), (byte)rgb);
        public static readonly Rgba Black = new Rgba(255, 0, 0, 0);
        public static readonly Rgba White = new Rgba(255, 255, 255, 255);
        public static readonly Rgba Transparent = new Rgba(0, 255, 255, 255);
        public string Hex => R.ToString("X2") + G.ToString("X2") + B.ToString("X2");
        public bool Equals(Rgba o) => A == o.A && R == o.R && G == o.G && B == o.B;
        public override bool Equals(object obj) => obj is Rgba r && Equals(r);
        public override int GetHashCode() => (A << 24) | (R << 16) | (G << 8) | B;
        public override string ToString() => "#" + (A != 255 ? A.ToString("X2") : "") + Hex;
        public static bool TryParseHex(string s, out Rgba c)
        {
            c = Black;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim().TrimStart('#');
            if (s.Length != 6 && s.Length != 8) return false;
            if (!uint.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out uint v)) return false;
            if (s.Length == 6) c = new Rgba(255, (byte)(v >> 16), (byte)(v >> 8), (byte)v);
            else c = new Rgba((byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v);
            return true;
        }
        public Rgba WithAlpha(byte a) => new Rgba(a, R, G, B);
        public double Luminance => (0.2126 * R + 0.7152 * G + 0.0722 * B) / 255.0;
    }

    public enum FillKind { None, Solid, Gradient, Image }

    public sealed class GradStop
    {
        public double Pos; // 0..1
        public Rgba Color;
        public GradStop() { }
        public GradStop(double p, Rgba c) { Pos = p; Color = c; }
    }

    public sealed class FillDef
    {
        public FillKind Kind = FillKind.None;
        public Rgba Color = Rgba.White;
        public List<GradStop> Stops = new List<GradStop>();
        public double Angle;      // градусы, 0 = слева направо
        public bool Radial;
        public string ImageKey;   // ключ в Media
        public bool Tile;
        public static FillDef NoFill() => new FillDef { Kind = FillKind.None };
        public static FillDef Solid(Rgba c) => new FillDef { Kind = FillKind.Solid, Color = c };
        public static FillDef Gradient(Rgba a, Rgba b, double angle, bool radial = false)
        {
            var f = new FillDef { Kind = FillKind.Gradient, Angle = angle, Radial = radial };
            f.Stops.Add(new GradStop(0, a)); f.Stops.Add(new GradStop(1, b));
            return f;
        }
        public FillDef Clone()
        {
            var f = (FillDef)MemberwiseClone();
            f.Stops = Stops.Select(s => new GradStop(s.Pos, s.Color)).ToList();
            return f;
        }
        public Rgba Representative => Kind == FillKind.Solid ? Color : Kind == FillKind.Gradient && Stops.Count > 0 ? Stops[0].Color : Rgba.White;
    }

    public sealed class LineDef
    {
        public bool Visible = true;
        public Rgba Color = Rgba.Black;
        public double WidthEmu = 12700;
        public string Dash = "solid";
        public string HeadEnd = "none";
        public string TailEnd = "none";
        public LineDef Clone() => (LineDef)MemberwiseClone();
        public static LineDef None() => new LineDef { Visible = false };
    }

    /// <summary>Унаследованный стиль уровня текста (результат разрешения наследования).</summary>
    public sealed class LevelStyle
    {
        public double SizePt = 18;
        public bool Bold, Italic, Underline, Strike;
        public Rgba Color = Rgba.Black;
        public string Font = "Calibri";
        public string Align = "l";
        public string Bullet;          // null = нет маркера
        public string BulletFont;
        public double MarLEmu, IndentEmu;
        public double LineSpacingPct = 100;
        public double SpaceBeforePt, SpaceAfterPt;
        public LevelStyle Clone() => (LevelStyle)MemberwiseClone();
    }

    public sealed class RunModel
    {
        public string Text = "";
        public bool IsBreak;
        public double? SizePt;
        public bool? Bold, Italic, Underline, Strike;
        public Rgba? Color;
        public string Font;
        public string Hyperlink;          // внешняя ссылка (только для показа)
        public XElement OrigRPr;          // исходные свойства для сохранения без потерь
        public RunModel Clone()
        {
            var r = (RunModel)MemberwiseClone();
            return r;
        }
    }

    public sealed class ParaModel
    {
        public List<RunModel> Runs = new List<RunModel>();
        public string Align;              // null = наследовать
        public int Level;
        public string Bullet;             // null = наследовать, "" = без маркера
        public double? LineSpacingPct;
        public double? SpaceBeforePt, SpaceAfterPt;
        public double? EndSizePt;
        public XElement OrigPPr;
        public ParaModel Clone()
        {
            var p = (ParaModel)MemberwiseClone();
            p.Runs = Runs.Select(r => r.Clone()).ToList();
            return p;
        }
        public string PlainText => string.Concat(Runs.Select(r => r.IsBreak ? "\n" : r.Text));
    }

    public sealed class TextBodyModel
    {
        public List<ParaModel> Paras = new List<ParaModel>();
        public double LIns = 91440, TIns = 45720, RIns = 91440, BIns = 45720;
        public string Anchor = "t";
        public bool Wrap = true;
        public double FontScale = 1.0;
        public double LnSpcReduction;
        public string Vert = "horz";
        public bool AutoFitShape;
        public LevelStyle[] Levels = DefaultLevels();
        public static LevelStyle[] DefaultLevels()
        {
            var a = new LevelStyle[9];
            for (int i = 0; i < 9; i++) a[i] = new LevelStyle();
            return a;
        }
        public TextBodyModel Clone()
        {
            var t = (TextBodyModel)MemberwiseClone();
            t.Paras = Paras.Select(p => p.Clone()).ToList();
            t.Levels = Levels.Select(l => l.Clone()).ToArray();
            return t;
        }
        public string PlainText => string.Join("\n", Paras.Select(p => p.PlainText));
        public bool IsEmpty => Paras.All(p => p.Runs.All(r => r.IsBreak || string.IsNullOrEmpty(r.Text)));
        public LevelStyle Lvl(int level) => Levels[Math.Max(0, Math.Min(8, level))];

        // Эффективные значения
        public double EffSize(ParaModel p, RunModel r) => (r?.SizePt ?? Lvl(p.Level).SizePt);
        public bool EffBold(ParaModel p, RunModel r) => r?.Bold ?? Lvl(p.Level).Bold;
        public bool EffItalic(ParaModel p, RunModel r) => r?.Italic ?? Lvl(p.Level).Italic;
        public bool EffUnderline(ParaModel p, RunModel r) => r?.Underline ?? Lvl(p.Level).Underline;
        public bool EffStrike(ParaModel p, RunModel r) => r?.Strike ?? Lvl(p.Level).Strike;
        public Rgba EffColor(ParaModel p, RunModel r) => r?.Color ?? Lvl(p.Level).Color;
        public string EffFont(ParaModel p, RunModel r) => r?.Font ?? Lvl(p.Level).Font;
        public string EffAlign(ParaModel p) => p.Align ?? Lvl(p.Level).Align;
        public string EffBullet(ParaModel p) => p.Bullet == null ? Lvl(p.Level).Bullet : (p.Bullet.Length == 0 ? null : p.Bullet);
        public double EffLineSpacing(ParaModel p) => p.LineSpacingPct ?? Lvl(p.Level).LineSpacingPct;
        public double EffSpaceBefore(ParaModel p) => p.SpaceBeforePt ?? Lvl(p.Level).SpaceBeforePt;
        public double EffSpaceAfter(ParaModel p) => p.SpaceAfterPt ?? Lvl(p.Level).SpaceAfterPt;

        public static TextBodyModel FromPlain(string text, LevelStyle baseStyle = null)
        {
            var t = new TextBodyModel();
            if (baseStyle != null) for (int i = 0; i < 9; i++) t.Levels[i] = baseStyle.Clone();
            foreach (var line in (text ?? "").Replace("\r\n", "\n").Split('\n'))
            {
                var p = new ParaModel();
                p.Runs.Add(new RunModel { Text = line });
                t.Paras.Add(p);
            }
            return t;
        }
    }

    public sealed class TableCell
    {
        public TextBodyModel Text = new TextBodyModel();
        public FillDef Fill;              // null = по стилю таблицы
        public LineDef BorderL, BorderR, BorderT, BorderB;
        public int GridSpan = 1, RowSpan = 1;
        public bool HMerge, VMerge;
        public TableCell Clone()
        {
            var c = (TableCell)MemberwiseClone();
            c.Text = Text.Clone(); c.Fill = Fill?.Clone();
            c.BorderL = BorderL?.Clone(); c.BorderR = BorderR?.Clone(); c.BorderT = BorderT?.Clone(); c.BorderB = BorderB?.Clone();
            return c;
        }
    }

    public sealed class TableModel
    {
        public List<double> ColWidths = new List<double>();
        public List<double> RowHeights = new List<double>();
        public List<List<TableCell>> Rows = new List<List<TableCell>>();
        public bool FirstRow = true, BandRow = true;
        public Rgba StyleAccent = Rgba.FromRgb(0x4472C4);
        public TableModel Clone()
        {
            var t = (TableModel)MemberwiseClone();
            t.ColWidths = ColWidths.ToList(); t.RowHeights = RowHeights.ToList();
            t.Rows = Rows.Select(r => r.Select(c => c.Clone()).ToList()).ToList();
            return t;
        }
    }

    public enum ShapeKind { Shape, Picture, Table, Group, Graphic, Connector }

    public sealed class PathCmd
    {
        public char Type;       // M, L, C, Z
        public double[] P;      // координаты (абсолютные в системе фигуры)
        public PathCmd(char t, params double[] p) { Type = t; P = p; }
    }

    public sealed class GeoPath
    {
        public List<PathCmd> Cmds = new List<PathCmd>();
        public bool Filled = true, Stroked = true, EvenOdd;
        public double ShadeFactor = 1.0; // darken / lighten
    }

    public sealed class ShapeModel
    {
        public int Id;
        public string Name = "";
        public ShapeKind Kind = ShapeKind.Shape;
        public double X, Y, W, H;        // EMU
        public double Rot;               // градусы
        public bool FlipH, FlipV;
        public string Geometry = "rect";
        public Dictionary<string, double> Adj = new Dictionary<string, double>();
        public List<GeoPath> CustomPaths; // в координатах [0..CustW]x[0..CustH] (EMU), масштабируются к W×H
        public double CustW = 1, CustH = 1;
        public FillDef Fill = FillDef.NoFill();
        public LineDef Line = LineDef.None();
        public TextBodyModel Text;
        public string ImageKey;
        public double CropL, CropT, CropR, CropB; // доли 0..1
        public TableModel Table;
        public List<ShapeModel> Children;
        public double ChX, ChY, ChW, ChH;
        public string GraphicLabel;
        public string PlaceholderType;
        public string PlaceholderIdx;
        public bool IsTextBox;
        public string Hyperlink;
        public bool Locked;              // фигуры макета/образца (не редактируются)
        public string AltText;

        // Для сохранения без потерь
        public XElement Original;
        public bool DirtyXfrm, DirtyGeom, DirtyFill, DirtyLine, DirtyText, DirtyImage, DirtyTable;
        public string OrigImageRelId;

        public bool IsDirty => DirtyXfrm || DirtyGeom || DirtyFill || DirtyLine || DirtyText || DirtyImage || DirtyTable;

        public ShapeModel Clone()
        {
            var s = (ShapeModel)MemberwiseClone();
            s.Adj = new Dictionary<string, double>(Adj);
            s.CustomPaths = CustomPaths; // неизменяемые
            s.Fill = Fill?.Clone(); s.Line = Line?.Clone(); s.Text = Text?.Clone();
            s.Table = Table?.Clone();
            s.Children = Children?.Select(c => c.Clone()).ToList();
            return s;
        }

        /// <summary>Отвязать фигуру от исходного XML (при вставке в другой слайд/файл).</summary>
        public void Detach()
        {
            Original = null; OrigImageRelId = null;
            DirtyXfrm = DirtyGeom = DirtyFill = DirtyLine = DirtyText = DirtyImage = DirtyTable = true;
            if (Text != null) foreach (var p in Text.Paras) { p.OrigPPr = null; foreach (var r in p.Runs) r.OrigRPr = null; }
            if (Table != null) foreach (var row in Table.Rows) foreach (var c in row) foreach (var p in c.Text.Paras) { p.OrigPPr = null; foreach (var r in p.Runs) r.OrigRPr = null; }
            if (Children != null) foreach (var c in Children) c.Detach();
        }

        public bool CanDetach => Kind != ShapeKind.Graphic && (Children == null || Children.All(c => c.CanDetach));

        public string KindName
        {
            get
            {
                switch (Kind)
                {
                    case ShapeKind.Picture: return "Рисунок";
                    case ShapeKind.Table: return "Таблица";
                    case ShapeKind.Group: return "Группа";
                    case ShapeKind.Graphic: return GraphicLabel ?? "Объект";
                    case ShapeKind.Connector: return "Линия";
                    default:
                        if (PlaceholderType != null) return "Заполнитель (" + PlaceholderType + ")";
                        return IsTextBox ? "Надпись" : "Фигура (" + Geometry + ")";
                }
            }
        }
    }

    public sealed class SlideModel
    {
        public List<ShapeModel> Shapes = new List<ShapeModel>();
        public List<ShapeModel> MasterShapes = new List<ShapeModel>();
        public FillDef Background = FillDef.Solid(Rgba.White);
        public bool BackgroundDirty;
        public string Notes = "";
        public bool NotesDirty;
        public bool Hidden;
        public bool HiddenDirty;
        public string PartName;           // исходная часть пакета
        public string RelsSource;         // часть, rels которой копировать (для дубликатов)
        public string LayoutPart;
        public string LayoutName;
        public string NotesPartName;
        public uint OrigSldId;
        public string OrigPresRelId;
        public Rgba HyperlinkColor = Rgba.FromRgb(0x0563C1);
        public TextBodyModel TitleTemplate, BodyTemplate; // для новых заполнителей

        public SlideModel Clone()
        {
            var s = (SlideModel)MemberwiseClone();
            s.Shapes = Shapes.Select(x => x.Clone()).ToList();
            s.MasterShapes = MasterShapes; // только для чтения
            s.Background = Background?.Clone();
            return s;
        }

        public string Title
        {
            get
            {
                var t = Shapes.FirstOrDefault(s => (s.PlaceholderType == "title" || s.PlaceholderType == "ctrTitle") && s.Text != null && !s.Text.IsEmpty)
                        ?? Shapes.FirstOrDefault(s => s.Text != null && !s.Text.IsEmpty);
                var txt = t?.Text?.PlainText?.Replace("\n", " ").Trim() ?? "";
                return txt.Length > 80 ? txt.Substring(0, 80) + "…" : txt;
            }
        }

        public int NextShapeId()
        {
            int max = 1;
            void Walk(IEnumerable<ShapeModel> list) { foreach (var s in list) { if (s.Id > max) max = s.Id; if (s.Children != null) Walk(s.Children); } }
            Walk(Shapes);
            return max + 1;
        }
    }

    public sealed class MediaItem
    {
        public byte[] Data;
        public string ContentType;
        public string Ext;
        public string PartName;  // null = новая (будет добавлена при сохранении)
    }

    public sealed class DocInfo
    {
        public string Title = "", Subject = "", Creator = "", Keywords = "", Description = "", Category = "";
        public string LastModifiedBy = "", Revision = "", Created = "", Modified = "", ContentStatus = "", Language = "";
        public string Application = "", AppVersion = "", Company = "", Manager = "", Template = "", TotalTime = "";
        public string Words = "", Paragraphs = "", PresentationFormat = "";
        public bool Dirty;
        public DocInfo Clone() => (DocInfo)MemberwiseClone();
    }

    public sealed class ThemeInfo
    {
        public string Name = "";
        public Dictionary<string, Rgba> Colors = new Dictionary<string, Rgba>();
        public string MajorFont = "Calibri Light", MinorFont = "Calibri";
    }

    public sealed class SecurityFindings
    {
        public bool HasMacros, HasActiveX, HasSignature, Encrypted, HasEmbeddedFonts, HasComments, HasCustomXml;
        public List<string> OleObjects = new List<string>();
        public List<string> ExternalLinks = new List<string>();
        public List<string> Hyperlinks = new List<string>();
        public List<string> Notes = new List<string>();
        public List<string> RemovedOnSave = new List<string>();
    }

    public sealed class LayoutProto
    {
        public string Part, Name, Type;
        public List<ShapeModel> Placeholders = new List<ShapeModel>();
        public List<ShapeModel> Decor = new List<ShapeModel>();
        public FillDef Background = FillDef.Solid(Rgba.White);
        public Rgba Hlink = Rgba.FromRgb(0x0563C1);
    }

    public sealed class PresentationModel
    {
        public List<LayoutProto> Layouts = new List<LayoutProto>();
        public double SlideW = 12192000, SlideH = 6858000;
        public List<SlideModel> Slides = new List<SlideModel>();
        public Dictionary<string, MediaItem> Media = new Dictionary<string, MediaItem>(StringComparer.OrdinalIgnoreCase);
        public OpcPackage Package;
        public string SourceFormat = "new";
        public string MainContentType;
        public DocInfo Info = new DocInfo();
        public ThemeInfo Theme = new ThemeInfo();
        public List<string> Warnings = new List<string>();
        public SecurityFindings Security = new SecurityFindings();
        public string DefaultLayoutPart;
        public string TitleLayoutPart;
        public Dictionary<string, string> LayoutNames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public int MasterCount = 1;
        public bool SizeDirty;
        public List<string> CfbStreams = new List<string>();
        public LevelStyle DefaultTextStyle = new LevelStyle();

        private int _mediaCounter;
        public string AddMedia(byte[] data, string ext)
        {
            ext = (ext ?? "png").TrimStart('.').ToLowerInvariant();
            if (ext == "jpg") ext = "jpeg";
            string key;
            do { key = "new-media-" + (++_mediaCounter) + "." + ext; } while (Media.ContainsKey(key));
            Media[key] = new MediaItem { Data = data, Ext = ext, ContentType = ContentTypes.ForImageExt(ext) };
            return key;
        }
    }

    public static class Units
    {
        public const double EmuPerInch = 914400;
        public const double EmuPerPt = 12700;
        public const double EmuPerDip = 9525;
        public const double EmuPerCm = 360000;
        public static double Clamp(double v, double lo, double hi) => v < lo ? lo : v > hi ? hi : v;
        public static int Clamp(int v, int lo, int hi) => v < lo ? lo : v > hi ? hi : v;
        public static string Inv(double v) => v.ToString(CultureInfo.InvariantCulture);
        public static long L(double v) => (long)Math.Round(v);
    }

    public static class ContentTypes
    {
        public const string Slide = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml";
        public const string Notes = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml";
        public const string NotesMaster = "application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml";
        public const string Theme = "application/vnd.openxmlformats-officedocument.theme+xml";
        public const string MainPptx = "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml";
        public const string MainPpsx = "application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml";
        public const string MainPotx = "application/vnd.openxmlformats-officedocument.presentationml.template.main+xml";
        public const string MainPptm = "application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml";
        public const string MainPpsm = "application/vnd.ms-powerpoint.slideshow.macroEnabled.main+xml";
        public const string MainPotm = "application/vnd.ms-powerpoint.template.macroEnabled.main+xml";
        public const string Rels = "application/vnd.openxmlformats-package.relationships+xml";
        public const string Core = "application/vnd.openxmlformats-package.core-properties+xml";

        public static string ForImageExt(string ext)
        {
            switch ((ext ?? "").ToLowerInvariant())
            {
                case "png": return "image/png";
                case "jpg": case "jpeg": return "image/jpeg";
                case "gif": return "image/gif";
                case "bmp": return "image/bmp";
                case "tif": case "tiff": return "image/tiff";
                case "emf": return "image/x-emf";
                case "wmf": return "image/x-wmf";
                case "svg": return "image/svg+xml";
                case "ico": return "image/x-icon";
                default: return "application/octet-stream";
            }
        }
    }

    public static class Rt
    {
        public const string OfficeDoc = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
        public const string Slide = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide";
        public const string SlideLayout = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout";
        public const string SlideMaster = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster";
        public const string NotesSlide = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide";
        public const string NotesMaster = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesMaster";
        public const string Theme = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme";
        public const string Image = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image";
        public const string Hyperlink = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink";
        public const string Vba = "http://schemas.microsoft.com/office/2006/relationships/vbaProject";
        public const string Thumbnail = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/thumbnail";
        public const string CoreProps = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties";
        public const string ExtProps = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties";
        public const string Ole = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject";
        public const string Package = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/package";
        public const string ActiveX = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/control";
        public const string Font = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font";
        public const string Comments = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments";
    }

    public static class Ns
    {
        public static readonly XNamespace A = "http://schemas.openxmlformats.org/drawingml/2006/main";
        public static readonly XNamespace P = "http://schemas.openxmlformats.org/presentationml/2006/main";
        public static readonly XNamespace R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        public static readonly XNamespace Mc = "http://schemas.openxmlformats.org/markup-compatibility/2006";
        public static readonly XNamespace PR = "http://schemas.openxmlformats.org/package/2006/relationships";
        public static readonly XNamespace CT = "http://schemas.openxmlformats.org/package/2006/content-types";
        public static readonly XNamespace CP = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties";
        public static readonly XNamespace DC = "http://purl.org/dc/elements/1.1/";
        public static readonly XNamespace DCT = "http://purl.org/dc/terms/";
        public static readonly XNamespace XSI = "http://www.w3.org/2001/XMLSchema-instance";
        public static readonly XNamespace EP = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties";
        public static readonly XNamespace P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main";
        public static readonly XNamespace Dgm = "http://schemas.openxmlformats.org/drawingml/2006/diagram";
        public static readonly XNamespace C = "http://schemas.openxmlformats.org/drawingml/2006/chart";
        public const string TableUri = "http://schemas.openxmlformats.org/drawingml/2006/table";
        public const string ChartUri = "http://schemas.openxmlformats.org/drawingml/2006/chart";
        public const string DgmUri = "http://schemas.openxmlformats.org/drawingml/2006/diagram";
        public const string OleUri = "http://schemas.openxmlformats.org/presentationml/2006/ole";
    }
}
