// Разбор цветов, заливок, линий и текстовых свойств DrawingML.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public sealed class ColorCtx
    {
        public Dictionary<string, Rgba> Scheme = new Dictionary<string, Rgba>();
        public Rgba? Ph;
        public ThemeInfo Theme;

        public ColorCtx WithPh(Rgba? ph)
        {
            return new ColorCtx { Scheme = Scheme, Ph = ph, Theme = Theme };
        }

        public static ColorCtx Build(ThemeInfo theme, XElement clrMap, XElement clrMapOvr = null)
        {
            var ctx = new ColorCtx { Theme = theme };
            foreach (var kv in theme.Colors) ctx.Scheme[kv.Key] = kv.Value;
            var map = clrMap;
            var ovr = clrMapOvr?.Element(Ns.A + "overrideClrMapping");
            if (ovr != null) map = ovr;
            string[] keys = { "bg1", "tx1", "bg2", "tx2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink" };
            string[] defs = { "lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink" };
            for (int i = 0; i < keys.Length; i++)
            {
                string target = (string)map?.Attribute(keys[i]) ?? defs[i];
                if (theme.Colors.TryGetValue(target, out var c)) ctx.Scheme[keys[i]] = c;
                else if (!ctx.Scheme.ContainsKey(keys[i])) ctx.Scheme[keys[i]] = i % 2 == 0 && i < 4 ? Rgba.White : Rgba.Black;
            }
            return ctx;
        }

        public Rgba Get(string key, Rgba fallback)
        {
            if (key == "phClr") return Ph ?? fallback;
            return Scheme.TryGetValue(key, out var c) ? c : fallback;
        }
    }

    public static class Dml
    {
        static readonly string[] ColorNames = { "srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr" };
        static readonly string[] FillNames = { "noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill" };

        public static double Attr(XElement e, string name, double def)
        {
            var a = e?.Attribute(name);
            if (a == null) return def;
            return double.TryParse(a.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : def;
        }

        public static bool? Bool(XElement e, string name)
        {
            var a = e?.Attribute(name);
            if (a == null) return null;
            return a.Value == "1" || a.Value.Equals("true", StringComparison.OrdinalIgnoreCase) || a.Value.Equals("on", StringComparison.OrdinalIgnoreCase);
        }

        public static XElement ColorChild(XElement parent)
        {
            if (parent == null) return null;
            return parent.Elements().FirstOrDefault(e => e.Name.Namespace == Ns.A && Array.IndexOf(ColorNames, e.Name.LocalName) >= 0);
        }

        public static Rgba? ParseColorIn(XElement parent, ColorCtx ctx) => ParseColor(ColorChild(parent), ctx);

        public static Rgba? ParseColor(XElement c, ColorCtx ctx)
        {
            if (c == null) return null;
            Rgba col;
            switch (c.Name.LocalName)
            {
                case "srgbClr":
                    if (!Rgba.TryParseHex((string)c.Attribute("val"), out col)) col = Rgba.Black;
                    break;
                case "schemeClr":
                    col = ctx != null ? ctx.Get((string)c.Attribute("val") ?? "tx1", Rgba.Black) : Rgba.Black;
                    break;
                case "sysClr":
                    {
                        var last = (string)c.Attribute("lastClr");
                        if (last == null || !Rgba.TryParseHex(last, out col))
                            col = ((string)c.Attribute("val") ?? "").StartsWith("window", StringComparison.Ordinal) && (string)c.Attribute("val") != "windowText" ? Rgba.White : Rgba.Black;
                        break;
                    }
                case "prstClr":
                    col = Preset((string)c.Attribute("val"));
                    break;
                case "scrgbClr":
                    {
                        double r = Attr(c, "r", 0) / 100000.0, g = Attr(c, "g", 0) / 100000.0, b = Attr(c, "b", 0) / 100000.0;
                        col = new Rgba(255, ToSrgb(r), ToSrgb(g), ToSrgb(b));
                        break;
                    }
                case "hslClr":
                    {
                        double h = Attr(c, "hue", 0) / 60000.0, s = Attr(c, "sat", 0) / 100000.0, l = Attr(c, "lum", 0) / 100000.0;
                        col = FromHsl(h, s, l, 255);
                        break;
                    }
                default: return null;
            }
            return ApplyTransforms(col, c);
        }

        static byte ToSrgb(double lin)
        {
            lin = Units.Clamp(lin, 0, 1);
            double v = lin <= 0.0031308 ? lin * 12.92 : 1.055 * Math.Pow(lin, 1 / 2.4) - 0.055;
            return (byte)Math.Round(v * 255);
        }

        static Rgba Preset(string name)
        {
            switch (name)
            {
                case "white": return Rgba.White;
                case "red": return Rgba.FromRgb(0xFF0000);
                case "green": return Rgba.FromRgb(0x008000);
                case "blue": return Rgba.FromRgb(0x0000FF);
                case "yellow": return Rgba.FromRgb(0xFFFF00);
                case "gray": case "grey": return Rgba.FromRgb(0x808080);
                case "lightGray": return Rgba.FromRgb(0xD3D3D3);
                case "darkGray": return Rgba.FromRgb(0xA9A9A9);
                case "orange": return Rgba.FromRgb(0xFFA500);
                case "purple": return Rgba.FromRgb(0x800080);
                case "cyan": return Rgba.FromRgb(0x00FFFF);
                case "magenta": return Rgba.FromRgb(0xFF00FF);
                case "navy": return Rgba.FromRgb(0x000080);
                case "silver": return Rgba.FromRgb(0xC0C0C0);
                default: return Rgba.Black;
            }
        }

        static Rgba ApplyTransforms(Rgba col, XElement c)
        {
            double r = col.R, g = col.G, b = col.B, a = col.A;
            foreach (var t in c.Elements())
            {
                double v = Attr(t, "val", 0) / 100000.0;
                switch (t.Name.LocalName)
                {
                    case "alpha": a = 255 * v; break;
                    case "alphaMod": a *= v; break;
                    case "alphaOff": a += 255 * v; break;
                    case "tint": r = 255 - (255 - r) * v; g = 255 - (255 - g) * v; b = 255 - (255 - b) * v; break;
                    case "shade": r *= v; g *= v; b *= v; break;
                    case "inv": r = 255 - r; g = 255 - g; b = 255 - b; break;
                    case "gray": { double y = 0.299 * r + 0.587 * g + 0.114 * b; r = g = b = y; break; }
                    case "lumMod":
                    case "lumOff":
                    case "satMod":
                    case "satOff":
                    case "hueOff":
                    case "hueMod":
                    case "lum":
                    case "sat":
                    case "hue":
                        {
                            ToHsl(r, g, b, out double hh, out double ss, out double ll);
                            switch (t.Name.LocalName)
                            {
                                case "lumMod": ll *= v; break;
                                case "lumOff": ll += v; break;
                                case "satMod": ss *= v; break;
                                case "satOff": ss += v; break;
                                case "hueOff": hh += Attr(t, "val", 0) / 60000.0; break;
                                case "hueMod": hh *= v; break;
                                case "lum": ll = v; break;
                                case "sat": ss = v; break;
                                case "hue": hh = Attr(t, "val", 0) / 60000.0; break;
                            }
                            var cc = FromHsl(hh, Units.Clamp(ss, 0, 1), Units.Clamp(ll, 0, 1), 255);
                            r = cc.R; g = cc.G; b = cc.B;
                            break;
                        }
                }
            }
            return new Rgba(B8(a), B8(r), B8(g), B8(b));
        }

        static byte B8(double v) => (byte)Math.Round(Units.Clamp(v, 0, 255));

        public static void ToHsl(double r, double g, double b, out double h, out double s, out double l)
        {
            r /= 255; g /= 255; b /= 255;
            double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
            l = (max + min) / 2;
            if (max == min) { h = 0; s = 0; return; }
            double d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            if (max == r) h = (g - b) / d + (g < b ? 6 : 0);
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
        }

        public static Rgba FromHsl(double h, double s, double l, byte a)
        {
            h = ((h % 360) + 360) % 360 / 360.0;
            double r, g, b;
            if (s == 0) r = g = b = l;
            else
            {
                double q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
                r = Hue(p, q, h + 1.0 / 3); g = Hue(p, q, h); b = Hue(p, q, h - 1.0 / 3);
            }
            return new Rgba(a, B8(r * 255), B8(g * 255), B8(b * 255));
        }
        static double Hue(double p, double q, double t)
        {
            if (t < 0) t += 1; if (t > 1) t -= 1;
            if (t < 1.0 / 6) return p + (q - p) * 6 * t;
            if (t < 0.5) return q;
            if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
            return p;
        }

        public static XElement FillChild(XElement parent)
        {
            if (parent == null) return null;
            return parent.Elements().FirstOrDefault(e => e.Name.Namespace == Ns.A && Array.IndexOf(FillNames, e.Name.LocalName) >= 0);
        }

        /// <summary>Возвращает null, если заливка не задана (наследуется).</summary>
        public static FillDef ParseFill(XElement parent, ColorCtx ctx, Func<string, string> relToKey)
        {
            var f = FillChild(parent);
            return f == null ? null : ParseFillElement(f, ctx, relToKey);
        }

        public static FillDef ParseFillElement(XElement f, ColorCtx ctx, Func<string, string> relToKey)
        {
            switch (f.Name.LocalName)
            {
                case "noFill": return FillDef.NoFill();
                case "solidFill": return FillDef.Solid(ParseColorIn(f, ctx) ?? Rgba.White);
                case "gradFill":
                    {
                        var g = new FillDef { Kind = FillKind.Gradient };
                        foreach (var gs in f.Element(Ns.A + "gsLst")?.Elements(Ns.A + "gs") ?? Enumerable.Empty<XElement>())
                            g.Stops.Add(new GradStop(Attr(gs, "pos", 0) / 100000.0, ParseColorIn(gs, ctx) ?? Rgba.White));
                        g.Stops = g.Stops.OrderBy(s => s.Pos).ToList();
                        if (g.Stops.Count == 0) return FillDef.Solid(Rgba.White);
                        if (g.Stops.Count == 1) return FillDef.Solid(g.Stops[0].Color);
                        var lin = f.Element(Ns.A + "lin");
                        var path = f.Element(Ns.A + "path");
                        if (lin != null) g.Angle = Attr(lin, "ang", 0) / 60000.0;
                        else if (path != null) g.Radial = true;
                        else g.Angle = 90;
                        return g;
                    }
                case "blipFill":
                    {
                        var blip = f.Element(Ns.A + "blip");
                        var rid = (string)blip?.Attribute(Ns.R + "embed");
                        var key = rid != null ? relToKey?.Invoke(rid) : null;
                        if (key == null) return FillDef.Solid(Rgba.FromRgb(0xD9D9D9));
                        return new FillDef { Kind = FillKind.Image, ImageKey = key, Tile = f.Element(Ns.A + "tile") != null };
                    }
                case "pattFill":
                    {
                        var fg = ParseColorIn(f.Element(Ns.A + "fgClr"), ctx) ?? Rgba.Black;
                        var bg = ParseColorIn(f.Element(Ns.A + "bgClr"), ctx) ?? Rgba.White;
                        // упрощение: смесь цветов узора
                        return FillDef.Solid(new Rgba(255, (byte)((fg.R + bg.R * 3) / 4), (byte)((fg.G + bg.G * 3) / 4), (byte)((fg.B + bg.B * 3) / 4)));
                    }
                case "grpFill": return null;
            }
            return null;
        }

        public static LineDef ParseLine(XElement ln, ColorCtx ctx, LineDef baseLine)
        {
            var l = baseLine?.Clone() ?? new LineDef { Visible = false };
            if (ln == null) return l;
            if (ln.Attribute("w") != null) l.WidthEmu = Attr(ln, "w", 12700);
            var fill = FillChild(ln);
            if (fill != null)
            {
                switch (fill.Name.LocalName)
                {
                    case "noFill": l.Visible = false; break;
                    case "solidFill": l.Visible = true; l.Color = ParseColorIn(fill, ctx) ?? Rgba.Black; break;
                    case "gradFill":
                        {
                            var gs = fill.Element(Ns.A + "gsLst")?.Elements(Ns.A + "gs").FirstOrDefault();
                            l.Visible = true; l.Color = ParseColorIn(gs, ctx) ?? Rgba.Black; break;
                        }
                    default: l.Visible = true; break;
                }
            }
            var dash = ln.Element(Ns.A + "prstDash");
            if (dash != null) l.Dash = (string)dash.Attribute("val") ?? "solid";
            var he = ln.Element(Ns.A + "headEnd"); if (he != null) l.HeadEnd = (string)he.Attribute("type") ?? "none";
            var te = ln.Element(Ns.A + "tailEnd"); if (te != null) l.TailEnd = (string)te.Attribute("type") ?? "none";
            return l;
        }

        public static string ResolveFont(string typeface, ThemeInfo theme)
        {
            if (string.IsNullOrEmpty(typeface)) return null;
            if (typeface.StartsWith("+mj", StringComparison.Ordinal)) return theme?.MajorFont ?? "Calibri Light";
            if (typeface.StartsWith("+mn", StringComparison.Ordinal)) return theme?.MinorFont ?? "Calibri";
            return typeface;
        }

        /// <summary>Применить a:defRPr / a:rPr к стилю уровня.</summary>
        public static void ApplyRPr(XElement rPr, LevelStyle lvl, ColorCtx ctx)
        {
            if (rPr == null) return;
            if (rPr.Attribute("sz") != null) lvl.SizePt = Attr(rPr, "sz", 1800) / 100.0;
            var b = Bool(rPr, "b"); if (b.HasValue) lvl.Bold = b.Value;
            var i = Bool(rPr, "i"); if (i.HasValue) lvl.Italic = i.Value;
            var u = (string)rPr.Attribute("u"); if (u != null) lvl.Underline = u != "none";
            var st = (string)rPr.Attribute("strike"); if (st != null) lvl.Strike = st != "noStrike";
            var c = ParseColorIn(rPr.Element(Ns.A + "solidFill"), ctx); if (c.HasValue) lvl.Color = c.Value;
            var gf = rPr.Element(Ns.A + "gradFill");
            if (gf != null && !c.HasValue) { var g0 = gf.Element(Ns.A + "gsLst")?.Elements(Ns.A + "gs").FirstOrDefault(); var cc = ParseColorIn(g0, ctx); if (cc.HasValue) lvl.Color = cc.Value; }
            var latin = (string)rPr.Element(Ns.A + "latin")?.Attribute("typeface");
            var f = ResolveFont(latin, ctx?.Theme); if (!string.IsNullOrEmpty(f)) lvl.Font = f;
        }

        public static void ApplyPPr(XElement pPr, LevelStyle lvl, ColorCtx ctx)
        {
            if (pPr == null) return;
            var algn = (string)pPr.Attribute("algn"); if (algn != null) lvl.Align = algn;
            if (pPr.Attribute("marL") != null) lvl.MarLEmu = Attr(pPr, "marL", 0);
            if (pPr.Attribute("indent") != null) lvl.IndentEmu = Attr(pPr, "indent", 0);
            var ls = pPr.Element(Ns.A + "lnSpc")?.Element(Ns.A + "spcPct"); if (ls != null) lvl.LineSpacingPct = Attr(ls, "val", 100000) / 1000.0;
            var sb = pPr.Element(Ns.A + "spcBef")?.Element(Ns.A + "spcPts"); if (sb != null) lvl.SpaceBeforePt = Attr(sb, "val", 0) / 100.0;
            var sa = pPr.Element(Ns.A + "spcAft")?.Element(Ns.A + "spcPts"); if (sa != null) lvl.SpaceAfterPt = Attr(sa, "val", 0) / 100.0;
            var bullet = ParseBullet(pPr);
            if (bullet != null) lvl.Bullet = bullet.Length == 0 ? null : bullet;
            var bf = (string)pPr.Element(Ns.A + "buFont")?.Attribute("typeface"); if (bf != null) lvl.BulletFont = bf;
            if (lvl.Bullet != null && lvl.BulletFont != null && lvl.Bullet.Length == 1 && lvl.Bullet[0] != '\u0001') lvl.Bullet = MapSymbol(lvl.Bullet, lvl.BulletFont);
            ApplyRPr(pPr.Element(Ns.A + "defRPr"), lvl, ctx);
        }

        /// <summary>null — не задано, "" — без маркера.</summary>
        public static string ParseBullet(XElement pPr)
        {
            if (pPr == null) return null;
            if (pPr.Element(Ns.A + "buNone") != null) return "";
            var ch = pPr.Element(Ns.A + "buChar");
            if (ch != null)
            {
                var c = (string)ch.Attribute("char") ?? "•";
                var bf = (string)pPr.Element(Ns.A + "buFont")?.Attribute("typeface");
                return MapSymbol(c, bf);
            }
            var an = pPr.Element(Ns.A + "buAutoNum");
            if (an != null) return "\u0001" + ((string)an.Attribute("type") ?? "arabicPeriod");
            if (pPr.Element(Ns.A + "buBlip") != null) return "•";
            return null;
        }

        public static string MapSymbol(string c, string font)
        {
            if (string.IsNullOrEmpty(c) || font == null) return c;
            bool wing = font.StartsWith("Wingdings", StringComparison.OrdinalIgnoreCase);
            bool sym = font.Equals("Symbol", StringComparison.OrdinalIgnoreCase);
            if (!wing && !sym) return c;
            int code = c[0];
            if (code >= 0xF000) code -= 0xF000;
            if (wing)
            {
                switch (code)
                {
                    case 0x6C: return "●";
                    case 0x6E: return "■";
                    case 0xA7: return "▪";
                    case 0x71: return "❑";
                    case 0x76: return "❖";
                    case 0xD8: return "➢";
                    case 0xFC: return "✓";
                    case 0xFB: return "✗";
                    case 0xE0: return "➔";
                    case 0xE8: return "➔";
                    case 0xA8: return "◆";
                    case 0x75: return "◆";
                    case 0x9F: return "•";
                    case 0x77: return "⬥";
                    default: return "•";
                }
            }
            if (code == 0xB7) return "•";
            return "•";
        }

        public static string AutoNumber(string scheme, int n)
        {
            scheme = scheme ?? "arabicPeriod";
            string core;
            if (scheme.StartsWith("alphaLc", StringComparison.Ordinal)) core = Alpha(n).ToLowerInvariant();
            else if (scheme.StartsWith("alphaUc", StringComparison.Ordinal)) core = Alpha(n);
            else if (scheme.StartsWith("romanLc", StringComparison.Ordinal)) core = Roman(n).ToLowerInvariant();
            else if (scheme.StartsWith("romanUc", StringComparison.Ordinal)) core = Roman(n);
            else core = n.ToString(CultureInfo.InvariantCulture);
            if (scheme.EndsWith("ParenBoth", StringComparison.Ordinal)) return "(" + core + ")";
            if (scheme.EndsWith("ParenR", StringComparison.Ordinal)) return core + ")";
            if (scheme.EndsWith("Plain", StringComparison.Ordinal)) return core;
            return core + ".";
        }
        static string Alpha(int n) { string s = ""; while (n > 0) { n--; s = (char)('A' + n % 26) + s; n /= 26; } return s; }
        static string Roman(int n)
        {
            int[] v = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
            string[] r = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < v.Length; i++) while (n >= v[i]) { sb.Append(r[i]); n -= v[i]; }
            return sb.ToString();
        }

        /// <summary>Разбор пользовательской геометрии a:custGeom → контуры в координатах фигуры.</summary>
        public static List<GeoPath> ParseCustGeom(XElement cust, double w, double h)
        {
            var res = new List<GeoPath>();
            var lst = cust?.Element(Ns.A + "pathLst");
            if (lst == null) return res;
            var guides = new Dictionary<string, double>();
            foreach (var gd in cust.Element(Ns.A + "gdLst")?.Elements(Ns.A + "gd") ?? Enumerable.Empty<XElement>())
            {
                var f = ((string)gd.Attribute("fmla") ?? "").Split(' ');
                if (f.Length == 2 && f[0] == "val" && double.TryParse(f[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                    guides[(string)gd.Attribute("name") ?? ""] = v;
            }
            Func<XElement, string, double> V = (e, n) =>
            {
                var s = (string)e.Attribute(n);
                if (s == null) return 0;
                if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) return d;
                if (guides.TryGetValue(s, out d)) return d;
                switch (s) { case "w": return w; case "h": return h; case "l": case "t": return 0; case "r": return w; case "b": return h; case "hc": return w / 2; case "vc": return h / 2; }
                return 0;
            };
            int count = 0;
            foreach (var path in lst.Elements(Ns.A + "path"))
            {
                if (++count > 512) break;
                double pw = Attr(path, "w", 0), ph = Attr(path, "h", 0);
                double sx = pw > 0 ? w / pw : 1, sy = ph > 0 ? h / ph : 1;
                var gp = new GeoPath();
                var fillAttr = (string)path.Attribute("fill");
                if (fillAttr == "none") gp.Filled = false;
                else if (fillAttr == "darken" || fillAttr == "darkenLess") gp.ShadeFactor = fillAttr == "darken" ? 0.6 : 0.8;
                else if (fillAttr == "lighten" || fillAttr == "lightenLess") gp.ShadeFactor = fillAttr == "lighten" ? 1.4 : 1.2;
                if ((string)path.Attribute("stroke") == "0" || (string)path.Attribute("stroke") == "false") gp.Stroked = false;
                double cx = 0, cy = 0;
                int n = 0;
                foreach (var c in path.Elements())
                {
                    if (++n > 100000) break;
                    var pts = c.Elements(Ns.A + "pt").ToList();
                    switch (c.Name.LocalName)
                    {
                        case "moveTo":
                            if (pts.Count > 0) { cx = V(pts[0], "x") * sx; cy = V(pts[0], "y") * sy; gp.Cmds.Add(new PathCmd('M', cx, cy)); }
                            break;
                        case "lnTo":
                            if (pts.Count > 0) { cx = V(pts[0], "x") * sx; cy = V(pts[0], "y") * sy; gp.Cmds.Add(new PathCmd('L', cx, cy)); }
                            break;
                        case "cubicBezTo":
                            if (pts.Count >= 3)
                            {
                                gp.Cmds.Add(new PathCmd('C', V(pts[0], "x") * sx, V(pts[0], "y") * sy, V(pts[1], "x") * sx, V(pts[1], "y") * sy, V(pts[2], "x") * sx, V(pts[2], "y") * sy));
                                cx = V(pts[2], "x") * sx; cy = V(pts[2], "y") * sy;
                            }
                            break;
                        case "quadBezTo":
                            if (pts.Count >= 2)
                            {
                                double qx = V(pts[0], "x") * sx, qy = V(pts[0], "y") * sy, ex = V(pts[1], "x") * sx, ey = V(pts[1], "y") * sy;
                                gp.Cmds.Add(new PathCmd('C', cx + 2.0 / 3 * (qx - cx), cy + 2.0 / 3 * (qy - cy), ex + 2.0 / 3 * (qx - ex), ey + 2.0 / 3 * (qy - ey), ex, ey));
                                cx = ex; cy = ey;
                            }
                            break;
                        case "arcTo":
                            {
                                double wr = V(c, "wR") * sx, hr = V(c, "hR") * sy, st = V(c, "stAng") / 60000.0, sw = V(c, "swAng") / 60000.0;
                                int before = gp.Cmds.Count;
                                PresetGeometry.ArcTo(gp, cx, cy, wr, hr, st, sw);
                                if (gp.Cmds.Count > before) { var last = gp.Cmds[gp.Cmds.Count - 1]; cx = last.P[4]; cy = last.P[5]; }
                                break;
                            }
                        case "close": gp.Cmds.Add(new PathCmd('Z')); break;
                    }
                }
                res.Add(gp);
            }
            return res;
        }
    }
}
