// Безопасное чтение/запись OPC-пакетов (pptx) полностью в памяти — без временных файлов.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public class UnsafeFileException : Exception
    {
        public UnsafeFileException(string msg) : base(msg) { }
    }

    public static class Limits
    {
        public static long MaxFileBytes = 1024L * 1024 * 1024;     // 1 ГБ
        public const long MaxPartBytes = 512L * 1024 * 1024;       // одна часть пакета
        public const long MaxTotalUncompressed = 2048L * 1024 * 1024;
        public const int MaxEntries = 20000;
        public const double MaxRatio = 1000;                       // защита от zip-бомб
        public const int MaxSlides = 5000;
        public const int MaxShapesPerSlide = 20000;
        public const int MaxNesting = 64;
        public const long MaxXmlChars = 400L * 1024 * 1024;
    }

    public static class SafeXml
    {
        static XmlReaderSettings Settings()
        {
            return new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Prohibit,   // защита от XXE / «billion laughs»
                XmlResolver = null,                       // никаких внешних ресурсов
                MaxCharactersFromEntities = 1024,
                MaxCharactersInDocument = Limits.MaxXmlChars,
                IgnoreComments = true,
                IgnoreProcessingInstructions = true,
                CloseInput = true,
            };
        }

        public static XDocument Parse(byte[] data)
        {
            using (var ms = new MemoryStream(data, false))
            using (var r = XmlReader.Create(ms, Settings()))
                return XDocument.Load(r, LoadOptions.None);
        }

        public static byte[] Serialize(XDocument doc)
        {
            var ms = new MemoryStream();
            var ws = new XmlWriterSettings { Encoding = new UTF8Encoding(false), Indent = false, OmitXmlDeclaration = false };
            using (var w = XmlWriter.Create(ms, ws))
            {
                if (doc.Declaration == null) doc.Declaration = new XDeclaration("1.0", "UTF-8", "yes");
                doc.Save(w);
            }
            return ms.ToArray();
        }
    }

    public enum FileFormat { Unknown, Ooxml, Ppt, EncryptedOoxml, OtherCfb, Empty }

    public static class FormatDetect
    {
        public static FileFormat Detect(byte[] d)
        {
            if (d == null || d.Length < 8) return FileFormat.Empty;
            if (d[0] == 0x50 && d[1] == 0x4B && (d[2] == 3 || d[2] == 5 || d[2] == 7)) return FileFormat.Ooxml;
            if (d[0] == 0xD0 && d[1] == 0xCF && d[2] == 0x11 && d[3] == 0xE0 && d[4] == 0xA1 && d[5] == 0xB1 && d[6] == 0x1A && d[7] == 0xE1)
            {
                try
                {
                    var cfb = new CfbReader(d);
                    if (cfb.Exists("EncryptedPackage")) return FileFormat.EncryptedOoxml;
                    if (cfb.Exists("PowerPoint Document")) return FileFormat.Ppt;
                }
                catch { }
                return FileFormat.OtherCfb;
            }
            return FileFormat.Unknown;
        }

        public static string Describe(FileFormat f)
        {
            switch (f)
            {
                case FileFormat.Ooxml: return "Office Open XML (ZIP-пакет)";
                case FileFormat.Ppt: return "PowerPoint 97–2003 (двоичный, OLE2)";
                case FileFormat.EncryptedOoxml: return "Зашифрованный документ Office (защищён паролем)";
                case FileFormat.OtherCfb: return "Составной документ OLE2 (не презентация)";
                case FileFormat.Empty: return "Пустой или повреждённый файл";
                default: return "Неизвестный формат";
            }
        }
    }

    public sealed class Rel
    {
        public string Id, Type, Target;
        public bool External;
        public Rel Clone() => (Rel)MemberwiseClone();
    }

    public sealed class OpcPackage
    {
        public Dictionary<string, byte[]> Parts = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> Defaults = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, string> Overrides = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public List<string> Anomalies = new List<string>();
        public long TotalUncompressed;

        public OpcPackage Clone()
        {
            var p = new OpcPackage();
            foreach (var kv in Parts) p.Parts[kv.Key] = kv.Value;
            foreach (var kv in Defaults) p.Defaults[kv.Key] = kv.Value;
            foreach (var kv in Overrides) p.Overrides[kv.Key] = kv.Value;
            p.Anomalies.AddRange(Anomalies);
            p.TotalUncompressed = TotalUncompressed;
            return p;
        }

        public static string Norm(string name)
        {
            name = name.Replace('\\', '/');
            if (!name.StartsWith("/")) name = "/" + name;
            return name;
        }

        public static OpcPackage FromZip(byte[] data)
        {
            try { return FromZipCore(data); }
            catch (InvalidDataException ex) { throw new UnsafeFileException("Архив документа повреждён: " + ex.Message); }
            catch (IOException ex) { throw new UnsafeFileException("Архив документа повреждён или обрезан: " + ex.Message); }
        }

        static OpcPackage FromZipCore(byte[] data)
        {
            var pkg = new OpcPackage();
            using (var ms = new MemoryStream(data, false))
            using (var zip = new ZipArchive(ms, ZipArchiveMode.Read, false))
            {
                if (zip.Entries.Count > Limits.MaxEntries) throw new UnsafeFileException("Слишком много элементов в архиве (" + zip.Entries.Count + ").");
                long total = 0;
                foreach (var e in zip.Entries)
                {
                    if (e.FullName.EndsWith("/")) continue;
                    string n = e.FullName.Replace('\\', '/');
                    if (n.Contains("../") || n.StartsWith("/") || n.Contains(":") || n.Contains("\0"))
                    {
                        pkg.Anomalies.Add("Подозрительное имя элемента архива пропущено: " + n);
                        continue;
                    }
                    if (e.Length > Limits.MaxPartBytes) throw new UnsafeFileException("Элемент архива слишком велик: " + n);
                    if (e.Length > 10 * 1024 * 1024 && e.CompressedLength > 0 && (double)e.Length / e.CompressedLength > Limits.MaxRatio)
                        throw new UnsafeFileException("Обнаружен признак zip-бомбы (аномальное сжатие): " + n);
                    total += e.Length;
                    if (total > Limits.MaxTotalUncompressed) throw new UnsafeFileException("Распакованный размер пакета превышает допустимый предел.");
                    byte[] buf = ReadBounded(e, e.Length);
                    string key = Norm(n);
                    if (pkg.Parts.ContainsKey(key)) { pkg.Anomalies.Add("Дублирующийся элемент архива: " + n); continue; }
                    pkg.Parts[key] = buf;
                }
                pkg.TotalUncompressed = total;
            }
            if (!pkg.Parts.TryGetValue("/[Content_Types].xml", out var ct)) throw new UnsafeFileException("В пакете нет [Content_Types].xml — это не документ Office.");
            var doc = SafeXml.Parse(ct);
            foreach (var d in doc.Root.Elements(Ns.CT + "Default"))
            {
                var ext = (string)d.Attribute("Extension"); var t = (string)d.Attribute("ContentType");
                if (ext != null && t != null) pkg.Defaults[ext] = t;
            }
            foreach (var o in doc.Root.Elements(Ns.CT + "Override"))
            {
                var pn = (string)o.Attribute("PartName"); var t = (string)o.Attribute("ContentType");
                if (pn != null && t != null) pkg.Overrides[Norm(Uri.UnescapeDataString(pn))] = t;
            }
            pkg.Parts.Remove("/[Content_Types].xml");
            return pkg;
        }

        static byte[] ReadBounded(ZipArchiveEntry e, long declared)
        {
            using (var s = e.Open())
            {
                var ms = new MemoryStream(declared > 0 && declared < int.MaxValue ? (int)declared : 0);
                var buf = new byte[81920];
                long total = 0; int n;
                while ((n = s.Read(buf, 0, buf.Length)) > 0)
                {
                    total += n;
                    if (total > declared || total > Limits.MaxPartBytes) throw new UnsafeFileException("Размер элемента архива не совпадает с заявленным (возможна атака): " + e.FullName);
                    ms.Write(buf, 0, n);
                }
                return ms.ToArray();
            }
        }

        public byte[] ToZip()
        {
            var ms = new MemoryStream();
            using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
            {
                WriteEntry(zip, "[Content_Types].xml", BuildContentTypes());
                foreach (var kv in Parts.OrderBy(k => k.Key.StartsWith("/_rels") ? 0 : 1).ThenBy(k => k.Key, StringComparer.Ordinal))
                    WriteEntry(zip, kv.Key.TrimStart('/'), kv.Value);
            }
            return ms.ToArray();
        }

        static void WriteEntry(ZipArchive zip, string name, byte[] data)
        {
            bool store = name.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) || name.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) || name.EndsWith(".png", StringComparison.OrdinalIgnoreCase);
            var e = zip.CreateEntry(name, store ? CompressionLevel.NoCompression : CompressionLevel.Optimal);
            e.LastWriteTime = new DateTimeOffset(1980, 1, 1, 0, 0, 0, TimeSpan.Zero);
            using (var s = e.Open()) s.Write(data, 0, data.Length);
        }

        byte[] BuildContentTypes()
        {
            var root = new XElement(Ns.CT + "Types");
            if (!Defaults.ContainsKey("rels")) Defaults["rels"] = ContentTypes.Rels;
            if (!Defaults.ContainsKey("xml")) Defaults["xml"] = "application/xml";
            foreach (var kv in Defaults.OrderBy(k => k.Key, StringComparer.Ordinal))
                root.Add(new XElement(Ns.CT + "Default", new XAttribute("Extension", kv.Key), new XAttribute("ContentType", kv.Value)));
            foreach (var kv in Overrides.OrderBy(k => k.Key, StringComparer.Ordinal))
                if (Parts.ContainsKey(kv.Key))
                    root.Add(new XElement(Ns.CT + "Override", new XAttribute("PartName", kv.Key), new XAttribute("ContentType", kv.Value)));
            return SafeXml.Serialize(new XDocument(root));
        }

        public string ContentTypeOf(string part)
        {
            part = Norm(part);
            if (Overrides.TryGetValue(part, out var t)) return t;
            var ext = Path.GetExtension(part).TrimStart('.');
            return Defaults.TryGetValue(ext, out t) ? t : null;
        }

        public bool Has(string part) => Parts.ContainsKey(Norm(part));
        public byte[] Get(string part) => Parts.TryGetValue(Norm(part), out var b) ? b : null;

        public XDocument GetXml(string part)
        {
            var b = Get(part);
            return b == null ? null : SafeXml.Parse(b);
        }

        public void SetXml(string part, XDocument doc, string contentType = null)
        {
            part = Norm(part);
            Parts[part] = SafeXml.Serialize(doc);
            if (contentType != null) Overrides[part] = contentType;
        }

        public void Remove(string part)
        {
            part = Norm(part);
            Parts.Remove(part);
            Overrides.Remove(part);
            Parts.Remove(RelsPathFor(part));
        }

        public static string RelsPathFor(string part)
        {
            part = Norm(part);
            int i = part.LastIndexOf('/');
            string dir = part.Substring(0, i + 1);
            string file = part.Substring(i + 1);
            return dir + "_rels/" + file + ".rels";
        }

        public List<Rel> GetRels(string part)
        {
            var list = new List<Rel>();
            var b = Get(part == "/" ? "/_rels/.rels" : RelsPathFor(part));
            if (b == null) return list;
            var doc = SafeXml.Parse(b);
            foreach (var r in doc.Root.Elements(Ns.PR + "Relationship"))
            {
                list.Add(new Rel
                {
                    Id = (string)r.Attribute("Id"),
                    Type = (string)r.Attribute("Type"),
                    Target = (string)r.Attribute("Target") ?? "",
                    External = string.Equals((string)r.Attribute("TargetMode"), "External", StringComparison.OrdinalIgnoreCase)
                });
            }
            return list;
        }

        public void SetRels(string part, List<Rel> rels)
        {
            var root = new XElement(Ns.PR + "Relationships");
            foreach (var r in rels)
            {
                var e = new XElement(Ns.PR + "Relationship", new XAttribute("Id", r.Id), new XAttribute("Type", r.Type), new XAttribute("Target", r.Target));
                if (r.External) e.Add(new XAttribute("TargetMode", "External"));
                root.Add(e);
            }
            var path = part == "/" ? "/_rels/.rels" : RelsPathFor(part);
            Parts[path] = SafeXml.Serialize(new XDocument(root));
        }

        public static string ResolveTarget(string sourcePart, string target)
        {
            if (string.IsNullOrEmpty(target)) return null;
            target = Uri.UnescapeDataString(target.Replace('\\', '/'));
            int hash = target.IndexOf('#'); if (hash >= 0) target = target.Substring(0, hash);
            string baseDir;
            if (target.StartsWith("/")) { baseDir = ""; }
            else
            {
                sourcePart = Norm(sourcePart ?? "/");
                baseDir = sourcePart.Substring(0, sourcePart.LastIndexOf('/') + 1);
            }
            var parts = new List<string>();
            foreach (var seg in (baseDir + target).Split('/'))
            {
                if (seg == "" || seg == ".") continue;
                if (seg == "..") { if (parts.Count > 0) parts.RemoveAt(parts.Count - 1); continue; }
                parts.Add(seg);
            }
            return "/" + string.Join("/", parts);
        }

        public static string RelativeTarget(string sourcePart, string targetPart)
        {
            sourcePart = Norm(sourcePart); targetPart = Norm(targetPart);
            var s = sourcePart.Split('/').Where(x => x != "").ToList(); s.RemoveAt(s.Count - 1);
            var t = targetPart.Split('/').Where(x => x != "").ToList();
            int common = 0;
            while (common < s.Count && common < t.Count - 1 && string.Equals(s[common], t[common], StringComparison.OrdinalIgnoreCase)) common++;
            var sb = new StringBuilder();
            for (int i = common; i < s.Count; i++) sb.Append("../");
            sb.Append(string.Join("/", t.Skip(common)));
            return sb.ToString();
        }

        public static string NewRelId(List<Rel> rels, string prefix = "rId")
        {
            int n = rels.Count + 1;
            while (rels.Any(r => string.Equals(r.Id, prefix + n, StringComparison.OrdinalIgnoreCase))) n++;
            return prefix + n;
        }

        public string UniquePartName(string dir, string baseName, string ext)
        {
            int n = 1;
            while (Has(dir + baseName + n + "." + ext)) n++;
            return Norm(dir + baseName + n + "." + ext);
        }

        public string FindByRelType(string source, string type)
        {
            var r = GetRels(source).FirstOrDefault(x => x.Type == type && !x.External);
            return r == null ? null : ResolveTarget(source, r.Target);
        }
    }
}
