// Чтение двоичных презентаций PowerPoint 97–2003 (.ppt / .pps / .pot).
// Импортируются: фигуры, текст с форматированием, рисунки, фон, заметки, скрытые слайды.
// Макросы/OLE/звуки не исполняются. При сохранении файл конвертируется в PPTX.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace SlideNova.Core
{
    public static class PptReader
    {
        const double MU = 1587.5; // 1 master unit (1/576 дюйма) в EMU

        struct Rec
        {
            public int Ver, Inst, Type;
            public int Off, Len; // начало данных и длина
            public bool IsContainer => Ver == 0xF;
            public int End => Off + Len;
        }

        static bool TryRec(byte[] d, int pos, int limit, out Rec r)
        {
            r = new Rec();
            if (pos < 0 || pos + 8 > limit || pos + 8 > d.Length) return false;
            int vi = BitConverter.ToUInt16(d, pos);
            r.Ver = vi & 0xF; r.Inst = vi >> 4;
            r.Type = BitConverter.ToUInt16(d, pos + 2);
            uint len = BitConverter.ToUInt32(d, pos + 4);
            r.Off = pos + 8;
            if (len > (uint)(Math.Min(limit, d.Length) - r.Off)) len = (uint)Math.Max(0, Math.Min(limit, d.Length) - r.Off);
            r.Len = (int)len;
            return true;
        }

        static IEnumerable<Rec> Kids(byte[] d, Rec parent)
        {
            int pos = parent.Off, n = 0;
            while (pos + 8 <= parent.End)
            {
                if (!TryRec(d, pos, parent.End, out var r)) yield break;
                if (++n > 200000) yield break;
                yield return r;
                pos = r.End;
            }
        }

        static Rec? Kid(byte[] d, Rec parent, int type, int inst = -1)
        {
            foreach (var k in Kids(d, parent)) if (k.Type == type && (inst < 0 || k.Inst == inst)) return k;
            return null;
        }

        static int I32(byte[] d, int o) => o + 4 <= d.Length ? BitConverter.ToInt32(d, o) : 0;
        static uint U32(byte[] d, int o) => o + 4 <= d.Length ? BitConverter.ToUInt32(d, o) : 0;
        static int U16(byte[] d, int o) => o + 2 <= d.Length ? BitConverter.ToUInt16(d, o) : 0;
        static short S16(byte[] d, int o) => o + 2 <= d.Length ? BitConverter.ToInt16(d, o) : (short)0;

        // ---------------- Контекст ----------------
        sealed class TextGroup
        {
            public int TextType = 4;
            public string Text = "";
            public List<Tuple<int, int, PF>> PRuns = new List<Tuple<int, int, PF>>(); // count, level, pf
            public List<Tuple<int, CF>> CRuns = new List<Tuple<int, CF>>();
        }
        sealed class PF { public bool? HasBullet; public char? BulletChar; public int? BulletFont; public int? Align; public int? LineSpacing; public int? SpaceBefore, SpaceAfter; public int? LeftMargin, Indent; }
        sealed class CF { public bool? Bold, Italic, Underline; public int? Font; public double? Size; public Rgba? Color; public int? ColorIndex; }
        sealed class SlwtEntry { public uint PersistRef, SlideId; public List<TextGroup> Texts = new List<TextGroup>(); }
        sealed class MasterStyle { public Dictionary<int, LevelStyle[]> ByType = new Dictionary<int, LevelStyle[]>(); }

        sealed class Ctx
        {
            public byte[] D, Pics;
            public Dictionary<uint, int> Persist = new Dictionary<uint, int>();
            public List<string> Fonts = new List<string>();
            public List<Tuple<int, int, int>> Blips = new List<Tuple<int, int, int>>(); // (abs offset in stream or -1), len, btWin32 ; хранится как: streamFlag, offset, length
            public List<byte[]> BlipData = new List<byte[]>();
            public Dictionary<int, string> BlipKeys = new Dictionary<int, string>();
            public PresentationModel Pres;
            public int ShapeCount;
        }

        sealed class Xf
        {
            public double Ox, Oy, Sx = MU, Sy = MU, Bx, By;
            public double X(double v) => Bx + (v - Ox) * Sx;
            public double Y(double v) => By + (v - Oy) * Sy;
        }

        // ---------------- Точка входа ----------------
        public static PresentationModel Read(byte[] data, int slideLimit = int.MaxValue)
        {
            var cfb = new CfbReader(data);
            var d = cfb.Read("PowerPoint Document");
            if (d == null) throw new UnsafeFileException("В файле нет потока «PowerPoint Document».");
            var cur = cfb.Read("Current User");
            var c = new Ctx { D = d, Pics = cfb.Read("Pictures") };

            // Презентацию строим на основе чистого шаблона (с пустым макетом)
            var pres = new PptxReader(Template.Create()).Read();
            pres.SourceFormat = "ppt";
            pres.Slides.Clear();
            c.Pres = pres;
            foreach (var st in cfb.Streams()) pres.CfbStreams.Add(st.Path + " (" + st.Size + " Б)");
            if (cfb.Exists("Macros/VBA/dir") || cfb.Streams().Any(s => s.Path.StartsWith("_VBA_PROJECT", StringComparison.OrdinalIgnoreCase) || s.Path.IndexOf("VBA", StringComparison.OrdinalIgnoreCase) >= 0))
            {
                pres.Security.HasMacros = true;
                pres.Security.Notes.Add("Обнаружен проект макросов VBA. Макросы не выполняются и не будут сохранены.");
            }
            if (cfb.Streams().Any(s => s.Path.StartsWith("ObjectPool", StringComparison.OrdinalIgnoreCase) || s.Path.IndexOf("Ole", StringComparison.OrdinalIgnoreCase) >= 0))
                pres.Security.OleObjects.Add("Внедрённые объекты OLE (двоичный формат) — не активируются");

            // Цепочка правок → каталог сохраняемых объектов
            uint offCurrentEdit = 0;
            if (cur != null && cur.Length >= 24)
            {
                uint token = U32(cur, 12);
                if (token == 0xF3D1C4DF) throw new UnsafeFileException("Презентация зашифрована паролем. Открытие зашифрованных файлов не поддерживается.");
                offCurrentEdit = U32(cur, 16);
            }
            uint docRef = 0; bool first = true;
            var visited = new HashSet<uint>();
            uint off = offCurrentEdit;
            while (off != 0 || first)
            {
                if (!visited.Add(off) || visited.Count > 10000) break;
                if (!TryRec(d, (int)off, d.Length, out var ue) || ue.Type != 0x0FF5) { if (first) throw new UnsafeFileException("Повреждена структура презентации (UserEditAtom)."); break; }
                if (first)
                {
                    docRef = U32(d, ue.Off + 16);
                    if (ue.Len >= 0x20 && U32(d, ue.Off + 28) != 0) throw new UnsafeFileException("Презентация зашифрована паролем.");
                }
                uint pdOff = U32(d, ue.Off + 12);
                if (TryRec(d, (int)pdOff, d.Length, out var pd) && pd.Type == 0x1772)
                {
                    int p = pd.Off;
                    while (p + 4 <= pd.End)
                    {
                        uint hdr = U32(d, p); p += 4;
                        uint pid = hdr & 0xFFFFF; int cnt = (int)(hdr >> 20);
                        for (int i = 0; i < cnt && p + 4 <= pd.End; i++, p += 4)
                            if (!c.Persist.ContainsKey(pid + (uint)i)) c.Persist[pid + (uint)i] = (int)U32(d, p);
                    }
                }
                off = U32(d, ue.Off + 8);
                first = false;
            }
            if (!c.Persist.TryGetValue(docRef, out var docOff) || !TryRec(d, docOff, d.Length, out var docRec) || docRec.Type != 0x03E8)
                throw new UnsafeFileException("Не найден контейнер документа PowerPoint.");

            // Документ
            var docAtom = Kid(d, docRec, 0x03E9);
            if (docAtom.HasValue)
            {
                double w = I32(d, docAtom.Value.Off) * MU, h = I32(d, docAtom.Value.Off + 4) * MU;
                if (w > 914400 * 0.5 && h > 914400 * 0.5 && w < 914400 * 60 && h < 914400 * 60) { pres.SlideW = w; pres.SlideH = h; pres.SizeDirty = true; }
            }
            var env = Kid(d, docRec, 0x03F2);
            var fc = env.HasValue ? Kid(d, env.Value, 0x07D5) : null;
            if (fc.HasValue)
                foreach (var fe in Kids(d, fc.Value).Where(k => k.Type == 0x0FB7))
                {
                    int n = Math.Min(64, fe.Len);
                    var name = Encoding.Unicode.GetString(d, fe.Off, n & ~1);
                    int z = name.IndexOf('\0'); if (z >= 0) name = name.Substring(0, z);
                    c.Fonts.Add(name);
                }
            var dgg = Kid(d, docRec, 0x040B);
            if (dgg.HasValue)
            {
                var dggc = Kid(d, dgg.Value, 0xF000);
                var bstore = dggc.HasValue ? Kid(d, dggc.Value, 0xF001) : null;
                if (bstore.HasValue)
                    foreach (var fbse in Kids(d, bstore.Value)) c.BlipData.Add(fbse.Type == 0xF007 ? ReadFbse(c, fbse) : null);
            }

            var slides = new List<SlwtEntry>(); var masters = new List<SlwtEntry>(); var notes = new List<SlwtEntry>();
            foreach (var k in Kids(d, docRec).Where(k => k.Type == 0x0FF0))
            {
                var list = k.Inst == 0 ? slides : k.Inst == 1 ? masters : notes;
                SlwtEntry curE = null; TextGroup tg = null;
                foreach (var a in Kids(d, k))
                {
                    switch (a.Type)
                    {
                        case 0x03F3: curE = new SlwtEntry { PersistRef = U32(d, a.Off), SlideId = U32(d, a.Off + 12) }; list.Add(curE); tg = null; break;
                        case 0x0F9F: if (curE != null) { tg = new TextGroup { TextType = I32(d, a.Off) }; curE.Texts.Add(tg); } break;
                        case 0x0FA0: if (tg != null) tg.Text = Encoding.Unicode.GetString(d, a.Off, a.Len & ~1); break;
                        case 0x0FA8: if (tg != null) tg.Text = Latin1(d, a.Off, a.Len); break;
                        case 0x0FA1: if (tg != null) ParseStyle(d, a, tg); break;
                    }
                }
            }

            // Образцы
            var masterInfo = new Dictionary<uint, MasterData>();
            foreach (var m in masters)
            {
                if (!c.Persist.TryGetValue(m.PersistRef, out var mo) || !TryRec(d, mo, d.Length, out var mr)) continue;
                if (mr.Type != 0x03F8 && mr.Type != 0x03EE) continue;
                try { masterInfo[m.SlideId] = ReadMaster(c, mr); } catch (Exception ex) { pres.Warnings.Add("Образец слайдов не прочитан: " + ex.Message); }
            }
            var defMaster = masterInfo.Values.FirstOrDefault() ?? new MasterData();

            var notesById = notes.ToDictionary(n => n.SlideId, n => n);
            var blank = pres.Layouts.FirstOrDefault(l => l.Type == "blank") ?? pres.Layouts.FirstOrDefault();

            int idx = 0;
            foreach (var se in slides)
            {
                if (++idx > Limits.MaxSlides || pres.Slides.Count >= slideLimit) break;
                var slide = new SlideModel { LayoutPart = blank?.Part, LayoutName = "Пустой слайд", MasterShapes = new List<ShapeModel>() };
                try
                {
                    if (!c.Persist.TryGetValue(se.PersistRef, out var so) || !TryRec(d, so, d.Length, out var sr) || sr.Type != 0x03EE) { pres.Warnings.Add("Слайд " + idx + " не найден."); pres.Slides.Add(slide); continue; }
                    var sa = Kid(d, sr, 0x03EF);
                    uint masterId = sa.HasValue ? U32(d, sa.Value.Off + 12) : 0;
                    uint notesId = sa.HasValue ? U32(d, sa.Value.Off + 16) : 0;
                    int flags = sa.HasValue ? U16(d, sa.Value.Off + 20) : 7;
                    var md = masterInfo.TryGetValue(masterId, out var mm) ? mm : defMaster;
                    var scheme = (flags & 2) != 0 ? md.Scheme : (ReadScheme(d, sr) ?? md.Scheme);
                    var ssi = Kid(d, sr, 0x03F9);
                    if (ssi.HasValue && ssi.Value.Len >= 12) slide.Hidden = (U16(d, ssi.Value.Off + 10) & 0x4) != 0;

                    var bgAndShapes = ReadDrawing(c, d, sr, scheme, md.Styles, se.Texts, out var bg);
                    slide.Background = (flags & 4) != 0 || bg == null ? md.Background.Clone() : bg;
                    slide.BackgroundDirty = true;
                    if ((flags & 1) != 0) foreach (var ms in md.Decor) { var cl = ms.Clone(); slide.Shapes.Add(cl); }
                    slide.Shapes.AddRange(bgAndShapes);
                    // Заметки
                    if (notesId != 0 && notesById.TryGetValue(notesId, out var ne) && c.Persist.TryGetValue(ne.PersistRef, out var no) && TryRec(d, no, d.Length, out var nr))
                    {
                        var nsh = ReadDrawing(c, d, nr, scheme, md.Styles, ne.Texts, out _, notesOnly: true);
                        slide.Notes = string.Join("\n", nsh.Where(s => s.Text != null).Select(s => s.Text.PlainText)).Trim();
                        if (slide.Notes.Length == 0) slide.Notes = string.Join("\n", ne.Texts.Where(t => t.TextType == 2).Select(t => t.Text.Replace('\r', '\n').Replace('\v', '\n'))).Trim();
                        slide.NotesDirty = slide.Notes.Length > 0;
                    }
                }
                catch (UnsafeFileException) { throw; }
                catch (Exception ex) { pres.Warnings.Add("Слайд " + idx + " прочитан частично: " + ex.Message); }
                int id = 2;
                foreach (var s in slide.Shapes) Renumber(s, ref id);
                pres.Slides.Add(slide);
            }
            if (pres.Slides.Count == 0) pres.Slides.Add(Template.NewSlide(pres, blank));
            pres.Info.Title = "";
            ReadSummary(cfb, pres.Info);
            pres.Info.Dirty = true;
            pres.Warnings.Insert(0, "Файл в формате PowerPoint 97–2003 импортирован. При сохранении он будет записан в современном формате PPTX.");
            return pres;
        }

        static void Renumber(ShapeModel s, ref int id)
        {
            s.Id = id++;
            if (s.Children != null) foreach (var k in s.Children) Renumber(k, ref id);
        }

        static string Latin1(byte[] d, int off, int len)
        {
            var sb = new StringBuilder(len);
            for (int i = 0; i < len && off + i < d.Length; i++) sb.Append((char)d[off + i]);
            return sb.ToString();
        }

        // ---------------- Сводка (заголовок, автор) ----------------
        static void ReadSummary(CfbReader cfb, DocInfo info)
        {
            try
            {
                var s = cfb.Read("\u0005SummaryInformation");
                if (s == null || s.Length < 48) return;
                int setOff = I32(s, 44);
                if (setOff <= 0 || setOff + 8 > s.Length) return;
                int count = I32(s, setOff + 4);
                int cp = 1252;
                for (int i = 0; i < count && i < 64; i++)
                {
                    int pid = I32(s, setOff + 8 + i * 8), p = setOff + I32(s, setOff + 12 + i * 8);
                    if (pid == 1 && p + 6 <= s.Length && I32(s, p) == 2) cp = U16(s, p + 4);
                }
                Encoding enc;
                try { enc = Encoding.GetEncoding(cp); } catch { enc = null; }
                for (int i = 0; i < count && i < 64; i++)
                {
                    int pid = I32(s, setOff + 8 + i * 8), poff = I32(s, setOff + 12 + i * 8);
                    int p = setOff + poff;
                    if (p + 8 > s.Length) continue;
                    int type = I32(s, p);
                    if (type != 30) continue;
                    int len = I32(s, p + 4);
                    if (len <= 0 || p + 8 + len > s.Length || len > 4096) continue;
                    var str = (enc != null ? enc.GetString(s, p + 8, len) : Latin1(s, p + 8, len)).TrimEnd('\0');
                    switch (pid) { case 2: info.Title = str; break; case 3: info.Subject = str; break; case 4: info.Creator = str; break; case 5: info.Keywords = str; break; case 6: info.Description = str; break; case 8: info.LastModifiedBy = str; break; }
                }
            }
            catch { }
        }

        // ---------------- Образец ----------------
        sealed class MasterData
        {
            public Rgba[] Scheme = { Rgba.White, Rgba.Black, Rgba.FromRgb(0x808080), Rgba.Black, Rgba.FromRgb(0xBBE0E3), Rgba.FromRgb(0x333399), Rgba.FromRgb(0x009999), Rgba.FromRgb(0x99CC00) };
            public MasterStyle Styles = new MasterStyle();
            public FillDef Background = FillDef.Solid(Rgba.White);
            public List<ShapeModel> Decor = new List<ShapeModel>();
        }

        static MasterData ReadMaster(Ctx c, Rec mr)
        {
            var d = c.D;
            var md = new MasterData();
            md.Scheme = ReadScheme(d, mr) ?? md.Scheme;
            foreach (var t in Kids(d, mr).Where(k => k.Type == 0x0FA3))
            {
                try { md.Styles.ByType[t.Inst] = ParseMasterStyle(c, d, t, md.Scheme); } catch { }
            }
            var shapes = ReadDrawing(c, d, mr, md.Scheme, md.Styles, new List<TextGroup>(), out var bg, decorOnly: true);
            if (bg != null) md.Background = bg;
            md.Decor = shapes;
            return md;
        }

        static Rgba[] ReadScheme(byte[] d, Rec container)
        {
            foreach (var k in Kids(d, container))
                if (k.Type == 0x07F0 && k.Len >= 32)
                {
                    var s = new Rgba[8];
                    for (int i = 0; i < 8; i++) s[i] = new Rgba(255, d[k.Off + i * 4], d[k.Off + i * 4 + 1], d[k.Off + i * 4 + 2]);
                    return s;
                }
            return null;
        }

        static LevelStyle[] DefaultLevels(int textType, Rgba[] scheme)
        {
            var lv = TextBodyModel.DefaultLevels();
            double[] body = { 32, 28, 24, 20, 20, 20, 20, 20, 20 };
            for (int i = 0; i < 9; i++)
            {
                lv[i].Font = "Arial";
                lv[i].Color = textType == 0 || textType == 6 ? scheme[3] : scheme[1];
                lv[i].SizePt = textType == 0 || textType == 6 ? 44 : textType == 2 ? 12 : textType == 4 ? 18 : body[i];
                lv[i].Align = textType == 0 || textType == 6 || textType == 5 ? "ctr" : "l";
                lv[i].Bullet = textType == 1 || textType == 7 || textType == 8 ? "•" : null;
                lv[i].MarLEmu = textType == 1 ? i * 457200 : 0;
            }
            return lv;
        }

        static LevelStyle[] ParseMasterStyle(Ctx c, byte[] d, Rec t, Rgba[] scheme)
        {
            var lv = DefaultLevels(t.Inst, scheme);
            int p = t.Off;
            int levels = U16(d, p); p += 2;
            for (int i = 0; i < levels && i < 5 && p < t.End; i++)
            {
                int level = i;
                if (t.Inst >= 5) { level = U16(d, p); p += 2; }
                var pf = ReadPF(d, ref p, t.End);
                var cf = ReadCF(d, ref p, t.End);
                if (level < 0 || level > 8) continue;
                ApplyPF(lv[level], pf, c);
                ApplyCF(lv[level], cf, c, scheme);
            }
            for (int i = 5; i < 9; i++) lv[i] = lv[4].Clone();
            return lv;
        }

        static void ApplyPF(LevelStyle l, PF pf, Ctx c)
        {
            if (pf == null) return;
            if (pf.Align.HasValue) l.Align = pf.Align == 1 ? "ctr" : pf.Align == 2 ? "r" : pf.Align == 3 ? "just" : "l";
            if (pf.HasBullet.HasValue) l.Bullet = pf.HasBullet.Value ? (l.Bullet ?? "•") : null;
            if (pf.BulletChar.HasValue && l.Bullet != null)
            {
                string font = pf.BulletFont.HasValue && pf.BulletFont.Value < c.Fonts.Count ? c.Fonts[pf.BulletFont.Value] : null;
                var ch = pf.BulletChar.Value;
                l.Bullet = ch == 0 ? "•" : Dml.MapSymbol(ch.ToString(), font) ?? "•";
            }
            if (pf.LineSpacing.HasValue && pf.LineSpacing.Value > 0) l.LineSpacingPct = Units.Clamp(pf.LineSpacing.Value, 50, 300);
            if (pf.SpaceBefore.HasValue && pf.SpaceBefore.Value > 0) l.SpaceBeforePt = pf.SpaceBefore.Value / 100.0 * 12;
            if (pf.SpaceAfter.HasValue && pf.SpaceAfter.Value > 0) l.SpaceAfterPt = pf.SpaceAfter.Value / 100.0 * 12;
            if (pf.LeftMargin.HasValue) l.MarLEmu = pf.LeftMargin.Value * MU;
            if (pf.Indent.HasValue) l.IndentEmu = (pf.Indent.Value - (pf.LeftMargin ?? 0)) * MU;
        }

        static void ApplyCF(LevelStyle l, CF cf, Ctx c, Rgba[] scheme)
        {
            if (cf == null) return;
            if (cf.Bold.HasValue) l.Bold = cf.Bold.Value;
            if (cf.Italic.HasValue) l.Italic = cf.Italic.Value;
            if (cf.Underline.HasValue) l.Underline = cf.Underline.Value;
            if (cf.Size.HasValue && cf.Size > 0) l.SizePt = cf.Size.Value;
            if (cf.Font.HasValue && cf.Font.Value < c.Fonts.Count) l.Font = c.Fonts[cf.Font.Value];
            var col = CfColor(cf, scheme); if (col.HasValue) l.Color = col.Value;
        }

        static Rgba? CfColor(CF cf, Rgba[] scheme)
        {
            if (cf.Color.HasValue) return cf.Color;
            if (cf.ColorIndex.HasValue && cf.ColorIndex.Value >= 0 && cf.ColorIndex.Value < 8) return scheme[cf.ColorIndex.Value];
            return null;
        }

        // ---------------- Стили текста ----------------
        static PF ReadPF(byte[] d, ref int p, int end)
        {
            var pf = new PF();
            if (p + 4 > end) { p = end; return pf; }
            uint m = U32(d, p); p += 4;
            if ((m & 0xF) != 0) { int f = U16(d, p); p += 2; if ((m & 1) != 0) pf.HasBullet = (f & 1) != 0; }
            if ((m & (1 << 7)) != 0) { pf.BulletChar = (char)U16(d, p); p += 2; }
            if ((m & (1 << 4)) != 0) { pf.BulletFont = U16(d, p); p += 2; }
            if ((m & (1 << 6)) != 0) p += 2;
            if ((m & (1 << 5)) != 0) p += 4;
            if ((m & (1 << 11)) != 0) { pf.Align = U16(d, p); p += 2; }
            if ((m & (1 << 12)) != 0) { pf.LineSpacing = S16(d, p); p += 2; }
            if ((m & (1 << 13)) != 0) { pf.SpaceBefore = S16(d, p); p += 2; }
            if ((m & (1 << 14)) != 0) { pf.SpaceAfter = S16(d, p); p += 2; }
            if ((m & (1 << 8)) != 0) { pf.LeftMargin = S16(d, p); p += 2; }
            if ((m & (1 << 10)) != 0) { pf.Indent = S16(d, p); p += 2; }
            if ((m & (1 << 15)) != 0) p += 2;
            if ((m & (1 << 20)) != 0) { int cnt = U16(d, p); p += 2 + Math.Min(cnt, 1000) * 4; }
            if ((m & (1 << 16)) != 0) p += 2;
            if ((m & 0xE0000) != 0) p += 2;
            if ((m & (1 << 21)) != 0) p += 2;
            return pf;
        }

        static CF ReadCF(byte[] d, ref int p, int end)
        {
            var cf = new CF();
            if (p + 4 > end) { p = end; return cf; }
            uint m = U32(d, p); p += 4;
            if ((m & 0xFFFF) != 0)
            {
                int fs = U16(d, p); p += 2;
                if ((m & 1) != 0) cf.Bold = (fs & 1) != 0;
                if ((m & 2) != 0) cf.Italic = (fs & 2) != 0;
                if ((m & 4) != 0) cf.Underline = (fs & 4) != 0;
            }
            if ((m & (1 << 16)) != 0) { cf.Font = U16(d, p); p += 2; }
            if ((m & (1 << 21)) != 0) p += 2;
            if ((m & (1 << 22)) != 0) p += 2;
            if ((m & (1 << 23)) != 0) p += 2;
            if ((m & (1 << 17)) != 0) { cf.Size = U16(d, p); p += 2; }
            if ((m & (1 << 18)) != 0)
            {
                byte r = p < d.Length ? d[p] : (byte)0, g = p + 1 < d.Length ? d[p + 1] : (byte)0, b = p + 2 < d.Length ? d[p + 2] : (byte)0, ix = p + 3 < d.Length ? d[p + 3] : (byte)0;
                if (ix == 0xFE) cf.Color = new Rgba(255, r, g, b); else if (ix < 8) cf.ColorIndex = ix;
                p += 4;
            }
            if ((m & (1 << 19)) != 0) p += 2;
            return cf;
        }

        static void ParseStyle(byte[] d, Rec a, TextGroup tg)
        {
            int total = tg.Text.Length + 1;
            int p = a.Off, end = a.End, sum = 0, guard = 0;
            while (sum < total && p + 6 <= end && guard++ < 100000)
            {
                int cnt = I32(d, p); int lvl = U16(d, p + 4); p += 6;
                var pf = ReadPF(d, ref p, end);
                if (cnt <= 0) break;
                tg.PRuns.Add(Tuple.Create(cnt, lvl, pf)); sum += cnt;
            }
            sum = 0;
            while (sum < total && p + 4 <= end && guard++ < 200000)
            {
                int cnt = I32(d, p); p += 4;
                var cf = ReadCF(d, ref p, end);
                if (cnt <= 0) break;
                tg.CRuns.Add(Tuple.Create(cnt, cf)); sum += cnt;
            }
        }

        // ---------------- Рисунки ----------------
        static byte[] ReadFbse(Ctx c, Rec fbse)
        {
            var d = c.D;
            if (fbse.Len < 36) return null;
            uint size = U32(d, fbse.Off + 20);
            uint foDelay = U32(d, fbse.Off + 28);
            int cbName = d[fbse.Off + 33];
            int embedded = fbse.Off + 36 + cbName;
            if (embedded + 8 <= fbse.End) return ExtractBlip(d, embedded, fbse.End);
            if (c.Pics != null && foDelay != 0xFFFFFFFF && foDelay < c.Pics.Length) return ExtractBlip(c.Pics, (int)foDelay, c.Pics.Length);
            return null;
        }

        /// <summary>Возвращает байты изображения с префиксом-маркером типа в первом байте: 1=emf,2=wmf,3=jpeg,4=png,5=bmp,6=tiff.</summary>
        static byte[] ExtractBlip(byte[] d, int pos, int limit)
        {
            if (!TryRec(d, pos, limit, out var r)) return null;
            int uids = (r.Inst & 1) == 1 ? 2 : 1;
            int p = r.Off + 16 * uids;
            byte kind; byte[] data;
            switch (r.Type)
            {
                case 0xF01A:
                case 0xF01B:
                case 0xF01C:
                    {
                        if (p + 34 > r.End) return null;
                        uint cbSize = U32(d, p); uint cbSave = U32(d, p + 28); byte compression = d[p + 32];
                        p += 34;
                        int len = (int)Math.Min(cbSave, (uint)Math.Max(0, r.End - p));
                        if (cbSize > 64 * 1024 * 1024) return null;
                        if (compression == 0)
                        {
                            using (var ms = new MemoryStream(d, p + 2, Math.Max(0, len - 2)))
                            using (var ds = new DeflateStream(ms, CompressionMode.Decompress))
                            {
                                var outp = new MemoryStream();
                                var buf = new byte[65536]; int n; long total = 0;
                                while ((n = ds.Read(buf, 0, buf.Length)) > 0) { total += n; if (total > cbSize + 1024) break; outp.Write(buf, 0, n); }
                                data = outp.ToArray();
                            }
                        }
                        else { data = new byte[len]; Buffer.BlockCopy(d, p, data, 0, len); }
                        if (r.Type == 0xF01C) return null; // PICT не поддерживается
                        kind = r.Type == 0xF01A ? (byte)1 : (byte)2;
                        break;
                    }
                case 0xF01D:
                case 0xF02A:
                case 0xF01E:
                case 0xF01F:
                case 0xF029:
                    {
                        p += 1; // tag
                        int len = r.End - p;
                        if (len <= 0) return null;
                        data = new byte[len]; Buffer.BlockCopy(d, p, data, 0, len);
                        kind = r.Type == 0xF01E ? (byte)4 : r.Type == 0xF01F ? (byte)5 : r.Type == 0xF029 ? (byte)6 : (byte)3;
                        if (kind == 5) data = DibToBmp(data);
                        if (data == null) return null;
                        break;
                    }
                default: return null;
            }
            var res = new byte[data.Length + 1];
            res[0] = kind; Buffer.BlockCopy(data, 0, res, 1, data.Length);
            return res;
        }

        public static byte[] DibToBmp(byte[] dib)
        {
            if (dib.Length < 40) return null;
            int biSize = I32(dib, 0), bitCount = U16(dib, 14), compression = I32(dib, 16), clrUsed = I32(dib, 32);
            if (biSize < 12 || biSize > dib.Length) return null;
            int palette = clrUsed > 0 ? clrUsed : (bitCount <= 8 ? 1 << bitCount : 0);
            int extra = (compression == 3 && biSize == 40) ? 12 : 0;
            int offBits = 14 + biSize + extra + palette * 4;
            var bmp = new byte[dib.Length + 14];
            bmp[0] = (byte)'B'; bmp[1] = (byte)'M';
            BitConverter.GetBytes(bmp.Length).CopyTo(bmp, 2);
            BitConverter.GetBytes(offBits).CopyTo(bmp, 10);
            Buffer.BlockCopy(dib, 0, bmp, 14, dib.Length);
            return bmp;
        }

        static string BlipKey(Ctx c, int pib)
        {
            if (pib <= 0 || pib > c.BlipData.Count) return null;
            if (c.BlipKeys.TryGetValue(pib, out var k)) return k;
            var raw = c.BlipData[pib - 1];
            if (raw == null || raw.Length < 2) return null;
            var data = new byte[raw.Length - 1]; Buffer.BlockCopy(raw, 1, data, 0, data.Length);
            string ext = raw[0] == 1 ? "emf" : raw[0] == 2 ? "wmf" : raw[0] == 4 ? "png" : raw[0] == 5 ? "bmp" : raw[0] == 6 ? "tiff" : "jpeg";
            k = c.Pres.AddMedia(data, ext);
            c.BlipKeys[pib] = k;
            return k;
        }

        // ---------------- Рисование ----------------
        sealed class Fopt
        {
            public Dictionary<int, uint> V = new Dictionary<int, uint>();
            public Dictionary<int, byte[]> Cx = new Dictionary<int, byte[]>();
            public bool Has(int p) => V.ContainsKey(p);
            public uint Get(int p, uint def) => V.TryGetValue(p, out var v) ? v : def;
        }

        static void ReadFopt(byte[] d, Rec r, Fopt f)
        {
            int n = r.Inst, p = r.Off;
            int cpos = r.Off + n * 6;
            for (int i = 0; i < n && p + 6 <= r.End; i++, p += 6)
            {
                int opid = U16(d, p); uint op = U32(d, p + 2);
                int pid = opid & 0x3FFF; bool complex = (opid & 0x8000) != 0;
                f.V[pid] = op;
                if (complex && op > 0 && cpos + op <= r.End && op < 16 * 1024 * 1024)
                {
                    var b = new byte[op]; Buffer.BlockCopy(d, cpos, b, 0, (int)op); f.Cx[pid] = b; cpos += (int)op;
                }
            }
        }

        static List<ShapeModel> ReadDrawing(Ctx c, byte[] d, Rec container, Rgba[] scheme, MasterStyle styles, List<TextGroup> outline, out FillDef bg, bool decorOnly = false, bool notesOnly = false)
        {
            bg = null;
            var res = new List<ShapeModel>();
            var drawing = Kid(d, container, 0x040C);
            if (!drawing.HasValue) return res;
            var dg = Kid(d, drawing.Value, 0xF002);
            if (!dg.HasValue) return res;
            foreach (var k in Kids(d, dg.Value))
            {
                if (k.Type == 0xF003) ReadGroup(c, d, k, new Xf(), true, scheme, styles, outline, res, decorOnly, notesOnly, 0);
                else if (k.Type == 0xF004)
                {
                    var fopt = new Fopt();
                    foreach (var kk in Kids(d, k)) if (kk.Type == 0xF00B || kk.Type == 0xF121 || kk.Type == 0xF122) ReadFopt(d, kk, fopt);
                    bg = ReadFill(c, fopt, scheme, true);
                }
            }
            return res;
        }

        static void ReadGroup(Ctx c, byte[] d, Rec spgr, Xf parent, bool patriarch, Rgba[] scheme, MasterStyle styles, List<TextGroup> outline, List<ShapeModel> output, bool decorOnly, bool notesOnly, int depth)
        {
            if (depth > Limits.MaxNesting) return;
            Xf childXf = parent;
            bool firstSp = true;
            foreach (var k in Kids(d, spgr))
            {
                if (k.Type == 0xF004 && firstSp)
                {
                    firstSp = false;
                    var fspgr = Kid(d, k, 0xF009);
                    if (!patriarch && fspgr.HasValue)
                    {
                        double gl = I32(d, fspgr.Value.Off), gt = I32(d, fspgr.Value.Off + 4), gr = I32(d, fspgr.Value.Off + 8), gb = I32(d, fspgr.Value.Off + 12);
                        if (GetAnchor(d, k, parent, out double ax, out double ay, out double aw, out double ah) && gr != gl && gb != gt)
                            childXf = new Xf { Ox = gl, Oy = gt, Sx = aw / (gr - gl), Sy = ah / (gb - gt), Bx = ax, By = ay };
                    }
                    else if (patriarch) childXf = new Xf();
                    continue;
                }
                if (k.Type == 0xF004)
                {
                    if (++c.ShapeCount > Limits.MaxShapesPerSlide * 4) return;
                    var s = ReadShape(c, d, k, childXf, scheme, styles, outline, decorOnly, notesOnly);
                    if (s != null) output.Add(s);
                }
                else if (k.Type == 0xF003) ReadGroup(c, d, k, childXf, false, scheme, styles, outline, output, decorOnly, notesOnly, depth + 1);
            }
        }

        static bool GetAnchor(byte[] d, Rec sp, Xf xf, out double x, out double y, out double w, out double h)
        {
            x = y = w = h = 0;
            var ca = Kid(d, sp, 0xF010);
            if (ca.HasValue)
            {
                double t, l, r, b;
                if (ca.Value.Len >= 16) { t = I32(d, ca.Value.Off); l = I32(d, ca.Value.Off + 4); r = I32(d, ca.Value.Off + 8); b = I32(d, ca.Value.Off + 12); }
                else { t = S16(d, ca.Value.Off); l = S16(d, ca.Value.Off + 2); r = S16(d, ca.Value.Off + 4); b = S16(d, ca.Value.Off + 6); }
                x = l * MU; y = t * MU; w = (r - l) * MU; h = (b - t) * MU;
                return true;
            }
            var ch = Kid(d, sp, 0xF00F);
            if (ch.HasValue)
            {
                double l = I32(d, ch.Value.Off), t = I32(d, ch.Value.Off + 4), r = I32(d, ch.Value.Off + 8), b = I32(d, ch.Value.Off + 12);
                x = xf.X(l); y = xf.Y(t); w = xf.X(r) - x; h = xf.Y(b) - y;
                return true;
            }
            return false;
        }

        static string MapType(int t)
        {
            switch (t)
            {
                case 1: return "rect"; case 2: return "roundRect"; case 3: return "ellipse"; case 4: return "diamond";
                case 5: return "triangle"; case 6: return "rtTriangle"; case 7: return "parallelogram"; case 8: return "trapezoid";
                case 9: return "hexagon"; case 10: return "octagon"; case 11: return "plus"; case 12: return "star5";
                case 13: return "rightArrow"; case 15: return "homePlate"; case 16: return "cube"; case 20: return "line";
                case 22: return "can"; case 23: return "donut"; case 32: return "straightConnector1"; case 33: return "bentConnector2";
                case 34: return "bentConnector3"; case 37: return "curvedConnector3"; case 55: return "chevron"; case 56: return "pentagon";
                case 57: return "noSmoking"; case 58: return "star8"; case 59: return "star16"; case 60: return "star32";
                case 61: return "wedgeRectCallout"; case 62: return "wedgeRoundRectCallout"; case 63: return "wedgeEllipseCallout";
                case 66: return "leftArrow"; case 67: return "downArrow"; case 68: return "upArrow"; case 69: return "leftRightArrow";
                case 70: return "upDownArrow"; case 74: return "heart"; case 92: return "star24"; case 109: return "rect";
                case 110: return "flowChartDecision"; case 111: return "flowChartInputOutput"; case 112: return "flowChartPredefinedProcess";
                case 114: return "flowChartDocument"; case 116: return "flowChartTerminator"; case 117: return "flowChartPreparation";
                case 118: return "flowChartManualInput"; case 120: return "ellipse"; case 132: return "can"; case 176: return "flowChartAlternateProcess";
                case 183: return "sun"; case 187: return "star4";
                default: return "rect";
            }
        }

        static Rgba? Color(uint v, Rgba[] scheme)
        {
            byte flags = (byte)(v >> 24);
            if ((flags & 0x08) != 0) { int i = (int)(v & 0xFF); return i < 8 ? scheme[i] : (Rgba?)null; }
            if ((flags & 0x10) != 0) return null;
            return new Rgba(255, (byte)v, (byte)(v >> 8), (byte)(v >> 16));
        }

        static FillDef ReadFill(Ctx c, Fopt f, Rgba[] scheme, bool isBg)
        {
            uint bools = f.Get(0x01BF, 0);
            bool filled = true;
            if ((bools & (1 << 20)) != 0) filled = (bools & (1 << 4)) != 0;
            if (!filled) return FillDef.NoFill();
            var color = f.Has(0x0181) ? Color(f.Get(0x0181, 0xFFFFFF), scheme) : null;
            var col = color ?? (isBg ? scheme[0] : scheme[4]);
            if (f.Has(0x0182)) col = col.WithAlpha((byte)Units.Clamp(f.Get(0x0182, 65536) / 65536.0 * 255, 0, 255));
            int type = (int)f.Get(0x0180, 0);
            if ((type == 2 || type == 3) && f.Has(0x0186))
            {
                var key = BlipKey(c, (int)f.Get(0x0186, 0));
                if (key != null) return new FillDef { Kind = FillKind.Image, ImageKey = key, Tile = type == 2 };
            }
            if (type >= 4 && type <= 7)
            {
                var back = (f.Has(0x0183) ? Color(f.Get(0x0183, 0xFFFFFF), scheme) : null) ?? Rgba.White;
                double ang = (int)f.Get(0x018B, 0) / 65536.0;
                var g = FillDef.Gradient(col, back, ((90 - ang) % 360 + 360) % 360, type == 5 || type == 6);
                return g;
            }
            return FillDef.Solid(col);
        }

        static ShapeModel ReadShape(Ctx c, byte[] d, Rec sp, Xf xf, Rgba[] scheme, MasterStyle styles, List<TextGroup> outline, bool decorOnly, bool notesOnly)
        {
            var fsp = Kid(d, sp, 0xF00A);
            if (!fsp.HasValue) return null;
            int type = fsp.Value.Inst;
            uint flags = U32(d, fsp.Value.Off + 4);
            if ((flags & 0x8) != 0 || (flags & 0x400) != 0) return null; // удалён / фон
            var fopt = new Fopt();
            foreach (var k in Kids(d, sp)) if (k.Type == 0xF00B || k.Type == 0xF121 || k.Type == 0xF122) ReadFopt(d, k, fopt);
            if (!GetAnchor(d, sp, xf, out double x, out double y, out double w, out double h)) return null;

            // заполнитель?
            bool isPh = false; int phType = -1;
            var cd = Kid(d, sp, 0xF011);
            if (cd.HasValue) { var pa = Kid(d, cd.Value, 0x0BC3); if (pa.HasValue) { isPh = true; phType = d[pa.Value.Off + 4]; } }
            if (decorOnly && isPh) return null;

            // текст
            TextGroup tg = null;
            var tb = Kid(d, sp, 0xF00D);
            if (tb.HasValue)
            {
                TextGroup local = null;
                foreach (var a in Kids(d, tb.Value))
                {
                    switch (a.Type)
                    {
                        case 0x0F9F: local = new TextGroup { TextType = I32(d, a.Off) }; break;
                        case 0x0FA0: if (local != null) local.Text = Encoding.Unicode.GetString(d, a.Off, a.Len & ~1); break;
                        case 0x0FA8: if (local != null) local.Text = Latin1(d, a.Off, a.Len); break;
                        case 0x0FA1: if (local != null) ParseStyle(d, a, local); break;
                        case 0x0F9E: { int i = I32(d, a.Off); if (i >= 0 && i < outline.Count) tg = outline[i]; break; }
                    }
                }
                if (tg == null) tg = local;
            }
            if (notesOnly)
            {
                if (tg == null || tg.TextType != 2 && !(isPh && phType == 0x0C)) return null;
            }

            var s = new ShapeModel { Kind = ShapeKind.Shape, Geometry = MapType(type) };
            s.FlipH = (flags & 0x40) != 0; s.FlipV = (flags & 0x80) != 0;
            double rot = (int)fopt.Get(0x0004, 0) / 65536.0;
            rot = ((rot % 360) + 360) % 360;
            if ((rot >= 45 && rot < 135) || (rot >= 225 && rot < 315))
            {
                double cx = x + w / 2, cy = y + h / 2; double t = w; w = h; h = t; x = cx - w / 2; y = cy - h / 2;
            }
            s.X = x; s.Y = y; s.W = Math.Max(0, w); s.H = Math.Max(0, h); s.Rot = rot;
            s.Name = isPh ? "Заполнитель" : "Фигура";

            // произвольная геометрия
            if ((type == 0 || type >= 0xFFF || MapType(type) == "rect" && type != 1 && type != 202 && type != 75 && type != 109) && fopt.Cx.ContainsKey(0x0145) && fopt.Cx.ContainsKey(0x0146))
            {
                var paths = ReadCustom(fopt, s.W, s.H);
                if (paths != null && paths.Count > 0) { s.Geometry = "custom"; s.CustomPaths = paths; s.CustW = Math.Max(1, s.W); s.CustH = Math.Max(1, s.H); }
            }

            bool isLine = PresetGeometry.IsLineLike(s.Geometry);
            bool textLike = isPh || type == 202 || type == 75;
            // рисунок
            int pib = (int)fopt.Get(0x0104, 0);
            if (pib > 0)
            {
                var key = BlipKey(c, pib);
                if (key != null)
                {
                    s.Kind = ShapeKind.Picture; s.ImageKey = key; s.Name = "Рисунок";
                    if (s.Geometry != "ellipse" && s.Geometry != "roundRect") s.Geometry = "rect";
                    double cl = (int)fopt.Get(0x0102, 0) / 65536.0, ct = (int)fopt.Get(0x0100, 0) / 65536.0, cr = (int)fopt.Get(0x0103, 0) / 65536.0, cb = (int)fopt.Get(0x0101, 0) / 65536.0;
                    s.CropL = Units.Clamp(cl, -1, 0.99); s.CropT = Units.Clamp(ct, -1, 0.99); s.CropR = Units.Clamp(cr, -1, 0.99); s.CropB = Units.Clamp(cb, -1, 0.99);
                }
            }

            // заливка
            uint fb = fopt.Get(0x01BF, 0);
            bool fillSpecified = (fb & (1 << 20)) != 0 || fopt.Has(0x0181);
            if (isLine) s.Fill = FillDef.NoFill();
            else if (s.Kind == ShapeKind.Picture) s.Fill = fillSpecified && (fb & (1 << 20)) != 0 && (fb & (1 << 4)) != 0 ? ReadFill(c, fopt, scheme, false) : FillDef.NoFill();
            else if (textLike && !fillSpecified) s.Fill = FillDef.NoFill();
            else s.Fill = ReadFill(c, fopt, scheme, false);

            // линия
            uint lb = fopt.Get(0x01FF, 0);
            bool line = !textLike && s.Kind != ShapeKind.Picture;
            if ((lb & (1 << 19)) != 0) line = (lb & (1 << 3)) != 0;
            else if (fopt.Has(0x01C0) && !textLike) line = true;
            s.Line = new LineDef { Visible = line || isLine && (lb & (1 << 19)) == 0 };
            if (s.Line.Visible)
            {
                s.Line.Color = (fopt.Has(0x01C0) ? Color(fopt.Get(0x01C0, 0), scheme) : null) ?? scheme[1];
                s.Line.WidthEmu = fopt.Get(0x01CB, 9525);
                int dash = (int)fopt.Get(0x01CE, 0);
                string[] dashes = { "solid", "sysDash", "sysDot", "dashDot", "sysDashDotDot", "dot", "dash", "lgDash", "dashDot", "lgDashDot", "lgDashDotDot" };
                s.Line.Dash = dash >= 0 && dash < dashes.Length ? dashes[dash] : "solid";
                string[] arrows = { "none", "triangle", "stealth", "diamond", "oval", "arrow" };
                int ha = (int)fopt.Get(0x01D0, 0), ta = (int)fopt.Get(0x01D1, 0);
                s.Line.HeadEnd = ha >= 0 && ha < arrows.Length ? arrows[ha] : "none";
                s.Line.TailEnd = ta >= 0 && ta < arrows.Length ? arrows[ta] : "none";
            }
            if (isLine) { s.Kind = ShapeKind.Connector; s.Name = "Линия"; }

            // текст
            if (s.Kind == ShapeKind.Shape)
            {
                int textType = tg?.TextType ?? (isPh ? 1 : 4);
                LevelStyle[] baseLv;
                if (!styles.ByType.TryGetValue(textType, out baseLv))
                {
                    int alt = textType == 6 ? 0 : textType == 5 || textType == 7 || textType == 8 ? 1 : textType;
                    if (!styles.ByType.TryGetValue(alt, out baseLv)) baseLv = DefaultLevels(textType, scheme);
                }
                s.Text = BuildText(c, tg, baseLv, scheme);
                s.Text.LIns = fopt.Get(0x0081, 91440); s.Text.TIns = fopt.Get(0x0082, 45720);
                s.Text.RIns = fopt.Get(0x0083, 91440); s.Text.BIns = fopt.Get(0x0084, 45720);
                s.Text.Wrap = fopt.Get(0x0085, 0) != 2;
                int anchor = (int)fopt.Get(0x0087, (uint)(textType == 0 || textType == 6 ? 1 : 0));
                s.Text.Anchor = anchor == 1 || anchor == 4 || anchor == 7 ? "ctr" : anchor == 2 || anchor == 5 || anchor == 8 ? "b" : "t";
                s.IsTextBox = type == 202 || isPh;
                if (tg == null && !isPh && s.Fill.Kind == FillKind.None && !s.Line.Visible && s.Geometry == "rect") return null;
            }
            s.Detach();
            return s;
        }

        static List<GeoPath> ReadCustom(Fopt f, double w, double h)
        {
            var vb = f.Cx[0x0145]; var sb = f.Cx[0x0146];
            if (vb.Length < 6 || sb.Length < 6) return null;
            int nv = U16(vb, 0), cbv = U16(vb, 4);
            int vsize = cbv == 0xFFF0 ? 4 : (cbv == 4 || cbv == 8 ? cbv : 8);
            var pts = new List<double[]>();
            for (int i = 0; i < nv && 6 + (i + 1) * vsize <= vb.Length; i++)
            {
                int o = 6 + i * vsize;
                if (vsize == 4) pts.Add(new double[] { S16(vb, o), S16(vb, o + 2) });
                else
                {
                    uint ux = U32(vb, o), uy = U32(vb, o + 4);
                    if (ux >= 0x80000000u && ux < 0x80010000u || uy >= 0x80000000u && uy < 0x80010000u) return null; // формулы-направляющие не поддерживаются
                    pts.Add(new double[] { I32(vb, o), I32(vb, o + 4) });
                }
            }
            double gl = (int)f.Get(0x0140, 0), gt = (int)f.Get(0x0141, 0), gr = (int)f.Get(0x0142, 21600), gb = (int)f.Get(0x0143, 21600);
            if (gr == gl) gr = gl + 21600; if (gb == gt) gb = gt + 21600;
            Func<double[], double> X = p => (p[0] - gl) / (gr - gl) * w;
            Func<double[], double> Y = p => (p[1] - gt) / (gb - gt) * h;
            int ns = U16(sb, 0), cbs = U16(sb, 4);
            int ssize = cbs == 0xFFF0 ? 2 : 2;
            var res = new List<GeoPath>(); var cur = new GeoPath(); int vi = 0;
            for (int i = 0; i < ns && 6 + (i + 1) * ssize <= sb.Length; i++)
            {
                int seg = U16(sb, 6 + i * ssize);
                int t = seg >> 13, cnt = seg & 0x1FFF;
                switch (t)
                {
                    case 0: for (int j = 0; j < Math.Max(1, cnt) && vi < pts.Count; j++, vi++) cur.Cmds.Add(new PathCmd('L', X(pts[vi]), Y(pts[vi]))); break;
                    case 1:
                        for (int j = 0; j < Math.Max(1, cnt) && vi + 2 < pts.Count; j++, vi += 3)
                            cur.Cmds.Add(new PathCmd('C', X(pts[vi]), Y(pts[vi]), X(pts[vi + 1]), Y(pts[vi + 1]), X(pts[vi + 2]), Y(pts[vi + 2])));
                        break;
                    case 2: if (vi < pts.Count) { cur.Cmds.Add(new PathCmd('M', X(pts[vi]), Y(pts[vi]))); vi++; } break;
                    case 3: cur.Cmds.Add(new PathCmd('Z')); break;
                    case 4: if (cur.Cmds.Count > 0) { res.Add(cur); cur = new GeoPath(); } break;
                    default: break; // escape-сегменты пропускаем
                }
            }
            if (cur.Cmds.Count > 0) res.Add(cur);
            foreach (var p in res) if (p.Cmds.Count > 0 && p.Cmds[0].Type != 'M') p.Cmds.Insert(0, new PathCmd('M', 0, 0));
            return res;
        }

        static TextBodyModel BuildText(Ctx c, TextGroup tg, LevelStyle[] baseLv, Rgba[] scheme)
        {
            var t = new TextBodyModel();
            for (int i = 0; i < 9; i++) { t.Levels[i].Font = "Calibri"; t.Levels[i].SizePt = 18; t.Levels[i].Color = Rgba.Black; t.Levels[i].Bullet = null; }
            if (tg == null || string.IsNullOrEmpty(tg.Text)) { t.Paras.Add(new ParaModel()); return t; }
            string text = tg.Text;
            int pi = 0, pLeft = tg.PRuns.Count > 0 ? tg.PRuns[0].Item1 : int.MaxValue;
            int ci = 0, cLeft = tg.CRuns.Count > 0 ? tg.CRuns[0].Item1 : int.MaxValue;
            ParaModel para = null; RunModel run = null; int runCi = -1; LevelStyle lvl = null; PF curPf = null; int curLevel = 0;
            Action startPara = () =>
            {
                curPf = pi < tg.PRuns.Count ? tg.PRuns[pi].Item3 : null;
                curLevel = pi < tg.PRuns.Count ? Units.Clamp(tg.PRuns[pi].Item2, 0, 8) : 0;
                lvl = baseLv[Math.Min(curLevel, baseLv.Length - 1)].Clone();
                ApplyPF(lvl, curPf, c);
                para = new ParaModel { Level = curLevel, Align = lvl.Align, Bullet = lvl.Bullet ?? "", LineSpacingPct = lvl.LineSpacingPct != 100 ? lvl.LineSpacingPct : (double?)null };
                if (lvl.SpaceBeforePt > 0) para.SpaceBeforePt = lvl.SpaceBeforePt;
                if (lvl.SpaceAfterPt > 0) para.SpaceAfterPt = lvl.SpaceAfterPt;
                t.Levels[curLevel].MarLEmu = lvl.MarLEmu; t.Levels[curLevel].IndentEmu = lvl.IndentEmu;
                t.Paras.Add(para); run = null; runCi = -1;
            };
            Func<RunModel> newRun = () =>
            {
                var cf = ci < tg.CRuns.Count ? tg.CRuns[ci].Item2 : null;
                var eff = lvl.Clone(); ApplyCF(eff, cf, c, scheme);
                return new RunModel { SizePt = eff.SizePt, Bold = eff.Bold, Italic = eff.Italic, Underline = eff.Underline, Color = eff.Color, Font = eff.Font };
            };
            startPara();
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (ch == '\r')
                {
                    if (run == null) para.EndSizePt = newRun().SizePt;
                }
                else if (ch == '\v' || ch == '\n')
                {
                    var br = newRun(); br.IsBreak = true; br.Text = ""; para.Runs.Add(br); run = null;
                }
                else
                {
                    if (run == null || runCi != ci) { run = newRun(); runCi = ci; para.Runs.Add(run); }
                    run.Text += ch == '\t' ? '\t' : (ch < 0x20 ? ' ' : ch);
                }
                // счётчики
                if (--cLeft <= 0) { ci++; cLeft = ci < tg.CRuns.Count ? tg.CRuns[ci].Item1 : int.MaxValue; }
                bool paraEndsHere = --pLeft <= 0;
                if (paraEndsHere) { pi++; pLeft = pi < tg.PRuns.Count ? tg.PRuns[pi].Item1 : int.MaxValue; }
                if (ch == '\r' && i < text.Length - 1) startPara();
            }
            return t;
        }
    }
}
