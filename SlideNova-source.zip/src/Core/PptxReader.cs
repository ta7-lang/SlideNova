// Чтение PPTX/PPSX/POTX/PPTM в модель. Макросы, ActiveX и OLE никогда не исполняются.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace SlideNova.Core
{
    public static class PresentationLoader
    {
        public static PresentationModel Load(byte[] data, int slideLimit = int.MaxValue)
        {
            if (data == null || data.Length == 0) throw new UnsafeFileException("Файл пуст.");
            if (data.LongLength > Limits.MaxFileBytes) throw new UnsafeFileException("Файл превышает допустимый размер.");
            var fmt = FormatDetect.Detect(data);
            switch (fmt)
            {
                case FileFormat.Ooxml: return new PptxReader(OpcPackage.FromZip(data), slideLimit).Read();
                case FileFormat.Ppt: return PptReader.Read(data, slideLimit);
                case FileFormat.EncryptedOoxml: throw new UnsafeFileException("Документ защищён паролем (зашифрован). Открытие зашифрованных файлов не поддерживается.");
                case FileFormat.OtherCfb: throw new UnsafeFileException("Файл является составным документом OLE2, но не содержит презентации PowerPoint.");
                default: throw new UnsafeFileException("Содержимое файла не является презентацией (сигнатура не распознана). Расширение файла не учитывается — проверяется реальное содержимое.");
            }
        }
    }

    public sealed class PptxReader
    {
        readonly OpcPackage _pkg;
        readonly PresentationModel _pres = new PresentationModel();
        string _presPart;
        readonly Dictionary<string, MasterInfo> _masters = new Dictionary<string, MasterInfo>(StringComparer.OrdinalIgnoreCase);
        readonly Dictionary<string, LayoutInfo> _layouts = new Dictionary<string, LayoutInfo>(StringComparer.OrdinalIgnoreCase);
        XElement _defaultTextStyle;
        int _shapeCount;

        sealed class MasterInfo
        {
            public string Part; public XDocument Doc; public ThemeInfo Theme; public XElement ClrMap; public ColorCtx Ctx;
            public XElement TxStyles; public List<XElement> FillStyles = new List<XElement>(), LineStyles = new List<XElement>(), BgStyles = new List<XElement>();
            public List<ShapeModel> Decor; public FillDef Bg; public PartCtx PC;
        }
        sealed class LayoutInfo
        {
            public string Part, Name, Type; public XDocument Doc; public MasterInfo Master; public List<ShapeModel> Decor; public FillDef Bg;
            public bool ShowMasterSp = true; public PartCtx PC; public List<ShapeModel> AllDecor;
        }
        sealed class PartCtx
        {
            public string Part; public ColorCtx Ctx; public MasterInfo Master; public LayoutInfo Layout; public bool IsSlide; public bool IsMasterOrLayout;
            public Dictionary<string, Rel> Rels = new Dictionary<string, Rel>(StringComparer.Ordinal);
            public XElement SpTree;
        }

        readonly int _slideLimit;
        public PptxReader(OpcPackage pkg, int slideLimit = int.MaxValue) { _pkg = pkg; _slideLimit = slideLimit; }

        public PresentationModel Read()
        {
            _pres.Package = _pkg;
            _pres.SourceFormat = "pptx";
            _presPart = _pkg.FindByRelType("/", Rt.OfficeDoc);
            if (_presPart == null || !_pkg.Has(_presPart)) throw new UnsafeFileException("В пакете не найдена основная часть презентации (ppt/presentation.xml).");
            _pres.MainContentType = _pkg.ContentTypeOf(_presPart);
            if (_pres.MainContentType != null && !_pres.MainContentType.Contains("presentationml") && !_pres.MainContentType.Contains("powerpoint"))
                throw new UnsafeFileException("Документ Office не является презентацией (тип: " + _pres.MainContentType + ").");

            ScanSecurity();
            ReadDocInfo();

            var presDoc = _pkg.GetXml(_presPart);
            var root = presDoc.Root;
            var sz = root.Element(Ns.P + "sldSz");
            if (sz != null)
            {
                _pres.SlideW = Units.Clamp(Dml.Attr(sz, "cx", 12192000), 914400 * 0.5, 914400 * 60);
                _pres.SlideH = Units.Clamp(Dml.Attr(sz, "cy", 6858000), 914400 * 0.5, 914400 * 60);
            }
            _defaultTextStyle = root.Element(Ns.P + "defaultTextStyle");
            var presRels = _pkg.GetRels(_presPart).ToDictionary(r => r.Id, r => r, StringComparer.Ordinal);

            // Образцы и макеты
            foreach (var mid in root.Element(Ns.P + "sldMasterIdLst")?.Elements(Ns.P + "sldMasterId") ?? Enumerable.Empty<XElement>())
            {
                var rid = (string)mid.Attribute(Ns.R + "id");
                if (rid != null && presRels.TryGetValue(rid, out var rel))
                {
                    var mp = OpcPackage.ResolveTarget(_presPart, rel.Target);
                    try { GetMaster(mp); } catch (UnsafeFileException) { throw; } catch (Exception ex) { _pres.Warnings.Add("Образец слайдов " + mp + " не прочитан: " + ex.Message); }
                }
            }
            _pres.MasterCount = Math.Max(1, _masters.Count);
            foreach (var m in _masters.Values.ToList())
            {
                foreach (var r in _pkg.GetRels(m.Part).Where(r => r.Type == Rt.SlideLayout))
                {
                    try { GetLayout(OpcPackage.ResolveTarget(m.Part, r.Target)); } catch (Exception ex) { _pres.Warnings.Add("Макет не прочитан: " + ex.Message); }
                }
            }
            if (_masters.Count > 0) _pres.Theme = _masters.Values.First().Theme;
            foreach (var l in _layouts.Values)
            {
                _pres.LayoutNames[l.Part] = l.Name;
                try { _pres.Layouts.Add(BuildProto(l)); }
                catch (UnsafeFileException) { throw; }
                catch (Exception ex) { _pres.Warnings.Add("Макет «" + l.Name + "» прочитан частично: " + ex.Message); }
            }
            var firstMasterLayouts = _layouts.Values.ToList();
            _pres.DefaultLayoutPart = (firstMasterLayouts.FirstOrDefault(l => l.Type == "obj") ?? firstMasterLayouts.FirstOrDefault(l => l.Type == "blank") ?? firstMasterLayouts.FirstOrDefault())?.Part;
            _pres.TitleLayoutPart = (firstMasterLayouts.FirstOrDefault(l => l.Type == "title") ?? firstMasterLayouts.FirstOrDefault())?.Part;

            // Слайды
            int count = 0;
            foreach (var sid in root.Element(Ns.P + "sldIdLst")?.Elements(Ns.P + "sldId") ?? Enumerable.Empty<XElement>())
            {
                if (_pres.Slides.Count >= _slideLimit) break;
                if (++count > Limits.MaxSlides) { _pres.Warnings.Add("Показаны только первые " + Limits.MaxSlides + " слайдов."); break; }
                var rid = (string)sid.Attribute(Ns.R + "id");
                if (rid == null || !presRels.TryGetValue(rid, out var rel)) continue;
                var part = OpcPackage.ResolveTarget(_presPart, rel.Target);
                if (!_pkg.Has(part)) { _pres.Warnings.Add("Отсутствует часть слайда: " + part); continue; }
                SlideModel slide;
                try { slide = ReadSlide(part); }
                catch (UnsafeFileException) { throw; }
                catch (Exception ex)
                {
                    _pres.Warnings.Add("Слайд " + count + " повреждён: " + ex.Message);
                    slide = new SlideModel { PartName = part };
                }
                slide.OrigSldId = (uint)Dml.Attr(sid, "id", 0);
                slide.OrigPresRelId = rid;
                _pres.Slides.Add(slide);
            }
            if (_pkg.Anomalies.Count > 0) _pres.Warnings.AddRange(_pkg.Anomalies);
            return _pres;
        }

        // ---------------- Безопасность ----------------
        void ScanSecurity()
        {
            var sec = _pres.Security;
            foreach (var kv in _pkg.Parts)
            {
                var name = kv.Key;
                var ct = _pkg.ContentTypeOf(name) ?? "";
                if (ct.Contains("vbaProject") || name.EndsWith("vbaProject.bin", StringComparison.OrdinalIgnoreCase)) sec.HasMacros = true;
                if (name.StartsWith("/ppt/activeX", StringComparison.OrdinalIgnoreCase)) sec.HasActiveX = true;
                if (name.StartsWith("/ppt/embeddings/", StringComparison.OrdinalIgnoreCase)) sec.OleObjects.Add(name.Substring(16) + " (" + FormatSize(kv.Value.Length) + ")");
                if (name.StartsWith("/_xmlsignatures", StringComparison.OrdinalIgnoreCase)) sec.HasSignature = true;
                if (name.StartsWith("/ppt/fonts/", StringComparison.OrdinalIgnoreCase)) sec.HasEmbeddedFonts = true;
                if (name.StartsWith("/ppt/comments", StringComparison.OrdinalIgnoreCase)) sec.HasComments = true;
                if (name.StartsWith("/customXml", StringComparison.OrdinalIgnoreCase)) sec.HasCustomXml = true;
                if (name.EndsWith(".rels", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var doc = SafeXml.Parse(kv.Value);
                        foreach (var r in doc.Root.Elements(Ns.PR + "Relationship"))
                        {
                            if (!string.Equals((string)r.Attribute("TargetMode"), "External", StringComparison.OrdinalIgnoreCase)) continue;
                            var target = (string)r.Attribute("Target") ?? "";
                            var type = (string)r.Attribute("Type") ?? "";
                            if (type.EndsWith("/hyperlink")) { if (!sec.Hyperlinks.Contains(target)) sec.Hyperlinks.Add(target); }
                            else sec.ExternalLinks.Add(type.Substring(type.LastIndexOf('/') + 1) + ": " + target);
                        }
                    }
                    catch { sec.Notes.Add("Повреждённый файл связей: " + name); }
                }
            }
            if (sec.HasMacros) sec.Notes.Add("Макросы VBA обнаружены и заблокированы. Они никогда не выполняются и будут удалены при сохранении.");
            if (sec.HasActiveX) sec.Notes.Add("Элементы ActiveX обнаружены и не активируются.");
            if (sec.OleObjects.Count > 0) sec.Notes.Add("Внедрённые OLE-объекты не запускаются; показывается только их изображение.");
            if (sec.ExternalLinks.Count > 0) sec.Notes.Add("Внешние ссылки на ресурсы не загружаются (сетевой доступ отсутствует).");
        }

        static string FormatSize(long b) => b < 1024 ? b + " Б" : b < 1048576 ? (b / 1024.0).ToString("0.#") + " КБ" : (b / 1048576.0).ToString("0.##") + " МБ";

        void ReadDocInfo()
        {
            var info = _pres.Info;
            try
            {
                var corePart = _pkg.FindByRelType("/", Rt.CoreProps);
                var core = corePart != null ? _pkg.GetXml(corePart) : null;
                if (core != null)
                {
                    string G(XNamespace ns, string n) => (string)core.Root.Element(ns + n) ?? "";
                    info.Title = G(Ns.DC, "title"); info.Subject = G(Ns.DC, "subject"); info.Creator = G(Ns.DC, "creator");
                    info.Keywords = G(Ns.CP, "keywords"); info.Description = G(Ns.DC, "description"); info.Category = G(Ns.CP, "category");
                    info.LastModifiedBy = G(Ns.CP, "lastModifiedBy"); info.Revision = G(Ns.CP, "revision");
                    info.Created = G(Ns.DCT, "created"); info.Modified = G(Ns.DCT, "modified");
                    info.ContentStatus = G(Ns.CP, "contentStatus"); info.Language = G(Ns.DC, "language");
                }
                var appPart = _pkg.FindByRelType("/", Rt.ExtProps);
                var app = appPart != null ? _pkg.GetXml(appPart) : null;
                if (app != null)
                {
                    string G(string n) => (string)app.Root.Element(Ns.EP + n) ?? "";
                    info.Application = G("Application"); info.AppVersion = G("AppVersion"); info.Company = G("Company"); info.Manager = G("Manager");
                    info.Template = G("Template"); info.TotalTime = G("TotalTime"); info.Words = G("Words"); info.Paragraphs = G("Paragraphs");
                    info.PresentationFormat = G("PresentationFormat");
                }
            }
            catch (Exception ex) { _pres.Warnings.Add("Свойства документа не прочитаны: " + ex.Message); }
        }

        // ---------------- Тема, образец, макет ----------------
        ThemeInfo ReadTheme(string part, MasterInfo m)
        {
            var t = new ThemeInfo();
            var doc = part != null ? _pkg.GetXml(part) : null;
            string[] def = { "dk1", "000000", "lt1", "FFFFFF", "dk2", "44546A", "lt2", "E7E6E6", "accent1", "4472C4", "accent2", "ED7D31", "accent3", "A5A5A5", "accent4", "FFC000", "accent5", "5B9BD5", "accent6", "70AD47", "hlink", "0563C1", "folHlink", "954F72" };
            for (int i = 0; i < def.Length; i += 2) { Rgba.TryParseHex(def[i + 1], out var c); t.Colors[def[i]] = c; }
            if (doc == null) return t;
            t.Name = (string)doc.Root.Attribute("name") ?? "";
            var te = doc.Root.Element(Ns.A + "themeElements");
            var cs = te?.Element(Ns.A + "clrScheme");
            if (cs != null)
                foreach (var c in cs.Elements())
                {
                    var col = Dml.ParseColor(Dml.ColorChild(c), null);
                    if (col.HasValue) t.Colors[c.Name.LocalName] = col.Value;
                }
            var fs = te?.Element(Ns.A + "fontScheme");
            var maj = (string)fs?.Element(Ns.A + "majorFont")?.Element(Ns.A + "latin")?.Attribute("typeface");
            var min = (string)fs?.Element(Ns.A + "minorFont")?.Element(Ns.A + "latin")?.Attribute("typeface");
            if (!string.IsNullOrEmpty(maj)) t.MajorFont = maj;
            if (!string.IsNullOrEmpty(min)) t.MinorFont = min;
            var fmt = te?.Element(Ns.A + "fmtScheme");
            if (fmt != null && m != null)
            {
                m.FillStyles = fmt.Element(Ns.A + "fillStyleLst")?.Elements().ToList() ?? new List<XElement>();
                m.LineStyles = fmt.Element(Ns.A + "lnStyleLst")?.Elements().ToList() ?? new List<XElement>();
                m.BgStyles = fmt.Element(Ns.A + "bgFillStyleLst")?.Elements().ToList() ?? new List<XElement>();
            }
            return t;
        }

        MasterInfo GetMaster(string part)
        {
            if (_masters.TryGetValue(part, out var m)) return m;
            m = new MasterInfo { Part = part, Doc = _pkg.GetXml(part) };
            if (m.Doc == null) throw new Exception("нет части " + part);
            _masters[part] = m;
            var themePart = _pkg.FindByRelType(part, Rt.Theme);
            m.Theme = ReadTheme(themePart, m);
            m.ClrMap = m.Doc.Root.Element(Ns.P + "clrMap");
            m.Ctx = ColorCtx.Build(m.Theme, m.ClrMap);
            m.TxStyles = m.Doc.Root.Element(Ns.P + "txStyles");
            m.PC = MakeCtx(part, m.Ctx, m, null, false);
            m.PC.IsMasterOrLayout = true;
            m.PC.SpTree = m.Doc.Root.Element(Ns.P + "cSld")?.Element(Ns.P + "spTree");
            m.Bg = ParseBg(m.Doc.Root.Element(Ns.P + "cSld")?.Element(Ns.P + "bg"), m.PC) ?? FillDef.Solid(m.Ctx.Get("bg1", Rgba.White));
            m.Decor = m.PC.SpTree != null ? ParseTree(m.PC.SpTree, m.PC, 0).Where(s => s.PlaceholderType == null).ToList() : new List<ShapeModel>();
            foreach (var s in m.Decor) s.Locked = true;
            return m;
        }

        LayoutInfo GetLayout(string part)
        {
            if (part == null) return null;
            if (_layouts.TryGetValue(part, out var l)) return l;
            var doc = _pkg.GetXml(part);
            if (doc == null) return null;
            var mp = _pkg.FindByRelType(part, Rt.SlideMaster);
            var master = mp != null ? GetMaster(mp) : _masters.Values.FirstOrDefault();
            if (master == null) return null;
            l = new LayoutInfo { Part = part, Doc = doc, Master = master };
            _layouts[part] = l;
            l.Name = (string)doc.Root.Element(Ns.P + "cSld")?.Attribute("name") ?? "Макет";
            l.Type = (string)doc.Root.Attribute("type") ?? "cust";
            l.ShowMasterSp = (string)doc.Root.Attribute("showMasterSp") != "0";
            var ctx = ColorCtx.Build(master.Theme, master.ClrMap, doc.Root.Element(Ns.P + "clrMapOvr"));
            l.PC = MakeCtx(part, ctx, master, l, false);
            l.PC.IsMasterOrLayout = true;
            l.PC.SpTree = doc.Root.Element(Ns.P + "cSld")?.Element(Ns.P + "spTree");
            l.Bg = ParseBg(doc.Root.Element(Ns.P + "cSld")?.Element(Ns.P + "bg"), l.PC) ?? master.Bg;
            l.Decor = l.PC.SpTree != null ? ParseTree(l.PC.SpTree, l.PC, 0).Where(s => s.PlaceholderType == null).ToList() : new List<ShapeModel>();
            foreach (var s in l.Decor) s.Locked = true;
            l.AllDecor = new List<ShapeModel>();
            if (l.ShowMasterSp) l.AllDecor.AddRange(master.Decor);
            l.AllDecor.AddRange(l.Decor);
            return l;
        }

        LayoutProto BuildProto(LayoutInfo l)
        {
            var proto = new LayoutProto { Part = l.Part, Name = l.Name, Type = l.Type, Decor = l.AllDecor, Background = l.Bg, Hlink = l.PC.Ctx.Get("hlink", Rgba.FromRgb(0x0563C1)) };
            if (l.PC.SpTree == null) return proto;
            // заполнители макета → прототипы для новых слайдов
            var fakeSlideCtx = MakeCtx(l.Part, l.PC.Ctx, l.Master, l, true);
            foreach (var sp in l.PC.SpTree.Elements(Ns.P + "sp"))
            {
                var ph = sp.Element(Ns.P + "nvSpPr")?.Element(Ns.P + "nvPr")?.Element(Ns.P + "ph");
                if (ph == null) continue;
                var type = (string)ph.Attribute("type") ?? "obj";
                if (type == "dt" || type == "ftr" || type == "sldNum") continue;
                var s = ParseSp(new XElement(Ns.P + "sp", new XElement(Ns.P + "nvSpPr",
                    new XElement(Ns.P + "cNvPr", new XAttribute("id", 2), new XAttribute("name", (string)sp.Element(Ns.P + "nvSpPr")?.Element(Ns.P + "cNvPr")?.Attribute("name") ?? "Placeholder")),
                    new XElement(Ns.P + "cNvSpPr"),
                    new XElement(Ns.P + "nvPr", new XElement(ph))), new XElement(Ns.P + "spPr")), fakeSlideCtx, false);
                if (s == null || s.Text == null) continue;
                s.Original = null;
                s.Text.Paras.Clear(); s.Text.Paras.Add(new ParaModel());
                proto.Placeholders.Add(s);
            }
            return proto;
        }

        PartCtx MakeCtx(string part, ColorCtx ctx, MasterInfo m, LayoutInfo l, bool isSlide)
        {
            var pc = new PartCtx { Part = part, Ctx = ctx, Master = m, Layout = l, IsSlide = isSlide };
            foreach (var r in _pkg.GetRels(part)) if (r.Id != null && !pc.Rels.ContainsKey(r.Id)) pc.Rels[r.Id] = r;
            return pc;
        }

        string RelToMedia(PartCtx pc, string rid)
        {
            if (rid == null || !pc.Rels.TryGetValue(rid, out var rel)) return null;
            if (rel.External) return null; // внешние изображения никогда не загружаются
            var target = OpcPackage.ResolveTarget(pc.Part, rel.Target);
            if (target == null) return null;
            if (_pres.Media.ContainsKey(target)) return target;
            var data = _pkg.Get(target);
            if (data == null) return null;
            var ext = System.IO.Path.GetExtension(target).TrimStart('.').ToLowerInvariant();
            _pres.Media[target] = new MediaItem { Data = data, PartName = target, Ext = ext, ContentType = _pkg.ContentTypeOf(target) ?? ContentTypes.ForImageExt(ext) };
            return target;
        }

        string RelToUrl(PartCtx pc, string rid)
        {
            if (rid == null || !pc.Rels.TryGetValue(rid, out var rel)) return null;
            return rel.External ? rel.Target : null;
        }

        FillDef ParseBg(XElement bg, PartCtx pc)
        {
            if (bg == null) return null;
            var bgPr = bg.Element(Ns.P + "bgPr");
            if (bgPr != null) return Dml.ParseFill(bgPr, pc.Ctx, rid => RelToMedia(pc, rid));
            var bgRef = bg.Element(Ns.P + "bgRef");
            if (bgRef != null)
            {
                int idx = (int)Dml.Attr(bgRef, "idx", 0);
                var col = Dml.ParseColorIn(bgRef, pc.Ctx);
                XElement style = null;
                if (idx >= 1001 && idx - 1001 < pc.Master.BgStyles.Count) style = pc.Master.BgStyles[idx - 1001];
                else if (idx >= 1 && idx - 1 < pc.Master.FillStyles.Count) style = pc.Master.FillStyles[idx - 1];
                if (style != null) return Dml.ParseFillElement(style, pc.Ctx.WithPh(col), rid => RelToMedia(MakeThemeCtx(pc), rid));
                if (col.HasValue) return FillDef.Solid(col.Value);
            }
            return null;
        }

        PartCtx MakeThemeCtx(PartCtx pc)
        {
            var tp = _pkg.FindByRelType(pc.Master.Part, Rt.Theme);
            return tp != null ? MakeCtx(tp, pc.Ctx, pc.Master, null, false) : pc;
        }

        // ---------------- Слайд ----------------
        SlideModel ReadSlide(string part)
        {
            var doc = _pkg.GetXml(part);
            var root = doc.Root;
            var layoutPart = _pkg.FindByRelType(part, Rt.SlideLayout);
            var layout = GetLayout(layoutPart);
            if (layout == null)
            {
                var m = _masters.Values.FirstOrDefault() ?? throw new Exception("нет образца слайдов");
                layout = new LayoutInfo { Part = null, Name = "—", Master = m, Decor = new List<ShapeModel>(), AllDecor = m.Decor, Bg = m.Bg, PC = m.PC };
            }
            var ctx = ColorCtx.Build(layout.Master.Theme, layout.Master.ClrMap, root.Element(Ns.P + "clrMapOvr"));
            var pc = MakeCtx(part, ctx, layout.Master, layout, true);
            var cSld = root.Element(Ns.P + "cSld");
            pc.SpTree = cSld?.Element(Ns.P + "spTree");
            var slide = new SlideModel
            {
                PartName = part,
                LayoutPart = layout.Part,
                LayoutName = layout.Name,
                Hidden = (string)root.Attribute("show") == "0",
                HyperlinkColor = ctx.Get("hlink", Rgba.FromRgb(0x0563C1)),
            };
            slide.Background = ParseBg(cSld?.Element(Ns.P + "bg"), pc) ?? layout.Bg ?? FillDef.Solid(Rgba.White);
            bool showMaster = (string)root.Attribute("showMasterSp") != "0";
            slide.MasterShapes = showMaster ? layout.AllDecor : new List<ShapeModel>();
            _shapeCount = 0;
            if (pc.SpTree != null) slide.Shapes = ParseTree(pc.SpTree, pc, 0);

            // Заметки
            var notesPart = _pkg.FindByRelType(part, Rt.NotesSlide);
            if (notesPart != null && _pkg.Has(notesPart))
            {
                slide.NotesPartName = notesPart;
                try
                {
                    var nd = _pkg.GetXml(notesPart);
                    var body = nd.Root.Element(Ns.P + "cSld")?.Element(Ns.P + "spTree")?.Elements(Ns.P + "sp")
                        .FirstOrDefault(s => (string)s.Element(Ns.P + "nvSpPr")?.Element(Ns.P + "nvPr")?.Element(Ns.P + "ph")?.Attribute("type") == "body");
                    if (body != null)
                        slide.Notes = string.Join("\n", body.Element(Ns.P + "txBody")?.Elements(Ns.A + "p").Select(p => string.Concat(p.Elements().Select(e => e.Name.LocalName == "br" ? "\n" : (string)e.Element(Ns.A + "t") ?? ""))) ?? Enumerable.Empty<string>());
                }
                catch { }
            }
            return slide;
        }

        List<ShapeModel> ParseTree(XElement container, PartCtx pc, int depth)
        {
            var list = new List<ShapeModel>();
            if (depth > Limits.MaxNesting) return list;
            foreach (var el in container.Elements())
            {
                if (++_shapeCount > Limits.MaxShapesPerSlide) break;
                var s = ParseElement(el, pc, depth);
                if (s != null) list.Add(s);
            }
            return list;
        }

        ShapeModel ParseElement(XElement el, PartCtx pc, int depth)
        {
            try
            {
                if (el.Name == Ns.Mc + "AlternateContent")
                {
                    var choice = el.Element(Ns.Mc + "Fallback") ?? el.Element(Ns.Mc + "Choice");
                    var inner = choice?.Elements().FirstOrDefault();
                    return inner != null ? ParseElement(inner, pc, depth) : null;
                }
                switch (el.Name.LocalName)
                {
                    case "sp": return ParseSp(el, pc, false);
                    case "cxnSp": return ParseSp(el, pc, true);
                    case "pic": return ParsePic(el, pc);
                    case "graphicFrame": return ParseFrame(el, pc, depth);
                    case "grpSp": return ParseGroup(el, pc, depth);
                }
            }
            catch (UnsafeFileException) { throw; }
            catch (Exception ex) { _pres.Warnings.Add("Объект пропущен (" + el.Name.LocalName + "): " + ex.Message); }
            return null;
        }

        static XElement Child(XElement e, string local) => e?.Elements().FirstOrDefault(x => x.Name.LocalName == local);

        static void ReadNv(XElement nvContainer, ShapeModel s)
        {
            var c = Child(nvContainer, "cNvPr");
            if (c == null) return;
            s.Id = (int)Dml.Attr(c, "id", 0);
            s.Name = (string)c.Attribute("name") ?? "";
            s.AltText = (string)c.Attribute("descr");
        }

        static bool ReadXfrm(XElement xfrm, ShapeModel s)
        {
            if (xfrm == null) return false;
            var off = xfrm.Element(Ns.A + "off"); var ext = xfrm.Element(Ns.A + "ext");
            if (off == null || ext == null) return false;
            s.X = Dml.Attr(off, "x", 0); s.Y = Dml.Attr(off, "y", 0);
            s.W = Math.Max(0, Dml.Attr(ext, "cx", 0)); s.H = Math.Max(0, Dml.Attr(ext, "cy", 0));
            s.Rot = Dml.Attr(xfrm, "rot", 0) / 60000.0;
            s.FlipH = Dml.Bool(xfrm, "flipH") ?? false; s.FlipV = Dml.Bool(xfrm, "flipV") ?? false;
            return true;
        }

        void ReadGeometry(XElement spPr, ShapeModel s)
        {
            var prst = spPr?.Element(Ns.A + "prstGeom");
            if (prst != null)
            {
                s.Geometry = (string)prst.Attribute("prst") ?? "rect";
                foreach (var gd in prst.Element(Ns.A + "avLst")?.Elements(Ns.A + "gd") ?? Enumerable.Empty<XElement>())
                {
                    var f = ((string)gd.Attribute("fmla") ?? "").Split(' ');
                    if (f.Length == 2 && f[0] == "val" && double.TryParse(f[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                        s.Adj[(string)gd.Attribute("name") ?? "adj"] = v;
                }
                return;
            }
            var cust = spPr?.Element(Ns.A + "custGeom");
            if (cust != null)
            {
                s.Geometry = "custom";
                double w = Math.Max(1, s.W), h = Math.Max(1, s.H);
                s.CustomPaths = Dml.ParseCustGeom(cust, w, h);
                s.CustW = w; s.CustH = h;
            }
        }

        // поиск заполнителя на макете/образце
        static XElement FindPh(XElement spTree, string type, string idx, bool byIdx)
        {
            if (spTree == null) return null;
            XElement byType = null;
            foreach (var sp in spTree.Elements())
            {
                var nv = sp.Elements().FirstOrDefault(e => e.Name.LocalName.StartsWith("nv", StringComparison.Ordinal));
                var ph = Child(nv, "nvPr")?.Element(Ns.P + "ph");
                if (ph == null) continue;
                var t = (string)ph.Attribute("type") ?? "obj";
                var i = (string)ph.Attribute("idx");
                if (byIdx && idx != null && i == idx) return sp;
                if (byType == null && NormType(t) == NormType(type)) byType = sp;
            }
            return byType;
        }

        static string NormType(string t)
        {
            switch (t)
            {
                case "ctrTitle": case "title": return "title";
                case "subTitle": case "body": case "obj": case null: return "body";
                default: return t;
            }
        }

        struct PhChain { public XElement Layout, Master; }

        PhChain GetPhChain(PartCtx pc, string type, string idx)
        {
            var ch = new PhChain();
            if (type == null) return ch;
            if (pc.IsSlide && pc.Layout != null && pc.Layout.PC != null)
                ch.Layout = FindPh(pc.Layout.PC.SpTree, type, idx, true);
            if (pc.Master != null && (pc.IsSlide || pc.Layout != null))
            {
                string lt = type;
                var layoutPh = ch.Layout?.Element(Ns.P + "nvSpPr")?.Element(Ns.P + "nvPr")?.Element(Ns.P + "ph");
                if (layoutPh != null) lt = (string)layoutPh.Attribute("type") ?? "obj";
                ch.Master = FindPh(pc.Master.PC?.SpTree, lt, null, false);
            }
            return ch;
        }

        LevelStyle[] BuildLevels(PartCtx pc, string phType, PhChain chain, XElement ownLstStyle, Rgba? fontRefColor, string fontRefFont)
        {
            var lv = new LevelStyle[9];
            var ctx = pc.Ctx;
            for (int i = 0; i < 9; i++)
            {
                lv[i] = new LevelStyle { Color = ctx.Get("tx1", Rgba.Black), Font = pc.Master?.Theme.MinorFont ?? "Calibri", SizePt = 18 };
                Dml.ApplyPPr(_defaultTextStyle?.Element(Ns.A + ("lvl" + (i + 1) + "pPr")), lv[i], ctx);
            }
            if (phType != null && pc.Master?.TxStyles != null)
            {
                var nt = NormType(phType);
                XElement st = nt == "title" ? pc.Master.TxStyles.Element(Ns.P + "titleStyle")
                            : nt == "body" ? pc.Master.TxStyles.Element(Ns.P + "bodyStyle")
                            : pc.Master.TxStyles.Element(Ns.P + "otherStyle");
                for (int i = 0; i < 9; i++) Dml.ApplyPPr(st?.Element(Ns.A + ("lvl" + (i + 1) + "pPr")), lv[i], ctx);
                ApplyLst(Child(chain.Master, "txBody")?.Element(Ns.A + "lstStyle"), lv, ctx);
                ApplyLst(Child(chain.Layout, "txBody")?.Element(Ns.A + "lstStyle"), lv, ctx);
            }
            if (fontRefColor.HasValue) foreach (var l in lv) l.Color = fontRefColor.Value;
            if (fontRefFont != null) foreach (var l in lv) l.Font = fontRefFont;
            ApplyLst(ownLstStyle, lv, ctx);
            return lv;
        }

        static void ApplyLst(XElement lst, LevelStyle[] lv, ColorCtx ctx)
        {
            if (lst == null) return;
            for (int i = 0; i < 9; i++) Dml.ApplyPPr(lst.Element(Ns.A + ("lvl" + (i + 1) + "pPr")), lv[i], ctx);
        }

        ShapeModel ParseSp(XElement el, PartCtx pc, bool connector)
        {
            var s = new ShapeModel { Kind = connector ? ShapeKind.Connector : ShapeKind.Shape, Original = el };
            var nv = Child(el, connector ? "nvCxnSpPr" : "nvSpPr");
            ReadNv(nv, s);
            var cNvPr = Child(nv, "cNvPr");
            var hl = (string)cNvPr?.Element(Ns.A + "hlinkClick")?.Attribute(Ns.R + "id");
            s.Hyperlink = RelToUrl(pc, hl);
            s.IsTextBox = Dml.Bool(Child(nv, "cNvSpPr"), "txBox") ?? false;
            var ph = Child(nv, "nvPr")?.Element(Ns.P + "ph");
            if (ph != null) { s.PlaceholderType = (string)ph.Attribute("type") ?? "obj"; s.PlaceholderIdx = (string)ph.Attribute("idx"); }
            if (pc.IsMasterOrLayout && ph != null) return s; // заполнители образца не рисуем на слайде

            var chain = GetPhChain(pc, s.PlaceholderType, s.PlaceholderIdx);
            var spPr = Child(el, "spPr");
            if (!ReadXfrm(spPr?.Element(Ns.A + "xfrm"), s))
            {
                if (!ReadXfrm(Child(chain.Layout, "spPr")?.Element(Ns.A + "xfrm"), s))
                    ReadXfrm(Child(chain.Master, "spPr")?.Element(Ns.A + "xfrm"), s);
                s.Rot = 0;
            }
            ReadGeometry(spPr, s);
            if (s.Geometry == "rect" && spPr?.Element(Ns.A + "prstGeom") == null && chain.Layout != null) ReadGeometry(Child(chain.Layout, "spPr"), s);

            // стиль
            var style = Child(el, "style");
            Rgba? fontRefColor = null; string fontRefFont = null;
            FillDef styleFill = null; LineDef styleLine = null;
            if (style != null)
            {
                var fr = style.Element(Ns.A + "fillRef");
                int fi = (int)Dml.Attr(fr, "idx", 0);
                var fc = Dml.ParseColorIn(fr, pc.Ctx);
                if (fi >= 1 && fi - 1 < pc.Master.FillStyles.Count) styleFill = Dml.ParseFillElement(pc.Master.FillStyles[fi - 1], pc.Ctx.WithPh(fc), null);
                else if (fi >= 1001 && fi - 1001 < pc.Master.BgStyles.Count) styleFill = Dml.ParseFillElement(pc.Master.BgStyles[fi - 1001], pc.Ctx.WithPh(fc), null);
                else if (fi == 0) styleFill = FillDef.NoFill();
                var lr = style.Element(Ns.A + "lnRef");
                int li = (int)Dml.Attr(lr, "idx", 0);
                var lc = Dml.ParseColorIn(lr, pc.Ctx);
                if (li >= 1 && li - 1 < pc.Master.LineStyles.Count) styleLine = Dml.ParseLine(pc.Master.LineStyles[li - 1], pc.Ctx.WithPh(lc), new LineDef { Visible = true, Color = lc ?? Rgba.Black, WidthEmu = 9525 });
                var fo = style.Element(Ns.A + "fontRef");
                fontRefColor = Dml.ParseColorIn(fo, pc.Ctx);
                var foIdx = (string)fo?.Attribute("idx");
                if (foIdx == "major") fontRefFont = pc.Master.Theme.MajorFont;
            }
            var fill = Dml.ParseFill(spPr, pc.Ctx, rid => RelToMedia(pc, rid));
            if (fill == null && chain.Layout != null) fill = Dml.ParseFill(Child(chain.Layout, "spPr"), pc.Layout.PC.Ctx, rid => RelToMedia(pc.Layout.PC, rid));
            if (fill == null && chain.Master != null) fill = Dml.ParseFill(Child(chain.Master, "spPr"), pc.Master.PC.Ctx, rid => RelToMedia(pc.Master.PC, rid));
            s.Fill = fill ?? styleFill ?? FillDef.NoFill();
            if (connector && s.Fill.Kind != FillKind.None) s.Fill = FillDef.NoFill();
            var lnEl = spPr?.Element(Ns.A + "ln");
            LineDef baseLine = styleLine;
            if (baseLine == null && chain.Layout != null) { var lle = Child(chain.Layout, "spPr")?.Element(Ns.A + "ln"); if (lle != null) baseLine = Dml.ParseLine(lle, pc.Ctx, new LineDef { Visible = Dml.FillChild(lle) != null }); }
            s.Line = Dml.ParseLine(lnEl, pc.Ctx, baseLine ?? new LineDef { Visible = false });
            if (lnEl != null && baseLine == null && Dml.FillChild(lnEl) == null && lnEl.Attribute("w") != null) s.Line.Visible = connector;

            // текст
            var tx = Child(el, "txBody");
            var levels = BuildLevels(pc, s.PlaceholderType, chain, tx?.Element(Ns.A + "lstStyle"), fontRefColor, fontRefFont);
            s.Text = ParseTextBody(tx, levels, pc, Child(chain.Layout, "txBody")?.Element(Ns.A + "bodyPr"), Child(chain.Master, "txBody")?.Element(Ns.A + "bodyPr"), s.PlaceholderType);
            return s;
        }

        TextBodyModel ParseTextBody(XElement tx, LevelStyle[] levels, PartCtx pc, XElement layoutBodyPr, XElement masterBodyPr, string phType)
        {
            var t = new TextBodyModel { Levels = levels };
            var own = tx?.Element(Ns.A + "bodyPr");
            Func<string, string> BA = n => (string)own?.Attribute(n) ?? (string)layoutBodyPr?.Attribute(n) ?? (string)masterBodyPr?.Attribute(n);
            double D(string n, double def) { var v = BA(n); return v != null && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d : def; }
            t.LIns = D("lIns", 91440); t.TIns = D("tIns", 45720); t.RIns = D("rIns", 91440); t.BIns = D("bIns", 45720);
            t.Anchor = BA("anchor") ?? (NormType(phType) == "title" && phType != null ? "ctr" : "t");
            t.Wrap = BA("wrap") != "none";
            t.Vert = BA("vert") ?? "horz";
            var na = own?.Element(Ns.A + "normAutofit");
            if (na != null) { t.FontScale = Dml.Attr(na, "fontScale", 100000) / 100000.0; t.LnSpcReduction = Dml.Attr(na, "lnSpcReduction", 0) / 100000.0; }
            t.AutoFitShape = own?.Element(Ns.A + "spAutoFit") != null;
            if (tx == null) { t.Paras.Add(new ParaModel()); return t; }
            foreach (var p in tx.Elements(Ns.A + "p"))
            {
                var pm = new ParaModel();
                var pPr = p.Element(Ns.A + "pPr");
                if (pPr != null)
                {
                    pm.OrigPPr = new XElement(pPr);
                    pm.Align = (string)pPr.Attribute("algn");
                    pm.Level = (int)Units.Clamp(Dml.Attr(pPr, "lvl", 0), 0, 8);
                    pm.Bullet = Dml.ParseBullet(pPr);
                    var ls = pPr.Element(Ns.A + "lnSpc")?.Element(Ns.A + "spcPct"); if (ls != null) pm.LineSpacingPct = Dml.Attr(ls, "val", 100000) / 1000.0;
                    var sb = pPr.Element(Ns.A + "spcBef")?.Element(Ns.A + "spcPts"); if (sb != null) pm.SpaceBeforePt = Dml.Attr(sb, "val", 0) / 100.0;
                    var sa = pPr.Element(Ns.A + "spcAft")?.Element(Ns.A + "spcPts"); if (sa != null) pm.SpaceAfterPt = Dml.Attr(sa, "val", 0) / 100.0;
                }
                foreach (var r in p.Elements())
                {
                    var ln = r.Name.LocalName;
                    if (ln == "r" || ln == "fld")
                    {
                        var rm = ParseRun(r.Element(Ns.A + "rPr"), pc);
                        rm.Text = (string)r.Element(Ns.A + "t") ?? "";
                        pm.Runs.Add(rm);
                    }
                    else if (ln == "br")
                    {
                        var rm = ParseRun(r.Element(Ns.A + "rPr"), pc);
                        rm.IsBreak = true; rm.Text = "";
                        pm.Runs.Add(rm);
                    }
                }
                var end = p.Element(Ns.A + "endParaRPr");
                if (end?.Attribute("sz") != null) pm.EndSizePt = Dml.Attr(end, "sz", 1800) / 100.0;
                t.Paras.Add(pm);
            }
            if (t.Paras.Count == 0) t.Paras.Add(new ParaModel());
            return t;
        }

        RunModel ParseRun(XElement rPr, PartCtx pc)
        {
            var r = new RunModel();
            if (rPr == null) return r;
            r.OrigRPr = new XElement(rPr);
            if (rPr.Attribute("sz") != null) r.SizePt = Dml.Attr(rPr, "sz", 1800) / 100.0;
            r.Bold = Dml.Bool(rPr, "b"); r.Italic = Dml.Bool(rPr, "i");
            var u = (string)rPr.Attribute("u"); if (u != null) r.Underline = u != "none";
            var st = (string)rPr.Attribute("strike"); if (st != null) r.Strike = st != "noStrike";
            r.Color = Dml.ParseColorIn(rPr.Element(Ns.A + "solidFill"), pc.Ctx);
            if (!r.Color.HasValue)
            {
                var gf = rPr.Element(Ns.A + "gradFill")?.Element(Ns.A + "gsLst")?.Elements(Ns.A + "gs").FirstOrDefault();
                if (gf != null) r.Color = Dml.ParseColorIn(gf, pc.Ctx);
            }
            r.Font = Dml.ResolveFont((string)rPr.Element(Ns.A + "latin")?.Attribute("typeface"), pc.Master?.Theme);
            var hl = (string)rPr.Element(Ns.A + "hlinkClick")?.Attribute(Ns.R + "id");
            r.Hyperlink = RelToUrl(pc, hl);
            return r;
        }

        ShapeModel ParsePic(XElement el, PartCtx pc)
        {
            var s = new ShapeModel { Kind = ShapeKind.Picture, Original = el };
            var nv = Child(el, "nvPicPr");
            ReadNv(nv, s);
            var ph = Child(nv, "nvPr")?.Element(Ns.P + "ph");
            if (ph != null) { s.PlaceholderType = (string)ph.Attribute("type") ?? "obj"; s.PlaceholderIdx = (string)ph.Attribute("idx"); }
            var spPr = Child(el, "spPr");
            if (!ReadXfrm(spPr?.Element(Ns.A + "xfrm"), s) && ph != null)
            {
                var chain = GetPhChain(pc, s.PlaceholderType, s.PlaceholderIdx);
                if (!ReadXfrm(Child(chain.Layout, "spPr")?.Element(Ns.A + "xfrm"), s)) ReadXfrm(Child(chain.Master, "spPr")?.Element(Ns.A + "xfrm"), s);
            }
            ReadGeometry(spPr, s);
            var blipFill = Child(el, "blipFill");
            var blip = blipFill?.Element(Ns.A + "blip");
            var rid = (string)blip?.Attribute(Ns.R + "embed");
            s.OrigImageRelId = rid;
            s.ImageKey = RelToMedia(pc, rid);
            if (blip?.Attribute(Ns.R + "link") != null && s.ImageKey == null) s.GraphicLabel = "Внешнее изображение заблокировано";
            var src = blipFill?.Element(Ns.A + "srcRect");
            if (src != null)
            {
                s.CropL = Units.Clamp(Dml.Attr(src, "l", 0) / 100000.0, -1, 0.99); s.CropT = Units.Clamp(Dml.Attr(src, "t", 0) / 100000.0, -1, 0.99);
                s.CropR = Units.Clamp(Dml.Attr(src, "r", 0) / 100000.0, -1, 0.99); s.CropB = Units.Clamp(Dml.Attr(src, "b", 0) / 100000.0, -1, 0.99);
            }
            s.Fill = Dml.ParseFill(spPr, pc.Ctx, r => RelToMedia(pc, r)) ?? FillDef.NoFill();
            s.Line = Dml.ParseLine(spPr?.Element(Ns.A + "ln"), pc.Ctx, new LineDef { Visible = false });
            var hl = (string)Child(nv, "cNvPr")?.Element(Ns.A + "hlinkClick")?.Attribute(Ns.R + "id");
            s.Hyperlink = RelToUrl(pc, hl);
            return s;
        }

        ShapeModel ParseGroup(XElement el, PartCtx pc, int depth)
        {
            var s = new ShapeModel { Kind = ShapeKind.Group, Original = el };
            ReadNv(Child(el, "nvGrpSpPr"), s);
            var xfrm = Child(el, "grpSpPr")?.Element(Ns.A + "xfrm");
            ReadXfrm(xfrm, s);
            var chOff = xfrm?.Element(Ns.A + "chOff"); var chExt = xfrm?.Element(Ns.A + "chExt");
            s.ChX = chOff != null ? Dml.Attr(chOff, "x", s.X) : s.X; s.ChY = chOff != null ? Dml.Attr(chOff, "y", s.Y) : s.Y;
            s.ChW = chExt != null ? Dml.Attr(chExt, "cx", s.W) : s.W; s.ChH = chExt != null ? Dml.Attr(chExt, "cy", s.H) : s.H;
            s.Children = ParseTree(el, pc, depth + 1);
            return s;
        }

        ShapeModel ParseFrame(XElement el, PartCtx pc, int depth)
        {
            var s = new ShapeModel { Kind = ShapeKind.Graphic, Original = el };
            ReadNv(Child(el, "nvGraphicFramePr"), s);
            ReadXfrm(Child(el, "xfrm"), s);
            var gd = el.Element(Ns.A + "graphic")?.Element(Ns.A + "graphicData");
            var uri = (string)gd?.Attribute("uri") ?? "";
            if (uri == Ns.TableUri)
            {
                var tbl = gd.Element(Ns.A + "tbl");
                if (tbl != null) { s.Kind = ShapeKind.Table; s.Table = ParseTable(tbl, pc); }
                return s;
            }
            if (uri == Ns.ChartUri) { s.GraphicLabel = "Диаграмма"; return s; }
            if (uri == Ns.DgmUri)
            {
                s.GraphicLabel = "SmartArt";
                try
                {
                    var drawRel = pc.Rels.Values.FirstOrDefault(r => r.Type.EndsWith("/diagramDrawing") && !r.External);
                    var relIds = gd.Element(Ns.Dgm + "relIds");
                    // ищем часть рисунка SmartArt, связанную с данными этой диаграммы
                    var dmId = (string)relIds?.Attribute(Ns.R + "dm");
                    string drawingPart = null;
                    if (dmId != null && pc.Rels.TryGetValue(dmId, out var dmRel))
                    {
                        var dataPart = OpcPackage.ResolveTarget(pc.Part, dmRel.Target);
                        var dataDoc = _pkg.GetXml(dataPart);
                        var ext = dataDoc?.Descendants().FirstOrDefault(e => e.Name.LocalName == "dataModelExt");
                        var relId = (string)ext?.Attribute("relId");
                        if (relId != null && pc.Rels.TryGetValue(relId, out var dr)) drawingPart = OpcPackage.ResolveTarget(pc.Part, dr.Target);
                    }
                    if (drawingPart == null && drawRel != null) drawingPart = OpcPackage.ResolveTarget(pc.Part, drawRel.Target);
                    if (drawingPart != null && _pkg.Has(drawingPart))
                    {
                        var ddoc = _pkg.GetXml(drawingPart);
                        var tree = ddoc.Root.Elements().FirstOrDefault(e => e.Name.LocalName == "spTree");
                        if (tree != null)
                        {
                            var dpc = MakeCtx(drawingPart, pc.Ctx, pc.Master, pc.Layout, false);
                            var kids = ParseTree(tree, dpc, depth + 1);
                            foreach (var k in kids) { k.Original = null; }
                            s.Children = kids;
                            s.ChX = 0; s.ChY = 0; s.ChW = s.W; s.ChH = s.H;
                        }
                    }
                }
                catch { }
                return s;
            }
            if (uri == Ns.OleUri || gd?.Descendants().Any(e => e.Name.LocalName == "oleObj") == true)
            {
                var ole = gd.Descendants().FirstOrDefault(e => e.Name.LocalName == "oleObj");
                s.GraphicLabel = "OLE-объект" + (ole?.Attribute("progId") != null ? " (" + (string)ole.Attribute("progId") + ")" : "");
                var pic = gd.Descendants(Ns.P + "pic").FirstOrDefault();
                if (pic != null)
                {
                    var rid = (string)pic.Descendants(Ns.A + "blip").FirstOrDefault()?.Attribute(Ns.R + "embed");
                    s.ImageKey = RelToMedia(pc, rid);
                }
                else
                {
                    // устаревший формат: изображение через атрибут r:id у объекта vml — ищем первую картинку-связь
                    var imgId = (string)ole?.Attribute("imgId") ?? (string)ole?.Attribute(Ns.R + "id");
                    var key = RelToMedia(pc, imgId);
                    if (key != null && (_pres.Media[key].ContentType ?? "").StartsWith("image")) s.ImageKey = key;
                }
                return s;
            }
            s.GraphicLabel = uri.Contains("media") || uri.Contains("video") ? "Медиа" : "Объект";
            return s;
        }

        TableModel ParseTable(XElement tbl, PartCtx pc)
        {
            var t = new TableModel();
            var tblPr = tbl.Element(Ns.A + "tblPr");
            t.FirstRow = Dml.Bool(tblPr, "firstRow") ?? false;
            t.BandRow = Dml.Bool(tblPr, "bandRow") ?? false;
            t.StyleAccent = pc.Ctx.Get("accent1", Rgba.FromRgb(0x4472C4));
            foreach (var gc in tbl.Element(Ns.A + "tblGrid")?.Elements(Ns.A + "gridCol") ?? Enumerable.Empty<XElement>()) t.ColWidths.Add(Dml.Attr(gc, "w", 914400));
            foreach (var tr in tbl.Elements(Ns.A + "tr"))
            {
                t.RowHeights.Add(Dml.Attr(tr, "h", 370840));
                var row = new List<TableCell>();
                foreach (var tc in tr.Elements(Ns.A + "tc"))
                {
                    var c = new TableCell
                    {
                        GridSpan = (int)Units.Clamp(Dml.Attr(tc, "gridSpan", 1), 1, 1000),
                        RowSpan = (int)Units.Clamp(Dml.Attr(tc, "rowSpan", 1), 1, 1000),
                        HMerge = Dml.Bool(tc, "hMerge") ?? false,
                        VMerge = Dml.Bool(tc, "vMerge") ?? false,
                    };
                    var lv = TextBodyModel.DefaultLevels();
                    foreach (var l in lv) { l.Color = pc.Ctx.Get("tx1", Rgba.Black); l.Font = pc.Master?.Theme.MinorFont ?? "Calibri"; l.SizePt = 18; }
                    var tcPr = tc.Element(Ns.A + "tcPr");
                    c.Text = ParseTextBody(tc.Element(Ns.A + "txBody"), lv, pc, null, null, null);
                    c.Text.LIns = Dml.Attr(tcPr, "marL", 91440); c.Text.RIns = Dml.Attr(tcPr, "marR", 91440);
                    c.Text.TIns = Dml.Attr(tcPr, "marT", 45720); c.Text.BIns = Dml.Attr(tcPr, "marB", 45720);
                    c.Text.Anchor = (string)tcPr?.Attribute("anchor") ?? "t";
                    c.Fill = Dml.ParseFill(tcPr, pc.Ctx, r => RelToMedia(pc, r));
                    LineDef B(string n) { var e = tcPr?.Element(Ns.A + n); return e == null ? null : Dml.ParseLine(e, pc.Ctx, new LineDef { Visible = Dml.FillChild(e) != null }); }
                    c.BorderL = B("lnL"); c.BorderR = B("lnR"); c.BorderT = B("lnT"); c.BorderB = B("lnB");
                    row.Add(c);
                }
                t.Rows.Add(row);
            }
            int cols = t.ColWidths.Count;
            foreach (var row in t.Rows) while (row.Count < cols) row.Add(new TableCell());
            return t;
        }
    }
}
