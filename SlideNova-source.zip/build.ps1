# Сборка SlideNova: приложение (.NET 8, автономное x64), обработчик эскизов (.NET Framework 4.8),
# портативный архив и установщик. Запускается на Windows (GitHub Actions: windows-latest).
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dist = Join-Path $root 'dist'
$app  = Join-Path $dist 'SlideNova'
$version = if ($env:SN_VERSION) { $env:SN_VERSION } else { '1.0.0' }

if (Test-Path $dist) { Remove-Item -Recurse -Force $dist }
New-Item -ItemType Directory -Force -Path $app | Out-Null

Write-Host '== Приложение SlideNova (WPF, .NET 8, win-x64, автономное) =='
dotnet publish (Join-Path $root 'src/App/SlideNova.csproj') -c Release -r win-x64 --self-contained true -o $app -p:Version=$version
if ($LASTEXITCODE -ne 0) { throw 'Сборка приложения завершилась с ошибкой' }

Write-Host '== Обработчик эскизов Проводника (.NET Framework 4.8) =='
$thumbOut = Join-Path $dist 'thumbs'
dotnet build (Join-Path $root 'src/Thumbs/SlideNova.Thumbnails.csproj') -c Release -o $thumbOut
if ($LASTEXITCODE -ne 0) { throw 'Сборка обработчика эскизов завершилась с ошибкой' }
Copy-Item (Join-Path $thumbOut 'SlideNova.Thumbnails.dll') $app
Remove-Item -Recurse -Force $thumbOut

Copy-Item (Join-Path $root 'assets/SlideNova.ico') $app
Copy-Item (Join-Path $root 'README.md') (Join-Path $app 'ПРОЧТИ.md')
Get-ChildItem $app -Filter *.pdb -Recurse | Remove-Item -Force

Write-Host '== Портативный архив =='
Compress-Archive -Path (Join-Path $app '*') -DestinationPath (Join-Path $dist "SlideNova-$version-win-x64-portable.zip") -CompressionLevel Optimal

Write-Host '== Установщик (Inno Setup) =='
$iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) {
    try { choco install innosetup -y --no-progress | Out-Null } catch { }
    $iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if ($iscc) {
    $env:SN_VERSION = $version
    & $iscc (Join-Path $root 'installer/SlideNova.iss')
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Установщик не собран (портативная версия готова).' }
} else { Write-Warning 'Inno Setup недоступен — собрана только портативная версия.' }

Write-Host '== Готово =='
Get-ChildItem $dist | Format-Table Name, Length
